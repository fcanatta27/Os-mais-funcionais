#!/usr/bin/env bash
# build-gcc-15.2.0-pass1.sh
# Primeiro estágio do GCC (pass1, somente C, sem headers) para toolchain em $ROOTFS/tools

set -euo pipefail
trap 'echo "[gcc] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-gcc-15.2.0-pass1}
SRC_DIR=${SRC_DIR:-/tmp/sources}

TARGET=${TARGET:-x86_64-pc-linux-gnu}
GCC_VERSION=${GCC_VERSION:-15.2.0}
GCC_PKG=${GCC_PKG:-gcc-"$GCC_VERSION"}
GCC_ARCHIVE=${GCC_ARCHIVE:-"$SRC_DIR/$GCC_PKG.tar.xz"}

MPFR_VERSION=${MPFR_VERSION:-4.2.1}
GMP_VERSION=${GMP_VERSION:-6.3.0}
MPC_VERSION=${MPC_VERSION:-1.3.1}

MPFR_PKG=${MPFR_PKG:-mpfr-"$MPFR_VERSION"}
GMP_PKG=${GMP_PKG:-gmp-"$GMP_VERSION"}
MPC_PKG=${MPC_PKG:-mpc-"$MPC_VERSION"}

MPFR_ARCHIVE=${MPFR_ARCHIVE:-"$SRC_DIR/$MPFR_PKG.tar.xz"}
GMP_ARCHIVE=${GMP_ARCHIVE:-"$SRC_DIR/$GMP_PKG.tar.xz"}
MPC_ARCHIVE=${MPC_ARCHIVE:-"$SRC_DIR/$MPC_PKG.tar.gz"}

GCC_URL=${GCC_URL:-"https://ftp.gnu.org/gnu/gcc/$GCC_PKG/$GCC_PKG.tar.xz"}
MPFR_URL=${MPFR_URL:-"https://ftp.gnu.org/gnu/mpfr/$MPFR_PKG.tar.xz"}
GMP_URL=${GMP_URL:-"https://ftp.gnu.org/gnu/gmp/$GMP_PKG.tar.xz"}
MPC_URL=${MPC_URL:-"https://ftp.gnu.org/gnu/mpc/$MPC_PKG.tar.gz"}

JOBS=${JOBS:-"$(nproc)"}

export ROOTFS TOOLS TMP SRC_DIR TARGET GCC_VERSION GCC_PKG GCC_ARCHIVE
export MPFR_VERSION GMP_VERSION MPC_VERSION
export MPFR_PKG GMP_PKG MPC_PKG
export MPFR_ARCHIVE GMP_ARCHIVE MPC_ARCHIVE

###############################################################################
# Preparação de diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"

for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  if [[ ! -w "$d" ]]; then
    echo "[gcc] ERRO: diretório '$d' não é gravável" >&2
    exit 1
  fi
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar make gcc; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[gcc] ERRO: comando obrigatório não encontrado: $cmd" >&2
    exit 1
  fi
done

###############################################################################
# Obtenção dos tarballs
###############################################################################

if [[ ! -f "$GCC_ARCHIVE" ]]; then
  echo "[gcc] Baixando $GCC_PKG de $GCC_URL..."
  wget -O "$GCC_ARCHIVE" "$GCC_URL"
fi

if [[ ! -f "$MPFR_ARCHIVE" ]]; then
  echo "[gcc] Baixando $MPFR_PKG de $MPFR_URL..."
  wget -O "$MPFR_ARCHIVE" "$MPFR_URL"
fi

if [[ ! -f "$GMP_ARCHIVE" ]]; then
  echo "[gcc] Baixando $GMP_PKG de $GMP_URL..."
  wget -O "$GMP_ARCHIVE" "$GMP_URL"
fi

if [[ ! -f "$MPC_ARCHIVE" ]]; then
  echo "[gcc] Baixando $MPC_PKG de $MPC_URL..."
  wget -O "$MPC_ARCHIVE" "$MPC_URL"
fi

###############################################################################
# Extração do GCC e bibliotecas necessárias
###############################################################################

cd "$TMP"
rm -rf "$GCC_PKG" build-gcc
tar -xf "$GCC_ARCHIVE"

cd "$GCC_PKG"

# Integrar MPFR
tar -xf "$MPFR_ARCHIVE"
mv "$MPFR_PKG" mpfr

# Integrar GMP
tar -xf "$GMP_ARCHIVE"
mv "$GMP_PKG" gmp

# Integrar MPC
tar -xf "$MPC_ARCHIVE"
mv "$MPC_PKG" mpc

cd "$TMP"
mkdir -p build-gcc
cd build-gcc

###############################################################################
# Configuração
###############################################################################

echo "[gcc] Configurando (pass1)..."

# Garante que o GCC/binutils recém-instalados fiquem na frente para próximos passos
export PATH="$TOOLS/bin:$PATH"

../"$GCC_PKG"/configure       --target="$TARGET"       --prefix="$TOOLS"       --with-sysroot="$ROOTFS"       --with-newlib       --without-headers       --disable-nls       --disable-shared       --disable-multilib       --disable-threads       --disable-libatomic       --disable-libgomp       --disable-libquadmath       --disable-libssp       --disable-libvtv       --disable-libstdcxx       --disable-bootstrap       --enable-languages=c       --enable-default-pie       --enable-default-ssp

###############################################################################
# Construção dos artefatos mínimos
###############################################################################

echo "[gcc] Construindo (pass1) com $JOBS jobs..."
make -j"$JOBS" all-gcc
make -j"$JOBS" all-target-libgcc

###############################################################################
# Instalação
###############################################################################

echo "[gcc] Instalando em $TOOLS..."
make install-gcc
make install-target-libgcc

echo "[gcc] Concluído com sucesso."
