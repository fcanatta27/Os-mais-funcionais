#!/usr/bin/env bash
# build-gcc-15.2.0-pass2.sh
# Constrói o GCC 15.2.0 (Pass 2) como ferramenta temporária em $ROOTFS/tools
#
# Este GCC Pass 2 é construído usando o sysroot em $ROOTFS e o target $TARGET,
# produzindo um compilador mais completo (com libc do sysroot) para o sistema.

set -euo pipefail
trap 'echo "[gcc-pass2] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-gcc-15.2.0-pass2}
SRC_DIR=${SRC_DIR:-/tmp/sources}

GCC_VERSION=${GCC_VERSION:-15.2.0}
GCC_PKG=${GCC_PKG:-gcc-"$GCC_VERSION"}
GCC_ARCHIVE=${GCC_ARCHIVE:-"$SRC_DIR/$GCC_PKG.tar.xz"}
GCC_URL=${GCC_URL:-"https://ftp.gnu.org/gnu/gcc/$GCC_PKG/$GCC_PKG.tar.xz"}

TARGET=${TARGET:-x86_64-pc-linux-gnu}

export ROOTFS TOOLS TMP SRC_DIR GCC_VERSION GCC_PKG GCC_ARCHIVE TARGET

###############################################################################
# Preparação de diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"

for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  if [[ ! -w "$d" ]]; then
    echo "[gcc-pass2] ERRO: diretório '$d' não é gravável" >&2
    exit 1
  fi
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar gcc make; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[gcc-pass2] ERRO: comando obrigatório não encontrado: $cmd" >&2
    exit 1
  fi
done

# Determina número de jobs de forma segura
if [[ -z "${JOBS:-}" ]]; then
  if command -v nproc >/dev/null 2>&1; then
    JOBS="$(nproc)"
  else
    JOBS=1
  fi
fi

###############################################################################
# Ambiente de build
###############################################################################

# Usa o toolchain temporário na frente do PATH (TARGET-* de Pass 1)
export PATH="$TOOLS/bin:$PATH"

# Muitos pacotes GNU reclamam se forem configurados como root sem isto
export FORCE_UNSAFE_CONFIGURE=1

: "${CFLAGS:=-O2}"
: "${CXXFLAGS:=-O2}"
export CFLAGS CXXFLAGS

###############################################################################
# Obtenção do código-fonte
###############################################################################

if [[ ! -f "$GCC_ARCHIVE" ]]; then
  echo "[gcc-pass2] Baixando $GCC_PKG de $GCC_URL..."
  wget -O "$GCC_ARCHIVE" "$GCC_URL"
fi

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$GCC_PKG" build-gcc-pass2
tar -xf "$GCC_ARCHIVE"

if [[ ! -d "$GCC_PKG" ]]; then
  echo "[gcc-pass2] ERRO: diretório de código-fonte $GCC_PKG não encontrado após extração." >&2
  exit 1
fi

mkdir -p build-gcc-pass2
cd build-gcc-pass2

###############################################################################
# Configuração
###############################################################################

echo "[gcc-pass2] Configurando para target $TARGET e sysroot $ROOTFS..."

# Triplet de build (host == build)
if [[ -z "${BUILD_TRIPLET:-}" ]]; then
  if [[ -x "../$GCC_PKG/config.guess" ]]; then
    BUILD_TRIPLET="$(../"$GCC_PKG"/config.guess)"
  elif [[ -x "../$GCC_PKG/build-aux/config.guess" ]]; then
    BUILD_TRIPLET="$(../"$GCC_PKG"/build-aux/config.guess)"
  else
    BUILD_TRIPLET="$(../"$GCC_PKG"/config.guess 2>/dev/null || true)"
  fi
fi

CONFIG_OPTS=(
  "--prefix=$TOOLS"
  "--with-sysroot=$ROOTFS"
  "--target=$TARGET"
  "--disable-nls"
  "--enable-languages=c,c++"
  "--disable-multilib"
  "--disable-libsanitizer"
  "--disable-libquadmath"
  "--disable-libquadmath-support"
  "--disable-bootstrap"
)

if [[ -n "${BUILD_TRIPLET:-}" ]]; then
  CONFIG_OPTS+=("--build=$BUILD_TRIPLET")
fi

../"$GCC_PKG"/configure "${CONFIG_OPTS[@]}"

###############################################################################
# Compilação
###############################################################################

echo "[gcc-pass2] Compilando com $JOBS jobs..."
make -j"$JOBS"

###############################################################################
# Testes opcionais
###############################################################################

if [[ "${GCC_PASS2_RUN_TESTS:-0}" = "1" ]]; then
  echo "[gcc-pass2] Executando 'make check' (pode ser MUITO demorado)..."
  make check
else
  echo "[gcc-pass2] Pulando 'make check' (defina GCC_PASS2_RUN_TESTS=1 para executar testes)."
fi

###############################################################################
# Instalação
###############################################################################

echo "[gcc-pass2] Instalando em $TOOLS..."
make install

echo "[gcc-pass2] Concluído com sucesso."
