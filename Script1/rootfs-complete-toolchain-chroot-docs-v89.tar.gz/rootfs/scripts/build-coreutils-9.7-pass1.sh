#!/usr/bin/env bash
# build-coreutils-9.7-pass1.sh
# Constrói o GNU coreutils 9.7 como ferramentas temporárias em $ROOTFS/tools (pass1).
#
# Estas ferramentas são usadas SOMENTE durante o build do sistema
# e não fazem parte do sistema final.

set -euo pipefail
trap 'echo "[coreutils] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-coreutils-9.7-pass1}
SRC_DIR=${SRC_DIR:-/tmp/sources}

COREUTILS_VERSION=${COREUTILS_VERSION:-9.7}
COREUTILS_PKG=${COREUTILS_PKG:-coreutils-"$COREUTILS_VERSION"}
COREUTILS_ARCHIVE=${COREUTILS_ARCHIVE:-"$SRC_DIR/$COREUTILS_PKG.tar.xz"}
COREUTILS_URL=${COREUTILS_URL:-"https://ftp.gnu.org/gnu/coreutils/$COREUTILS_PKG.tar.xz"}

JOBS=${JOBS:-"$(nproc)"}

export ROOTFS TOOLS TMP SRC_DIR COREUTILS_VERSION COREUTILS_PKG COREUTILS_ARCHIVE

###############################################################################
# Preparação de diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"

for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  if [[ ! -w "$d" ]]; then
    echo "[coreutils] ERRO: diretório '$d' não é gravável" >&2
    exit 1
  fi
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar make gcc; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[coreutils] ERRO: comando obrigatório não encontrado: $cmd" >&2
    exit 1
  fi
done

# Necessário ao configurar coreutils como root
export FORCE_UNSAFE_CONFIGURE=1

# Priorizar ferramentas temporárias
export PATH="$TOOLS/bin:$PATH"

###############################################################################
# Obtenção do código-fonte
###############################################################################

if [[ ! -f "$COREUTILS_ARCHIVE" ]]; then
  echo "[coreutils] Baixando $COREUTILS_PKG de $COREUTILS_URL..."
  wget -O "$COREUTILS_ARCHIVE" "$COREUTILS_URL"
fi

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$COREUTILS_PKG" build-coreutils
tar -xf "$COREUTILS_ARCHIVE"

if [[ ! -d "$COREUTILS_PKG" ]]; then
  echo "[coreutils] ERRO: diretório de código-fonte $COREUTILS_PKG não encontrado após extração." >&2
  exit 1
fi

mkdir -p build-coreutils
cd build-coreutils

###############################################################################
# Configuração
###############################################################################

echo "[coreutils] Configurando (pass1)..."

# Determinar triplet de build (ferramentas do host)
if [[ -z "${BUILD_TRIPLET:-}" ]]; then
  BUILD_TRIPLET="$(../"$COREUTILS_PKG"/build-aux/config.guess 2>/dev/null || true)"
fi

CONFIG_OPTS=(
  "--prefix=$TOOLS"
  "--disable-nls"
  "--enable-no-install-program=kill,uptime"
)

if [[ -n "${BUILD_TRIPLET:-}" ]]; then
  CONFIG_OPTS+=("--build=$BUILD_TRIPLET")
fi

../"$COREUTILS_PKG"/configure "${CONFIG_OPTS[@]}"

###############################################################################
# Compilação
###############################################################################

echo "[coreutils] Compilando (pass1) com $JOBS jobs..."
make -j"$JOBS"

###############################################################################
# Testes opcionais
###############################################################################

if [[ "${COREUTILS_RUN_TESTS:-0}" = "1" ]]; then
  echo "[coreutils] Executando 'make check' (opcional e demorado)..."
  make check
else
  echo "[coreutils] Pulando testes (defina COREUTILS_RUN_TESTS=1 para executar)."
fi

###############################################################################
# Instalação
###############################################################################

echo "[coreutils] Instalando em $TOOLS..."
make install

echo "[coreutils] Concluído com sucesso."
