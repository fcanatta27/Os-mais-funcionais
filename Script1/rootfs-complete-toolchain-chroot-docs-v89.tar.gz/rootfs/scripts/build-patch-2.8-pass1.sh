#!/usr/bin/env bash
# build-patch-2.8-pass1.sh
# Constrói o GNU patch 2.8 como ferramenta temporária em $ROOTFS/tools (pass1)

set -euo pipefail
trap 'echo "[patch] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-patch-2.8-pass1}
SRC_DIR=${SRC_DIR:-/tmp/sources}

PATCH_VERSION=${PATCH_VERSION:-2.8}
PATCH_PKG=${PATCH_PKG:-patch-"$PATCH_VERSION"}
PATCH_ARCHIVE=${PATCH_ARCHIVE:-"$SRC_DIR/$PATCH_PKG.tar.gz"}
PATCH_URL=${PATCH_URL:-"https://ftp.gnu.org/gnu/patch/$PATCH_PKG.tar.gz"}

export ROOTFS TOOLS TMP SRC_DIR PATCH_VERSION PATCH_PKG PATCH_ARCHIVE

###############################################################################
# Diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"
for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  [[ -w "$d" ]] || { echo "[patch] ERRO: $d não é gravável"; exit 1; }
done

###############################################################################
# Dependências
###############################################################################

for cmd in wget tar gcc make; do
  command -v "$cmd" >/dev/null 2>&1 || {
    echo "[patch] ERRO: comando obrigatório não encontrado: $cmd"
    exit 1
  }
done

# JOBS seguro
if [[ -z "${JOBS:-}" ]]; then
  if command -v nproc >/dev/null 2>&1; then
    JOBS="$(nproc)"
  else
    JOBS=1
  fi
fi

###############################################################################
# Ambiente
###############################################################################

export FORCE_UNSAFE_CONFIGURE=1
export PATH="$TOOLS/bin:$PATH"

: "${CFLAGS:=-O2}"
: "${CXXFLAGS:=-O2}"
export CFLAGS CXXFLAGS

###############################################################################
# Fonte
###############################################################################

if [[ ! -f "$PATCH_ARCHIVE" ]]; then
  wget -O "$PATCH_ARCHIVE" "$PATCH_URL"
fi

###############################################################################
# Build
###############################################################################

cd "$TMP"
rm -rf "$PATCH_PKG" build-patch
tar -xf "$PATCH_ARCHIVE"
[[ -d "$PATCH_PKG" ]] || { echo "[patch] ERRO: fonte não encontrada"; exit 1; }

mkdir build-patch
cd build-patch

# Triplet
if [[ -z "${BUILD_TRIPLET:-}" ]]; then
  if [[ -x ../$PATCH_PKG/config.guess ]]; then
    BUILD_TRIPLET="$(../$PATCH_PKG/config.guess)"
  elif [[ -x ../$PATCH_PKG/build-aux/config.guess ]]; then
    BUILD_TRIPLET="$(../$PATCH_PKG/build-aux/config.guess)"
  else
    BUILD_TRIPLET=""
  fi
fi

CONFIG_OPTS=(
  "--prefix=$TOOLS"
  "--disable-nls"
)

[[ -n "$BUILD_TRIPLET" ]] && CONFIG_OPTS+=("--build=$BUILD_TRIPLET")

../"$PATCH_PKG"/configure "${CONFIG_OPTS[@]}"

make -j"$JOBS"

if [[ "${PATCH_RUN_TESTS:-0}" == "1" ]]; then
  make check
fi

make install

echo "[patch] OK"
