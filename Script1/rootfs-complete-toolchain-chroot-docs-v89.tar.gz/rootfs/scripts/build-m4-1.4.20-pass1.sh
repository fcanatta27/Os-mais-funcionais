#!/usr/bin/env bash
# build-m4-1.4.20-pass1.sh
# Constrói o GNU M4 1.4.20 como ferramenta temporária em $ROOTFS/tools (pass1)
#
# Este M4 é usado como ferramenta do *host* para compilar outros pacotes
# (por exemplo, bison, autoconf, etc.), não faz parte do sistema final.

set -euo pipefail
trap 'echo "[m4] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-m4-1.4.20-pass1}
SRC_DIR=${SRC_DIR:-/tmp/sources}

M4_VERSION=${M4_VERSION:-1.4.20}
M4_PKG=${M4_PKG:-m4-"$M4_VERSION"}
M4_ARCHIVE=${M4_ARCHIVE:-"$SRC_DIR/$M4_PKG.tar.xz"}
M4_URL=${M4_URL:-"https://ftp.gnu.org/gnu/m4/$M4_PKG.tar.xz"}

JOBS=${JOBS:-"$(nproc)"}

export ROOTFS TOOLS TMP SRC_DIR M4_VERSION M4_PKG M4_ARCHIVE

###############################################################################
# Preparação de diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"

for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  if [[ ! -w "$d" ]]; then
    echo "[m4] ERRO: diretório '$d' não é gravável" >&2
    exit 1
  fi
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar make gcc; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[m4] ERRO: comando obrigatório não encontrado: $cmd" >&2
    exit 1
  fi
done

# Usa o prefixo de ferramentas temporárias na frente do PATH
export PATH="$TOOLS/bin:$PATH"

###############################################################################
# Obtenção do código-fonte
###############################################################################

if [[ ! -f "$M4_ARCHIVE" ]]; then
  echo "[m4] Baixando $M4_PKG de $M4_URL..."
  wget -O "$M4_ARCHIVE" "$M4_URL"
fi

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$M4_PKG" build-m4
tar -xf "$M4_ARCHIVE"

if [[ ! -d "$M4_PKG" ]]; then
  echo "[m4] ERRO: diretório de código-fonte $M4_PKG não encontrado após extração." >&2
  exit 1
fi

mkdir -p build-m4
cd build-m4

###############################################################################
# Configuração
###############################################################################

echo "[m4] Configurando (pass1)..."

# Triplet de build (host == build aqui, pois é ferramenta para o host)
if [[ -z "${BUILD_TRIPLET:-}" ]]; then
  if [[ -x "../$M4_PKG/build-aux/config.guess" ]]; then
    BUILD_TRIPLET="$(../"$M4_PKG"/build-aux/config.guess)"
  else
    BUILD_TRIPLET="$(../"$M4_PKG"/config.guess 2>/dev/null || true)"
  fi
fi

CONFIG_OPTS=(
  "--prefix=$TOOLS"
  "--disable-nls"
)

if [[ -n "${BUILD_TRIPLET:-}" ]]; then
  CONFIG_OPTS+=("--build=$BUILD_TRIPLET")
fi

../"$M4_PKG"/configure "${CONFIG_OPTS[@]}"

###############################################################################
# Compilação
###############################################################################

echo "[m4] Compilando (pass1) com $JOBS jobs..."
make -j"$JOBS"

###############################################################################
# Testes opcionais
###############################################################################

if [[ "${M4_RUN_TESTS:-0}" = "1" ]]; then
  echo "[m4] Executando 'make check' (isso pode ser demorado)..."
  make check
else
  echo "[m4] Pulando 'make check' (defina M4_RUN_TESTS=1 para executar testes)."
fi

###############################################################################
# Instalação
###############################################################################

echo "[m4] Instalando em $TOOLS..."
make install

echo "[m4] Concluído com sucesso."
