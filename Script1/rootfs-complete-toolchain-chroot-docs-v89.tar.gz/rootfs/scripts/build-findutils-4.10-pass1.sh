#!/usr/bin/env bash
# build-findutils-4.10-pass1.sh
# Constrói o GNU findutils 4.10 como ferramenta temporária em $ROOTFS/tools (pass1)
#
# Ferramenta do host usada durante a construção do sistema.

set -euo pipefail
trap 'echo "[findutils] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-findutils-4.10-pass1}
SRC_DIR=${SRC_DIR:-/tmp/sources}

FINDUTILS_VERSION=${FINDUTILS_VERSION:-4.10}
FINDUTILS_PKG=${FINDUTILS_PKG:-findutils-${FINDUTILS_VERSION}}
FINDUTILS_ARCHIVE=${FINDUTILS_ARCHIVE:-"$SRC_DIR/$FINDUTILS_PKG.tar.xz"}
FINDUTILS_URL=${FINDUTILS_URL:-"https://ftp.gnu.org/gnu/findutils/$FINDUTILS_PKG.tar.xz"}

JOBS=${JOBS:-"$(nproc)"}

export ROOTFS TOOLS TMP SRC_DIR FINDUTILS_VERSION FINDUTILS_PKG FINDUTILS_ARCHIVE

###############################################################################
# Diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"

for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  [[ -w "$d" ]] || { echo "[findutils] ERRO: '$d' não é gravável"; exit 1; }
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar make gcc; do
  command -v "$cmd" >/dev/null 2>&1 || {
    echo "[findutils] ERRO: comando não encontrado: $cmd"
    exit 1
  }
done

# Necessário se rodar como root
export FORCE_UNSAFE_CONFIGURE=1

export PATH="$TOOLS/bin:$PATH"

: "${CFLAGS:=-O2}"
: "${CXXFLAGS:=-O2}"
export CFLAGS CXXFLAGS

###############################################################################
# Código-fonte
###############################################################################

if [[ ! -f "$FINDUTILS_ARCHIVE" ]]; then
  wget -O "$FINDUTILS_ARCHIVE" "$FINDUTILS_URL"
fi

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$FINDUTILS_PKG" build-findutils
tar -xf "$FINDUTILS_ARCHIVE"

[[ -d "$FINDUTILS_PKG" ]] || {
  echo "[findutils] ERRO: diretório do código-fonte não encontrado"
  exit 1
}

mkdir build-findutils
cd build-findutils

###############################################################################
# Configuração
###############################################################################

if [[ -z "${BUILD_TRIPLET:-}" ]]; then
  if [[ -x "../$FINDUTILS_PKG/build-aux/config.guess" ]]; then
    BUILD_TRIPLET="$(../"$FINDUTILS_PKG"/build-aux/config.guess)"
  else
    BUILD_TRIPLET="$(../"$FINDUTILS_PKG"/config.guess 2>/dev/null || true)"
  fi
fi

LOCALSTATE_DIR="$TOOLS/var/lib/locate"

../"$FINDUTILS_PKG"/configure   --prefix="$TOOLS"   --disable-nls   --localstatedir="$LOCALSTATE_DIR"   ${BUILD_TRIPLET:+--build="$BUILD_TRIPLET"}

###############################################################################
# Build / Install
###############################################################################

make -j"$JOBS"
make install

echo "[findutils] OK"
