#!/usr/bin/env bash
    # build-toolchain-full.sh
    # Orquestra a construção completa do toolchain temporário em $ROOTFS/tools
    # Chamando todos os scripts de build na ordem correta, com suporte a retomada.
    #
    # Ordem (estilo LFS moderno):
    #   01 - Binutils  Pass 1
    #   02 - GCC       Pass 1
    #   03 - Linux API Headers
    #   04 - Glibc     Pass 1
    #   05 - M4        Pass 1
    #   06 - Ncurses   Pass 1
    #   07 - Bash      Pass 1
    #   08 - Coreutils Pass 1
    #   09 - Diffutils Pass 1
    #   10 - File      Pass 1
    #   11 - Findutils Pass 1
    #   12 - Gawk      Pass 1
    #   13 - Grep      Pass 1
    #   14 - Gzip      Pass 1
    #   15 - Make      Pass 1
    #   16 - Patch     Pass 1
    #   17 - Sed       Pass 1
    #   18 - Tar       Pass 1
    #   19 - Xz        Pass 1
    #   20 - Binutils  Pass 2
    #   21 - GCC       Pass 2

    set -euo pipefail
    trap 'echo "[toolchain] ERRO na linha ${LINENO}"; exit 1' ERR

    ###############################################################################
    # Configuração básica e diretórios
    ###############################################################################

    # ROOTFS padrão; pode ser sobrescrito pelo ambiente antes de chamar este script
    ROOTFS=${ROOTFS:-/tmp/rootfs}
    TOOLS=${TOOLS:-"$ROOTFS/tools"}
    SRC_DIR=${SRC_DIR:-/tmp/sources}

    # Diretório onde este script está; usamos como base para encontrar os demais
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    SCRIPTS_DIR=${SCRIPTS_DIR:-"$SCRIPT_DIR"}

    # Arquivo de estado para suporte à retomada
    STATE_DIR=${STATE_DIR:-"$ROOTFS/tools"}
    STATE_FILE="$STATE_DIR/.toolchain-full.state"

    mkdir -p "$ROOTFS" "$TOOLS" "$SRC_DIR" "$STATE_DIR"

    if [[ ! -d "$SCRIPTS_DIR" ]]; then
      echo "[toolchain][ERRO] Diretório de scripts não existe: $SCRIPTS_DIR" >&2
      exit 1
    fi

    ###############################################################################
    # Utilitários de log
    ###############################################################################

    log_info()  { printf '[toolchain] %s
' "$*" >&2; }
    log_error() { printf '[toolchain][ERRO] %s
' "$*" >&2; }

    ###############################################################################
    # Funções de estado (retomada)
    ###############################################################################

    mark_done() {
      local step_id="$1"
      # Usa || true para não acionar 'set -e' em caso de grep com saída != 0
      if ! grep -qxF "$step_id" "$STATE_FILE" 2>/dev/null; then
        echo "$step_id" >> "$STATE_FILE"
      fi
    }

    is_done() {
      local step_id="$1"
      # Retorna 0 se já concluído, 1 caso contrário, sem morrer por causa do 'set -e'
      grep -qxF "$step_id" "$STATE_FILE" 2>/dev/null || return 1
    }

    ###############################################################################
    # Função para executar um passo
    ###############################################################################

    run_step() {
      local step_id="$1"
      local description="$2"
      local script_name="$3"

      if is_done "$step_id"; then
        log_info "Passo $step_id já concluído: $description (pulando)"
        return 0
      fi

      local script_path="$SCRIPTS_DIR/$script_name"

      if [[ ! -x "$script_path" ]]; then
        if [[ -f "$script_path" ]]; then
          log_error "Script encontrado mas não executável: $script_path"
        else
          log_error "Script não encontrado: $script_path"
        fi
        exit 1
      fi

      log_info "Iniciando passo $step_id: $description"
      log_info "Script: $script_path"

      # Exporta variáveis-base para os scripts de build
      export ROOTFS TOOLS SRC_DIR

      # Executa o script no diretório onde ele está
      ( cd "$SCRIPTS_DIR" && "./$script_name" )

      mark_done "$step_id"
      log_info "Passo $step_id concluído: $description"
    }

    ###############################################################################
    # Verificações de ambiente mínimas
    ###############################################################################

    for cmd in bash mkdir grep; do
      if ! command -v "$cmd" >/dev/null 2>&1; then
        log_error "Comando obrigatório não encontrado no host: $cmd"
        exit 1
      fi
    done

    ###############################################################################
    # Definição da sequência de build
    ###############################################################################

    # Cada chamada: run_step "ID" "Descrição" "nome_do_script.sh"
    # Os nomes dos scripts precisam bater com os existentes em $SCRIPTS_DIR.

    run_step "01-binutils-pass1"   "Binutils 2.45.1 - Pass 1"          "build-binutils-2.45.1-pass1.sh"
    run_step "02-gcc-pass1"        "GCC 15.2.0 - Pass 1"               "build-gcc-15.2.0-pass1.sh"
    run_step "03-linux-headers"    "Linux API Headers 6.16.1"          "build-linux-headers-6.16.1.sh"
    run_step "04-glibc-pass1"      "Glibc - Pass 1"                    "build-glibc-pass1.sh"

    run_step "05-m4-pass1"         "M4 1.4.20 - Pass 1"                "build-m4-1.4.20-pass1.sh"
    run_step "06-ncurses-pass1"    "Ncurses 6.5 - Pass 1"              "build-ncurses-6.5-pass1.sh"
    run_step "07-bash-pass1"       "Bash 5.3 - Pass 1"                 "build-bash-5.3-pass1.sh"
    run_step "08-coreutils-pass1"  "Coreutils 9.7 - Pass 1"            "build-coreutils-9.7-pass1.sh"
    run_step "09-diffutils-pass1"  "Diffutils 3.12 - Pass 1"           "build-diffutils-3.12-pass1.sh"
    run_step "10-file-pass1"       "File 5.46 - Pass 1"                "build-file-5.46-pass1.sh"
    run_step "11-findutils-pass1"  "Findutils 4.10 - Pass 1"           "build-findutils-4.10-pass1.sh"
    run_step "12-gawk-pass1"       "Gawk 5.3.2 - Pass 1"               "build-gawk-5.3.2-pass1.sh"
    run_step "13-grep-pass1"       "Grep 3.12 - Pass 1"                "build-grep-3.12-pass1.sh"
    run_step "14-gzip-pass1"       "Gzip 1.14 - Pass 1"                "build-gzip-1.14-pass1.sh"
    run_step "15-make-pass1"       "Make 4.4.1 - Pass 1"               "build-make-4.4.1-pass1.sh"
    run_step "16-patch-pass1"      "Patch 2.8 - Pass 1"                "build-patch-2.8-pass1.sh"
    run_step "17-sed-pass1"        "Sed 4.9 - Pass 1"                  "build-sed-4.9-pass1.sh"
    run_step "18-tar-pass1"        "Tar 1.35 - Pass 1"                 "build-tar-1.35-pass1.sh"
    run_step "19-xz-pass1"         "XZ Utils 5.8.1 - Pass 1"           "build-xz-5.8.1-pass1.sh"

    run_step "20-binutils-pass2"   "Binutils 2.45.1 - Pass 2"          "build-binutils-2.45.1-pass2.sh"
    run_step "21-gcc-pass2"        "GCC 15.2.0 - Pass 2"               "build-gcc-15.2.0-pass2.sh"

    ###############################################################################
    # Fim
    ###############################################################################

    log_info "Toolchain completo construído com sucesso em $TOOLS"
    log_info "Arquivo de estado: $STATE_FILE"
