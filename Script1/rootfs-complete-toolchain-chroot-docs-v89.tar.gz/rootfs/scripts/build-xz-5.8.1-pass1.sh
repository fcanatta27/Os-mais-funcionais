#!/usr/bin/env bash
# build-xz-5.8.1-pass1.sh
# Constrói o XZ Utils 5.8.1 como ferramenta temporária em $ROOTFS/tools (pass1)
#
# Este xz é uma ferramenta do host, usada para (des)compactar arquivos .xz durante o build.

set -euo pipefail
trap 'echo "[xz] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-xz-5.8.1-pass1}
SRC_DIR=${SRC_DIR:-/tmp/sources}

XZ_VERSION=${XZ_VERSION:-5.8.1}
XZ_PKG=${XZ_PKG:-xz-"$XZ_VERSION"}
XZ_ARCHIVE=${XZ_ARCHIVE:-"$SRC_DIR/$XZ_PKG.tar.xz"}
XZ_URL=${XZ_URL:-"https://tukaani.org/xz/$XZ_PKG.tar.xz"}

export ROOTFS TOOLS TMP SRC_DIR XZ_VERSION XZ_PKG XZ_ARCHIVE

###############################################################################
# Preparação de diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"

for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  if [[ ! -w "$d" ]]; then
    echo "[xz] ERRO: diretório '$d' não é gravável" >&2
    exit 1
  fi
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar gcc make; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[xz] ERRO: comando obrigatório não encontrado: $cmd" >&2
    exit 1
  fi
done

# Determina número de jobs de forma segura
if [[ -z "${JOBS:-}" ]]; then
  if command -v nproc >/dev/null 2>&1; then
    JOBS="$(nproc)"
  else
    JOBS=1
  fi
fi

###############################################################################
# Ambiente de build
###############################################################################

# Muitos pacotes GNU reclamam se forem configurados como root sem isto
export FORCE_UNSAFE_CONFIGURE=1

# Usa o prefixo das ferramentas temporárias na frente do PATH
export PATH="$TOOLS/bin:$PATH"

# Flags padrão razoáveis; podem ser sobrescritas pelo ambiente
: "${CFLAGS:=-O2}"
: "${CXXFLAGS:=-O2}"
export CFLAGS CXXFLAGS

###############################################################################
# Obtenção do código-fonte
###############################################################################

if [[ ! -f "$XZ_ARCHIVE" ]]; then
  echo "[xz] Baixando $XZ_PKG de $XZ_URL..."
  wget -O "$XZ_ARCHIVE" "$XZ_URL"
fi

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$XZ_PKG" build-xz
tar -xf "$XZ_ARCHIVE"

if [[ ! -d "$XZ_PKG" ]]; then
  echo "[xz] ERRO: diretório de código-fonte $XZ_PKG não encontrado após extração." >&2
  exit 1
fi

mkdir -p build-xz
cd build-xz

###############################################################################
# Configuração
###############################################################################

echo "[xz] Configurando (pass1) para instalação em $TOOLS..."

# Triplet de build (host == build)
if [[ -z "${BUILD_TRIPLET:-}" ]]; then
  if [[ -x "../$XZ_PKG/build-aux/config.guess" ]]; then
    BUILD_TRIPLET="$(../"$XZ_PKG"/build-aux/config.guess)"
  else
    BUILD_TRIPLET="$(../"$XZ_PKG"/config.guess 2>/dev/null || true)"
  fi
fi

CONFIG_OPTS=(
  "--prefix=$TOOLS"
  "--disable-nls"
  "--disable-static"
)

if [[ -n "${BUILD_TRIPLET:-}" ]]; then
  CONFIG_OPTS+=("--build=$BUILD_TRIPLET")
fi

../"$XZ_PKG"/configure "${CONFIG_OPTS[@]}"

###############################################################################
# Compilação
###############################################################################

echo "[xz] Compilando (pass1) com $JOBS jobs..."
make -j"$JOBS"

###############################################################################
# Testes opcionais
###############################################################################

if [[ "${XZ_RUN_TESTS:-0}" = "1" ]]; then
  echo "[xz] Executando 'make check' (pode ser demorado)..."
  make check
else
  echo "[xz] Pulando 'make check' (defina XZ_RUN_TESTS=1 para executar testes)."
fi

###############################################################################
# Instalação
###############################################################################

echo "[xz] Instalando em $TOOLS..."
make install

echo "[xz] Concluído com sucesso."
