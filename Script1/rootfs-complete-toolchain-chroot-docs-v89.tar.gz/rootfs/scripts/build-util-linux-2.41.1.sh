#!/usr/bin/env bash
# build-util-linux-2.41.1.sh
# Constrói o Util-linux 2.41.1 dentro do sistema (fase chroot / ferramentas adicionais)
#
# Segue um esquema inspirado em LFS, desabilitando alguns utilitários que
# podem ser fornecidos por outros pacotes (shadow, etc.).

set -euo pipefail
trap 'echo "[util-linux] ERRO na linha ${LINENO}" >&2' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/}
DESTDIR=${DESTDIR:-"$ROOTFS"}
SRC_DIR=${SRC_DIR:-/tmp/sources}
TMP=${TMP:-/tmp/build-util-linux-2.41.1}

UTIL_LINUX_VERSION=${UTIL_LINUX_VERSION:-2.41.1}
UTIL_LINUX_PKG=${UTIL_LINUX_PKG:-util-linux-"$UTIL_LINUX_VERSION"}
UTIL_LINUX_ARCHIVE=${UTIL_LINUX_ARCHIVE:-"$SRC_DIR/$UTIL_LINUX_PKG.tar.xz"}
UTIL_LINUX_URL=${UTIL_LINUX_URL:-"https://www.kernel.org/pub/linux/utils/util-linux/v2.41/$UTIL_LINUX_PKG.tar.xz"}

export ROOTFS DESTDIR SRC_DIR TMP UTIL_LINUX_VERSION UTIL_LINUX_PKG UTIL_LINUX_ARCHIVE

###############################################################################
# Diretórios e verificações
###############################################################################

mkdir -p "$DESTDIR" "$SRC_DIR" "$TMP"

for d in "$DESTDIR" "$SRC_DIR" "$TMP"; do
  if [[ ! -d "$d" ]]; then
    echo "[util-linux] ERRO: diretório não encontrado: $d" >&2
    exit 1
  fi
  if [[ ! -w "$d" ]]; then
    echo "[util-linux] ERRO: diretório não é gravável: $d" >&2
    exit 1
  fi
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar gcc make pkg-config; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[util-linux] ERRO: comando obrigatório não encontrado: $cmd" >&2
    exit 1
  fi
done

if [[ -z "${JOBS:-}" ]]; then
  if command -v nproc >/dev/null 2>&1; then
    JOBS="$(nproc)"
  else
    JOBS=1
  fi
fi

###############################################################################
# Ambiente
###############################################################################

: "${CFLAGS:=-O2}"
: "${CXXFLAGS:=-O2}"
export CFLAGS CXXFLAGS

###############################################################################
# Obtenção do código-fonte
###############################################################################

if [[ ! -f "$UTIL_LINUX_ARCHIVE" ]]; then
  echo "[util-linux] Baixando $UTIL_LINUX_PKG de $UTIL_LINUX_URL..."
  mkdir -p "$SRC_DIR"
  wget -O "$UTIL_LINUX_ARCHIVE" "$UTIL_LINUX_URL"
fi

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$UTIL_LINUX_PKG" build-util-linux
tar -xf "$UTIL_LINUX_ARCHIVE"

if [[ ! -d "$UTIL_LINUX_PKG" ]]; then
  echo "[util-linux] ERRO: diretório de código-fonte $UTIL_LINUX_PKG não encontrado após extração." >&2
  exit 1
fi

mkdir -p build-util-linux
cd build-util-linux

###############################################################################
# Configuração
###############################################################################

echo "[util-linux] Configurando para prefix=/usr (DESTDIR=$DESTDIR)..."

../"$UTIL_LINUX_PKG"/configure       ADJTIME_PATH=/var/lib/hwclock/adjtime       --prefix=/usr       --docdir=/usr/share/doc/"$UTIL_LINUX_PKG"       --disable-chfn-chsh       --disable-login       --disable-nologin       --disable-su       --disable-setpriv       --disable-runuser       --disable-pylibmount       --disable-static       --without-python

###############################################################################
# Compilação
###############################################################################

echo "[util-linux] Compilando com $JOBS jobs..."
make -j"$JOBS"

###############################################################################
# Testes (opcionais)
###############################################################################

if [[ "${UTIL_LINUX_RUN_TESTS:-0}" = "1" ]]; then
  echo "[util-linux] Executando 'make check' (pode ser demorado)..."
  make check
else
  echo "[util-linux] Pulando 'make check' (defina UTIL_LINUX_RUN_TESTS=1 para executar testes)."
fi

###############################################################################
# Instalação
###############################################################################

echo "[util-linux] Instalando em $DESTDIR..."

# Garante diretório para o adjtime dentro de DESTDIR
mkdir -p "$DESTDIR/var/lib/hwclock"

make install DESTDIR="$DESTDIR"

echo "[util-linux] Concluído com sucesso."
