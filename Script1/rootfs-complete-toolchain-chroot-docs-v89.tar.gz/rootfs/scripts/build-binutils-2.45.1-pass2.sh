#!/usr/bin/env bash
# build-binutils-2.45.1-pass2.sh
# Constrói o GNU binutils 2.45.1 (Pass 2) como ferramenta temporária em $ROOTFS/tools
#
# Este binutils Pass 2 é construído usando o toolchain temporário e o sysroot em $ROOTFS,
# produzindo as ferramentas definitivas de assembler/linker para o target.

set -euo pipefail
trap 'echo "[binutils-pass2] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-binutils-2.45.1-pass2}
SRC_DIR=${SRC_DIR:-/tmp/sources}

BINUTILS_VERSION=${BINUTILS_VERSION:-2.45.1}
BINUTILS_PKG=${BINUTILS_PKG:-binutils-"$BINUTILS_VERSION"}
BINUTILS_ARCHIVE=${BINUTILS_ARCHIVE:-"$SRC_DIR/$BINUTILS_PKG.tar.xz"}
BINUTILS_URL=${BINUTILS_URL:-"https://ftp.gnu.org/gnu/binutils/$BINUTILS_PKG.tar.xz"}

TARGET=${TARGET:-x86_64-pc-linux-gnu}

export ROOTFS TOOLS TMP SRC_DIR BINUTILS_VERSION BINUTILS_PKG BINUTILS_ARCHIVE TARGET

###############################################################################
# Preparação de diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"

for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  if [[ ! -w "$d" ]]; then
    echo "[binutils-pass2] ERRO: diretório '$d' não é gravável" >&2
    exit 1
  fi
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar gcc make; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[binutils-pass2] ERRO: comando obrigatório não encontrado: $cmd" >&2
    exit 1
  fi
done

# Determina número de jobs de forma segura
if [[ -z "${JOBS:-}" ]]; then
  if command -v nproc >/dev/null 2>&1; then
    JOBS="$(nproc)"
  else
    JOBS=1
  fi
fi

###############################################################################
# Ambiente de build
###############################################################################

# Usa o toolchain temporário na frente do PATH
export PATH="$TOOLS/bin:$PATH"

# Muitos pacotes GNU reclamam se forem configurados como root sem isto
export FORCE_UNSAFE_CONFIGURE=1

: "${CFLAGS:=-O2}"
: "${CXXFLAGS:=-O2}"
export CFLAGS CXXFLAGS

###############################################################################
# Obtenção do código-fonte
###############################################################################

if [[ ! -f "$BINUTILS_ARCHIVE" ]]; then
  echo "[binutils-pass2] Baixando $BINUTILS_PKG de $BINUTILS_URL..."
  wget -O "$BINUTILS_ARCHIVE" "$BINUTILS_URL"
fi

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$BINUTILS_PKG" build-binutils-pass2
tar -xf "$BINUTILS_ARCHIVE"

if [[ ! -d "$BINUTILS_PKG" ]]; then
  echo "[binutils-pass2] ERRO: diretório de código-fonte $BINUTILS_PKG não encontrado após extração." >&2
  exit 1
fi

mkdir -p build-binutils-pass2
cd build-binutils-pass2

###############################################################################
# Configuração
###############################################################################

echo "[binutils-pass2] Configurando para target $TARGET e sysroot $ROOTFS..."

# Triplet de build (host == build)
if [[ -z "${BUILD_TRIPLET:-}" ]]; then
  if [[ -x "../$BINUTILS_PKG/build-aux/config.guess" ]]; then
    BUILD_TRIPLET="$(../"$BINUTILS_PKG"/build-aux/config.guess)"
  else
    BUILD_TRIPLET="$(../"$BINUTILS_PKG"/config.guess 2>/dev/null || true)"
  fi
fi

CONFIG_OPTS=(
  "--prefix=$TOOLS"
  "--with-sysroot=$ROOTFS"
  "--target=$TARGET"
  "--disable-nls"
  "--disable-werror"
)

if [[ -n "${BUILD_TRIPLET:-}" ]]; then
  CONFIG_OPTS+=("--build=$BUILD_TRIPLET")
fi

../"$BINUTILS_PKG"/configure "${CONFIG_OPTS[@]}"

###############################################################################
# Compilação
###############################################################################

echo "[binutils-pass2] Compilando com $JOBS jobs..."
make -j"$JOBS"

###############################################################################
# Testes opcionais
###############################################################################

if [[ "${BINUTILS_PASS2_RUN_TESTS:-0}" = "1" ]]; then
  echo "[binutils-pass2] Executando 'make check' (pode ser demorado)..."
  make check
else
  echo "[binutils-pass2] Pulando 'make check' (defina BINUTILS_PASS2_RUN_TESTS=1 para executar testes)."
fi

###############################################################################
# Instalação
###############################################################################

echo "[binutils-pass2] Instalando em $TOOLS..."
make install

echo "[binutils-pass2] Concluído com sucesso."
