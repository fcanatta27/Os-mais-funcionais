#!/usr/bin/env bash
# build-gzip-1.14-pass1.sh
# Constrói o GNU gzip 1.14 como ferramenta temporária em $ROOTFS/tools (pass1)

set -euo pipefail
trap 'echo "[gzip] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-gzip-1.14-pass1}
SRC_DIR=${SRC_DIR:-/tmp/sources}

GZIP_VERSION=${GZIP_VERSION:-1.14}
GZIP_PKG="gzip-${GZIP_VERSION}"
GZIP_ARCHIVE="$SRC_DIR/$GZIP_PKG.tar.xz"
GZIP_URL="https://ftp.gnu.org/gnu/gzip/$GZIP_PKG.tar.xz"

JOBS=${JOBS:-"$(nproc)"}

export ROOTFS TOOLS TMP SRC_DIR GZIP_VERSION GZIP_PKG GZIP_ARCHIVE

###############################################################################
# Diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"
for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  [[ -w "$d" ]] || { echo "[gzip] ERRO: $d não gravável"; exit 1; }
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar make gcc; do
  command -v "$cmd" >/dev/null 2>&1 || {
    echo "[gzip] ERRO: comando ausente: $cmd"; exit 1; }
done

export FORCE_UNSAFE_CONFIGURE=1
export PATH="$TOOLS/bin:$PATH"
: "${CFLAGS:=-O2}"
export CFLAGS

###############################################################################
# Fonte
###############################################################################

[[ -f "$GZIP_ARCHIVE" ]] || wget -O "$GZIP_ARCHIVE" "$GZIP_URL"

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$GZIP_PKG" build-gzip
tar -xf "$GZIP_ARCHIVE"
cd build-gzip || { mkdir build-gzip && cd build-gzip; }

###############################################################################
# Configuração
###############################################################################

BUILD_TRIPLET=${BUILD_TRIPLET:-"$(../$GZIP_PKG/build-aux/config.guess 2>/dev/null || ../$GZIP_PKG/config.guess)"}

../"$GZIP_PKG"/configure   --prefix="$TOOLS"   --disable-nls   --build="$BUILD_TRIPLET"

###############################################################################
# Build / install
###############################################################################

make -j"$JOBS"
make install
