#!/usr/bin/env bash
# build-diffutils-3.12-pass1.sh
# Ferramenta temporária (host) – instala em $ROOTFS/tools

set -euo pipefail
trap 'echo "[diffutils] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-diffutils-3.12-pass1}
SRC_DIR=${SRC_DIR:-/tmp/sources}

DIFFUTILS_VERSION=${DIFFUTILS_VERSION:-3.12}
DIFFUTILS_PKG=${DIFFUTILS_PKG:-diffutils-${DIFFUTILS_VERSION}}
DIFFUTILS_ARCHIVE=${DIFFUTILS_ARCHIVE:-"$SRC_DIR/$DIFFUTILS_PKG.tar.xz"}
DIFFUTILS_URL=${DIFFUTILS_URL:-"https://ftp.gnu.org/gnu/diffutils/$DIFFUTILS_PKG.tar.xz"}

JOBS=${JOBS:-"$(nproc)"}

export ROOTFS TOOLS TMP SRC_DIR DIFFUTILS_VERSION DIFFUTILS_PKG DIFFUTILS_ARCHIVE

###############################################################################
# Diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"
for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  [[ -w "$d" ]] || { echo "[diffutils] '$d' não é gravável"; exit 1; }
done

###############################################################################
# Dependências
###############################################################################

for cmd in wget tar make gcc; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "[diffutils] falta $cmd"; exit 1; }
done

export PATH="$TOOLS/bin:$PATH"

###############################################################################
# Download
###############################################################################

if [[ ! -f "$DIFFUTILS_ARCHIVE" ]]; then
  wget -O "$DIFFUTILS_ARCHIVE" "$DIFFUTILS_URL"
fi

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$DIFFUTILS_PKG" build
tar -xf "$DIFFUTILS_ARCHIVE"
[[ -d "$DIFFUTILS_PKG" ]] || { echo "[diffutils] fonte não encontrada"; exit 1; }

mkdir build && cd build

###############################################################################
# Configure
###############################################################################

if [[ -z "${BUILD_TRIPLET:-}" ]]; then
  if [[ -x "../$DIFFUTILS_PKG/build-aux/config.guess" ]]; then
    BUILD_TRIPLET="$(../"$DIFFUTILS_PKG"/build-aux/config.guess)"
  else
    BUILD_TRIPLET="$(../"$DIFFUTILS_PKG"/config.guess 2>/dev/null || true)"
  fi
fi

CONFIG_OPTS=(
  "--prefix=$TOOLS"
  "--disable-nls"
)

[[ -n "${BUILD_TRIPLET:-}" ]] && CONFIG_OPTS+=("--build=$BUILD_TRIPLET")

../"$DIFFUTILS_PKG"/configure "${CONFIG_OPTS[@]}"

###############################################################################
# Build / Install
###############################################################################

make -j"$JOBS"
make install

echo "[diffutils] OK"
