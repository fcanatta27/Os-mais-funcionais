#!/usr/bin/env bash
# build-ncurses-6.5-pass1.sh
# Constrói o ncurses 6.5 como biblioteca/ferramenta temporária em $ROOTFS/tools
#
# Esta build é para o host (não target), para suportar programas interativos
# e dependências de outros pacotes durante a construção do sistema.

set -euo pipefail
trap 'echo "[ncurses] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-ncurses-6.5-pass1}
SRC_DIR=${SRC_DIR:-/tmp/sources}

NCURSES_VERSION=${NCURSES_VERSION:-6.5}
NCURSES_PKG=${NCURSES_PKG:-ncurses-"$NCURSES_VERSION"}
NCURSES_ARCHIVE=${NCURSES_ARCHIVE:-"$SRC_DIR/$NCURSES_PKG.tar.gz"}
NCURSES_URL=${NCURSES_URL:-"https://ftp.gnu.org/gnu/ncurses/$NCURSES_PKG.tar.gz"}

JOBS=${JOBS:-"$(nproc)"}

export ROOTFS TOOLS TMP SRC_DIR NCURSES_VERSION NCURSES_PKG NCURSES_ARCHIVE

###############################################################################
# Preparação de diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"

for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  if [[ ! -w "$d" ]]; then
    echo "[ncurses] ERRO: diretório '$d' não é gravável" >&2
    exit 1
  fi
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar make gcc; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[ncurses] ERRO: comando obrigatório não encontrado: $cmd" >&2
    exit 1
  fi
done

# Coloca o prefixo das ferramentas temporárias na frente do PATH
export PATH="$TOOLS/bin:$PATH"

###############################################################################
# Obtenção do código-fonte
###############################################################################

if [[ ! -f "$NCURSES_ARCHIVE" ]]; then
  echo "[ncurses] Baixando $NCURSES_PKG de $NCURSES_URL..."
  wget -O "$NCURSES_ARCHIVE" "$NCURSES_URL"
fi

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$NCURSES_PKG" build-ncurses
tar -xf "$NCURSES_ARCHIVE"

if [[ ! -d "$NCURSES_PKG" ]]; then
  echo "[ncurses] ERRO: diretório de código-fonte $NCURSES_PKG não encontrado após extração." >&2
  exit 1
fi

mkdir -p build-ncurses
cd build-ncurses

###############################################################################
# Configuração
###############################################################################

echo "[ncurses] Configurando (pass1) para instalação em $TOOLS..."

# Triplet de build (ncurses aqui é uma lib para o host, não cross-target)
if [[ -z "${BUILD_TRIPLET:-}" ]]; then
  BUILD_TRIPLET="$(../"$NCURSES_PKG"/config.guess 2>/dev/null || true)"
fi

CONFIG_OPTS=(
  "--prefix=$TOOLS"
  "--with-shared"
  "--without-debug"
  "--without-ada"
  "--enable-widec"
  "--disable-stripping"
)

if [[ -n "${BUILD_TRIPLET:-}" ]]; then
  CONFIG_OPTS+=("--build=$BUILD_TRIPLET")
fi

../"$NCURSES_PKG"/configure "${CONFIG_OPTS[@]}"

###############################################################################
# Compilação
###############################################################################

echo "[ncurses] Compilando (pass1) com $JOBS jobs..."
make -j"$JOBS"

###############################################################################
# Testes opcionais
###############################################################################

if [[ "${NCURSES_RUN_TESTS:-0}" = "1" ]]; then
  echo "[ncurses] Executando 'make check' (pode ser demorado e requer ambiente interativo)..."
  make check
else
  echo "[ncurses] Pulando 'make check' (defina NCURSES_RUN_TESTS=1 para executar testes)."
fi

###############################################################################
# Instalação
###############################################################################

echo "[ncurses] Instalando em $TOOLS..."
make install

echo "[ncurses] Concluído com sucesso."
