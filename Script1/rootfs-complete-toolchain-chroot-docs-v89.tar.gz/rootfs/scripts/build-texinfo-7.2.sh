#!/usr/bin/env bash
# build-texinfo-7.2.sh
# Constrói o Texinfo 7.2 dentro do sistema (fase chroot / ferramentas adicionais)

set -euo pipefail
trap 'echo "[texinfo] ERRO na linha ${LINENO}" >&2' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/}
DESTDIR=${DESTDIR:-"$ROOTFS"}
SRC_DIR=${SRC_DIR:-/tmp/sources}
TMP=${TMP:-/tmp/build-texinfo-7.2}

TEXINFO_VERSION=${TEXINFO_VERSION:-7.2}
TEXINFO_PKG=${TEXINFO_PKG:-texinfo-"$TEXINFO_VERSION"}
TEXINFO_ARCHIVE=${TEXINFO_ARCHIVE:-"$SRC_DIR/$TEXINFO_PKG.tar.xz"}
TEXINFO_URL=${TEXINFO_URL:-"https://ftp.gnu.org/gnu/texinfo/$TEXINFO_PKG.tar.xz"}

export ROOTFS DESTDIR SRC_DIR TMP TEXINFO_VERSION TEXINFO_PKG TEXINFO_ARCHIVE

###############################################################################
# Diretórios e verificações
###############################################################################

mkdir -p "$DESTDIR" "$SRC_DIR" "$TMP"

for d in "$DESTDIR" "$SRC_DIR" "$TMP"; do
  if [[ ! -d "$d" ]]; then
    echo "[texinfo] ERRO: diretório não encontrado: $d" >&2
    exit 1
  fi
  if [[ ! -w "$d" ]]; then
    echo "[texinfo] ERRO: diretório não é gravável: $d" >&2
    exit 1
  fi
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar gcc make; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[texinfo] ERRO: comando obrigatório não encontrado: $cmd" >&2
    exit 1
  fi
done

if [[ -z "${JOBS:-}" ]]; then
  if command -v nproc >/dev/null 2>&1; then
    JOBS="$(nproc)"
  else
    JOBS=1
  fi
fi

###############################################################################
# Ambiente
###############################################################################

: "${CFLAGS:=-O2}"
: "${CXXFLAGS:=-O2}"
export CFLAGS CXXFLAGS

###############################################################################
# Obtenção do código-fonte
###############################################################################

if [[ ! -f "$TEXINFO_ARCHIVE" ]]; then
  echo "[texinfo] Baixando $TEXINFO_PKG de $TEXINFO_URL..."
  mkdir -p "$SRC_DIR"
  wget -O "$TEXINFO_ARCHIVE" "$TEXINFO_URL"
fi

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$TEXINFO_PKG" build-texinfo
tar -xf "$TEXINFO_ARCHIVE"

if [[ ! -d "$TEXINFO_PKG" ]]; then
  echo "[texinfo] ERRO: diretório de código-fonte $TEXINFO_PKG não encontrado após extração." >&2
  exit 1
fi

mkdir -p build-texinfo
cd build-texinfo

###############################################################################
# Configuração
###############################################################################

echo "[texinfo] Configurando para prefix=/usr (DESTDIR=$DESTDIR)..."

../"$TEXINFO_PKG"/configure       --prefix=/usr       --disable-static

###############################################################################
# Compilação
###############################################################################

echo "[texinfo] Compilando com $JOBS jobs..."
make -j"$JOBS"

###############################################################################
# Testes (opcionais)
###############################################################################

if [[ "${TEXINFO_RUN_TESTS:-0}" = "1" ]]; then
  echo "[texinfo] Executando 'make check' (pode ser demorado)..."
  make check
else
  echo "[texinfo] Pulando 'make check' (defina TEXINFO_RUN_TESTS=1 para executar testes)."
fi

###############################################################################
# Instalação
###############################################################################

echo "[texinfo] Instalando em $DESTDIR..."
make install DESTDIR="$DESTDIR"

echo "[texinfo] Concluído com sucesso."
