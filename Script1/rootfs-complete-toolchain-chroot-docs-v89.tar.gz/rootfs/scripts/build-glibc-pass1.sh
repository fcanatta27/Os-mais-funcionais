#!/usr/bin/env bash
# build-glibc-pass1.sh
# Primeiro build da glibc (pass1) para o sysroot em $ROOTFS usando o toolchain em $TOOLS.
#
# Este script assume que:
#   - você já tem um toolchain mínimo (binutils + gcc pass1) instalado em $TOOLS
#   - os Linux API headers já estão instalados em $ROOTFS/usr/include

set -euo pipefail
trap 'echo "[glibc] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-glibc-pass1}
SRC_DIR=${SRC_DIR:-/tmp/sources}

TARGET=${TARGET:-x86_64-pc-linux-gnu}

# Versão padrão razoavelmente recente da glibc
GLIBC_VERSION=${GLIBC_VERSION:-2.43}
GLIBC_PKG=${GLIBC_PKG:-glibc-"$GLIBC_VERSION"}
GLIBC_ARCHIVE=${GLIBC_ARCHIVE:-"$SRC_DIR/$GLIBC_PKG.tar.xz"}
GLIBC_URL=${GLIBC_URL:-"https://ftp.gnu.org/gnu/glibc/$GLIBC_PKG.tar.xz"}

JOBS=${JOBS:-"$(nproc)"}

export ROOTFS TOOLS TMP SRC_DIR TARGET GLIBC_VERSION GLIBC_PKG GLIBC_ARCHIVE

###############################################################################
# Verificações iniciais
###############################################################################

# Diretórios básicos
mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"

for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  if [[ ! -w "$d" ]]; then
    echo "[glibc] ERRO: diretório '$d' não é gravável" >&2
    exit 1
  fi
done

# Dependências mínimas do host
for cmd in wget tar make gcc; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[glibc] ERRO: comando obrigatório não encontrado no host: $cmd" >&2
    exit 1
  fi
done

# Usar o toolchain recém-criado em $TOOLS na frente do PATH
export PATH="$TOOLS/bin:$PATH"

# Verificar se o cross-compiler alvo existe
if ! command -v "$TARGET-gcc" >/dev/null 2>&1; then
  echo "[glibc] ERRO: compilador alvo não encontrado: $TARGET-gcc (espere encontrá-lo em $TOOLS/bin)" >&2
  exit 1
fi

# Verificar se os Linux API headers já estão instalados
if [[ ! -d "$ROOTFS/usr/include" ]] || [[ ! -f "$ROOTFS/usr/include/linux/version.h" ]]; then
  echo "[glibc] ERRO: Linux API headers não encontrados em $ROOTFS/usr/include."
  echo "[glibc]       Rode o script de linux headers antes deste (build-linux-headers-6.16.1.sh)."
  exit 1
fi

###############################################################################
# Obtenção do código-fonte da glibc
###############################################################################

if [[ ! -f "$GLIBC_ARCHIVE" ]]; then
  echo "[glibc] Baixando $GLIBC_PKG de $GLIBC_URL..."
  wget -O "$GLIBC_ARCHIVE" "$GLIBC_URL"
fi

###############################################################################
# Extração e preparação
###############################################################################

cd "$TMP"
rm -rf "$GLIBC_PKG" build-glibc
tar -xf "$GLIBC_ARCHIVE"

if [[ ! -d "$GLIBC_PKG" ]]; then
  echo "[glibc] ERRO: diretório de código-fonte $GLIBC_PKG não encontrado após extração." >&2
  exit 1
fi

mkdir -p build-glibc
cd build-glibc

###############################################################################
# Configuração
###############################################################################

echo "[glibc] Configurando (pass1)..."

# Descobrir triplet de build se não fornecido
if [[ -z "${BUILD_TRIPLET:-}" ]]; then
  BUILD_TRIPLET="$(../"$GLIBC_PKG"/scripts/config.guess)"
fi

export BUILD_TRIPLET
export CC="$TARGET-gcc"
export CXX="$TARGET-g++"

# Opcionalmente você pode ajustar CFLAGS/CXXFLAGS se quiser algo mais otimizado
: "${CFLAGS:=-O2}"
: "${CXXFLAGS:=-O2}"
export CFLAGS CXXFLAGS

../"$GLIBC_PKG"/configure       --prefix=/usr       --host="$TARGET"       --build="$BUILD_TRIPLET"       --with-headers="$ROOTFS/usr/include"       --enable-kernel=5.4       --enable-stack-protector=strong       --disable-werror       libc_cv_slibdir=/usr/lib

###############################################################################
# Compilação
###############################################################################

echo "[glibc] Compilando (pass1) com $JOBS jobs..."
make -j"$JOBS"

###############################################################################
# Instalação em $ROOTFS (sysroot)
###############################################################################

echo "[glibc] Instalando em sysroot $ROOTFS..."
make DESTDIR="$ROOTFS" install

echo "[glibc] Concluído com sucesso."
