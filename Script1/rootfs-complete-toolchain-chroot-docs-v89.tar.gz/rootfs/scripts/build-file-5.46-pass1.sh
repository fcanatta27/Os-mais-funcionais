#!/usr/bin/env bash
# build-file-5.46-pass1.sh
# Ferramenta temporária (host) – instala em $ROOTFS/tools

set -euo pipefail
trap 'echo "[file] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-file-5.46-pass1}
SRC_DIR=${SRC_DIR:-/tmp/sources}

FILE_VERSION=${FILE_VERSION:-5.46}
FILE_PKG=${FILE_PKG:-file-${FILE_VERSION}}
FILE_ARCHIVE=${FILE_ARCHIVE:-"$SRC_DIR/$FILE_PKG.tar.gz"}
FILE_URL=${FILE_URL:-"https://astron.com/pub/file/$FILE_PKG.tar.gz"}

JOBS=${JOBS:-"$(nproc)"}

export ROOTFS TOOLS TMP SRC_DIR FILE_VERSION FILE_PKG FILE_ARCHIVE

###############################################################################
# Diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"
for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  [[ -w "$d" ]] || { echo "[file] '$d' não é gravável"; exit 1; }
done

###############################################################################
# Dependências
###############################################################################

for cmd in wget tar make gcc; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "[file] falta $cmd"; exit 1; }
done

export PATH="$TOOLS/bin:$PATH"

###############################################################################
# Download
###############################################################################

if [[ ! -f "$FILE_ARCHIVE" ]]; then
  wget -O "$FILE_ARCHIVE" "$FILE_URL"
fi

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$FILE_PKG" build
tar -xf "$FILE_ARCHIVE"
[[ -d "$FILE_PKG" ]] || { echo "[file] fonte não encontrada"; exit 1; }

mkdir build && cd build

###############################################################################
# Configure
###############################################################################

if [[ -z "${BUILD_TRIPLET:-}" ]]; then
  if [[ -x "../$FILE_PKG/build-aux/config.guess" ]]; then
    BUILD_TRIPLET="$(../"$FILE_PKG"/build-aux/config.guess)"
  else
    BUILD_TRIPLET="$(../"$FILE_PKG"/config.guess 2>/dev/null || true)"
  fi
fi

CONFIG_OPTS=(
  "--prefix=$TOOLS"
  "--disable-nls"
)

[[ -n "${BUILD_TRIPLET:-}" ]] && CONFIG_OPTS+=("--build=$BUILD_TRIPLET")

../"$FILE_PKG"/configure "${CONFIG_OPTS[@]}"

###############################################################################
# Build / Install
###############################################################################

make -j"$JOBS"
make install

echo "[file] OK"
