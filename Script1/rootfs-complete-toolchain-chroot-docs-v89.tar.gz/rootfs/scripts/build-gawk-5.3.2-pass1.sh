#!/usr/bin/env bash
# build-gawk-5.3.2-pass1.sh
# Constrói o GNU gawk 5.3.2 como ferramenta temporária em $ROOTFS/tools (pass1)

set -euo pipefail
trap 'echo "[gawk] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-gawk-5.3.2-pass1}
SRC_DIR=${SRC_DIR:-/tmp/sources}

GAWK_VERSION=${GAWK_VERSION:-5.3.2}
GAWK_PKG=${GAWK_PKG:-gawk-${GAWK_VERSION}}
GAWK_ARCHIVE=${GAWK_ARCHIVE:-"$SRC_DIR/$GAWK_PKG.tar.xz"}
GAWK_URL=${GAWK_URL:-"https://ftp.gnu.org/gnu/gawk/$GAWK_PKG.tar.xz"}

JOBS=${JOBS:-"$(nproc)"}

export ROOTFS TOOLS TMP SRC_DIR GAWK_VERSION GAWK_PKG GAWK_ARCHIVE

###############################################################################
# Diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"

for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  [[ -w "$d" ]] || { echo "[gawk] ERRO: '$d' não é gravável"; exit 1; }
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar make gcc; do
  command -v "$cmd" >/dev/null 2>&1 || {
    echo "[gawk] ERRO: comando não encontrado: $cmd"
    exit 1
  }
done

export PATH="$TOOLS/bin:$PATH"

: "${CFLAGS:=-O2}"
: "${CXXFLAGS:=-O2}"
export CFLAGS CXXFLAGS

###############################################################################
# Código-fonte
###############################################################################

if [[ ! -f "$GAWK_ARCHIVE" ]]; then
  wget -O "$GAWK_ARCHIVE" "$GAWK_URL"
fi

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$GAWK_PKG" build-gawk
tar -xf "$GAWK_ARCHIVE"

[[ -d "$GAWK_PKG" ]] || {
  echo "[gawk] ERRO: diretório do código-fonte não encontrado"
  exit 1
}

mkdir build-gawk
cd build-gawk

###############################################################################
# Configuração
###############################################################################

if [[ -z "${BUILD_TRIPLET:-}" ]]; then
  if [[ -x "../$GAWK_PKG/build-aux/config.guess" ]]; then
    BUILD_TRIPLET="$(../"$GAWK_PKG"/build-aux/config.guess)"
  else
    BUILD_TRIPLET="$(../"$GAWK_PKG"/config.guess 2>/dev/null || true)"
  fi
fi

../"$GAWK_PKG"/configure   --prefix="$TOOLS"   --disable-nls   ${BUILD_TRIPLET:+--build="$BUILD_TRIPLET"}

###############################################################################
# Build / Install
###############################################################################

make -j"$JOBS"
make install

echo "[gawk] OK"
