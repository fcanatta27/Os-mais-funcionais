name=dejagnu
version=1.6.3

source="dejagnu-{version}.tar.gz::https://ftp.gnu.org/gnu/dejagnu/dejagnu-{version}.tar.gz"
sha256="-"

deps=(expect tcl)

build() {
  set -euo pipefail
  : "${DESTDIR:?}" "${TMP:?}"

  local src="$PWD"
  local build="$TMP/${name}-${version}-build"
  rm -rf "$build"
  mkdir -p "$build"
  cd "$build"

  "$src/configure" \
    --prefix=/usr \
    --sysconfdir=/etc

  make -j"${JOBS:-1}"

  if [[ "${DEJAGNU_RUN_TESTS:-0}" = 1 ]]; then
    make check || echo "[spm:dejagnu][WARN] testes falharam"
  fi

  make install DESTDIR="$DESTDIR"
}

post_install() { :; }
