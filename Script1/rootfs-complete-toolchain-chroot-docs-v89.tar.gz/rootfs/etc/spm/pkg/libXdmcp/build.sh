name=libXdmcp
version=1.1.5

source="\
  libXdmcp-{version}.tar.xz::https://www.x.org/pub/individual/lib/libXdmcp-{version}.tar.xz \
"

sha256="\
  <sha256-libXdmcp-{version}.tar.xz> \
"

deps=(glibc xorgproto)

build() {
  set -euo pipefail
  cd libXdmcp-${version}

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libXdmcp*.la' -delete 2>/dev/null || true
}

post_install() {
  ls /usr/lib/libXdmcp* 2>/dev/null || true
}
