name=transset
version=1.0.3

source="\
  transset-{version}.tar.xz::https://www.x.org/releases/individual/app/transset-{version}.tar.xz \
"

sha256="\
  <sha256-transset-{version}.tar.xz> \
"

# Utilitário para ajustar transparência de janelas sob X11 + compositor.
deps=(glibc libX11 libXcomposite libXdamage libXfixes xorgproto)

build() {
  set -euo pipefail

  if [[ -d transset-${version} ]]; then
    cd transset-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  command -v transset >/dev/null 2>&1 || true
}
