name=showfont
version=1.0.6

source="\
  showfont-{version}.tar.xz::https://www.x.org/releases/individual/app/showfont-{version}.tar.xz \
"

sha256="\
  <sha256-showfont-{version}.tar.xz> \
"

# Utilitário para listar glifos de fontes X.
deps=(glibc libX11 libXaw libXt libXmu xorgproto)

build() {
  set -euo pipefail

  if [[ -d showfont-${version} ]]; then
    cd showfont-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  command -v showfont >/dev/null 2>&1 || true
}
