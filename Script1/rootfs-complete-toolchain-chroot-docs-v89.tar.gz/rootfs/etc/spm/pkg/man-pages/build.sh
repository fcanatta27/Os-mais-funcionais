# Definição de pacote SPM para man-pages (páginas de manual do sistema)
name=man-pages
version=6.15

# Tarball oficial das man-pages
source="man-pages-{version}.tar.xz::https://www.kernel.org/pub/linux/docs/man-pages/man-pages-{version}.tar.xz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' enquanto não tiver o hash real.
sha256="-"

# As man-pages assumem um userland com glibc (ou libc equivalente)
deps=(glibc)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  # Diretório do código-fonte (SPM já entrou no diretório extraído)
  local srcdir="$PWD"

  # Para man-pages, não é necessário build out-of-tree; o Makefile trabalha diretamente no srcdir.
  echo "[spm:man-pages] Instalando páginas de manual em DESTDIR=${DESTDIR}..."

  # Algumas distribuições exportam MANCONF/MANPATH, mas aqui controlamos via prefix/DESTDIR.
  make -C "$srcdir" prefix=/usr DESTDIR="$DESTDIR" install

  # Nenhum artefato de build pesado é gerado, só cópia de arquivos.
  echo "[spm:man-pages] Instalação concluída."
}

post_install() {
  # Hook opcional após instalação das man-pages.
  # Poderia, por exemplo, atualizar index de whatis/man-db se estiver disponível.
  #
  # if command -v mandb >/dev/null 2>&1; then
  #   echo "[spm:man-pages] Atualizando banco de dados de man-db (mandb)..."
  #   mandb || echo "[spm:man-pages][WARN] mandb retornou erro."
  # fi
  :
}
