# Definição de pacote SPM para libffi (biblioteca de chamadas de função em tempo de execução)
name=libffi
version=3.5.2

# Tarball oficial do libffi
source="libffi-{version}.tar.gz::https://github.com/libffi/libffi/releases/download/v{version}/libffi-{version}.tar.gz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
sha256="-"

deps=(glibc)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:libffi] Configurando libffi-${version}..."
  "$srcdir/configure" \
    --prefix=/usr \
    --disable-static \
    --libdir=/usr/lib

  echo "[spm:libffi] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  if [[ "${LIBFFI_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:libffi] Executando 'make check' (pode ser demorado)..."
    make check || echo "[spm:libffi][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:libffi] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  echo "[spm:libffi] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do libffi.
  :
}
