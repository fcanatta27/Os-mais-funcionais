name=libunistring
version=1.2

source="\
  libunistring-{version}.tar.xz::https://ftp.gnu.org/gnu/libunistring/libunistring-{version}.tar.xz \
"

sha256="\
  <sha256-libunistring-{version}.tar.xz> \
"

deps=(glibc)

build() {
  set -euo pipefail
  cd libunistring-${version}

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name '*.la' -delete 2>/dev/null || true
}

post_install() {
  pkg-config --modversion libunistring 2>/dev/null || true
}
