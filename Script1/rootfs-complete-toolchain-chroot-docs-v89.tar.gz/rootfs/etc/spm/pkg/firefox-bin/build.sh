name=firefox-bin
version=147.0.1

source="\
  firefox-{version}.tar.bz2::https://download-installer.cdn.mozilla.net/pub/firefox/releases/{version}/linux-x86_64/en-US/firefox-{version}.tar.bz2 \
"

sha256="\
  <sha256-firefox-{version}.tar.bz2> \
"

# Firefox binário oficial da Mozilla (pré-compilado).
deps=(glibc gtk3 pango cairo dbus libX11 libXrender libXrandr libxcb alsa-lib)

build() {
  set -euo pipefail

  if [[ -d firefox-{version} ]]; then
    cd firefox-{version}
  fi

  mkdir -p "${DESTDIR}/usr/lib/firefox-bin"
  mkdir -p "${DESTDIR}/usr/bin"

  tar -xf firefox-{version}.tar.bz2 -C "${DESTDIR}/usr/lib/firefox-bin" --strip-components=1

  cat > "${DESTDIR}/usr/bin/firefox-bin" << 'EOF'
#!/bin/sh
exec /usr/lib/firefox-bin/firefox "$@"
EOF
  chmod +x "${DESTDIR}/usr/bin/firefox-bin"
}

post_install() {
  :
}
