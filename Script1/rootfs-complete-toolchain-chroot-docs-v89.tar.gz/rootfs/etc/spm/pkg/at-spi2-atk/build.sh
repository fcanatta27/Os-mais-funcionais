name=at-spi2-atk
version=2.38.0

source="\
  at-spi2-atk-{version}.tar.xz::https://download.gnome.org/sources/at-spi2-atk/2.38/at-spi2-atk-{version}.tar.xz \
"

sha256="\
  <sha256-at-spi2-atk-{version}.tar.xz> \
"

# Bridge entre ATK e AT-SPI.
deps=(glib2 at-spi2-core)

build() {
  set -euo pipefail

  if [[ -d at-spi2-atk-${version} ]]; then
    cd at-spi2-atk-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
