name=libtool
version=2.5.4
source="libtool-{version}.tar.xz::https://ftp.gnu.org/gnu/libtool/libtool-{version}.tar.xz"
sha256="-"
deps=(glibc m4)

build() {
  set -euo pipefail
  : "${DESTDIR:?}" "${TMP:?}"
  local src="$PWD"
  local b="$TMP/${name}-${version}-build"
  rm -rf "$b"; mkdir -p "$b"; cd "$b"

  "$src/configure" \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  [[ "${LIBTOOL_RUN_TESTS:-0}" == 1 ]] && make check || true
  make install DESTDIR="$DESTDIR"
}
