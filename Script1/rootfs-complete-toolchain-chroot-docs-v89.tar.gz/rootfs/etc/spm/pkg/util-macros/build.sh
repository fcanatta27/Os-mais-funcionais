name=util-macros
version=1.20.2

source="\
  util-macros-{version}.tar.xz::https://www.x.org/pub/individual/util/util-macros-{version}.tar.xz \
"

sha256="\
  <sha256-util-macros-{version}.tar.xz> \
"

deps=(glibc)

build() {
  set -euo pipefail
  cd util-macros-${version}

  ./configure --prefix=/usr
  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() { :; }
