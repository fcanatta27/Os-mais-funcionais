name=xinit
version=1.4.4

source="\
  xinit-{version}.tar.xz::https://www.x.org/releases/individual/app/xinit-{version}.tar.xz \
"

sha256="\
  <sha256-xinit-{version}.tar.xz> \
"

# Ferramenta para iniciar sessão X (startx/xinit).
deps=(glibc xorg-server libX11 libXau libXdmcp xorgproto)

build() {
  set -euo pipefail

  if [[ -d xinit-${version} ]]; then
    cd xinit-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --with-xinitdir=/etc/X11/xinit \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  # Você pode customizar /etc/X11/xinit/xinitrc depois para chamar twm + xterm.
}

post_install() {
  command -v startx >/dev/null 2>&1 || true
}
