# Definição de pacote SPM para bc (bc moderno de Gavin Howard)
name=bc
version=7.0.3

# Tarball oficial do bc moderno
source="bc-{version}.tar.xz::https://github.com/gavinhoward/bc/releases/download/{version}/bc-{version}.tar.xz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' enquanto não tiver o hash real.
sha256="-"

# bc precisa de glibc e de um shell e toolchain funcionais;
# opcionalmente pode depender de readline para interface mais amigável.
deps=(glibc readline)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:bc] Configurando bc-${version}..."
  # O script configure.sh do bc moderno aceita diversas opções.
  # Usamos -G para usar a biblioteca GNU bc, -O3 para otimização
  # e --prefix=/usr para instalação.
  CC=${CC:-gcc} \
  CFLAGS="${CFLAGS:--O2}" \
  "$srcdir/configure.sh" -G -O3 --prefix=/usr

  echo "[spm:bc] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  # Testes opcionais
  if [[ "${BC_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:bc] Executando 'make test'..."
    make test || echo "[spm:bc][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:bc] Instalando em DESTDIR=${DESTDIR}..."
  make DESTDIR="$DESTDIR" install

  echo "[spm:bc] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do bc.
  :
}
