name=noto-fonts
version=2024.02.01

source="Noto-fonts.tar.gz::https://github.com/notofonts/notofonts.github.io/archive/refs/tags/{version}.tar.gz"
sha256="<sha256-noto-fonts>"

deps=()

build() {
  set -euo pipefail
  cd notofonts.github.io-${version}

  install -d "${DESTDIR}/usr/share/fonts/noto"
  find fonts -type f -name '*.ttf' -exec install -m644 {} "${DESTDIR}/usr/share/fonts/noto/" \;
}
