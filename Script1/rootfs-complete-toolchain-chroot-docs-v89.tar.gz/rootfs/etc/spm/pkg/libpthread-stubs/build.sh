name=libpthread-stubs
version=0.5

source="\
  libpthread-stubs-{version}.tar.xz::https://xcb.freedesktop.org/dist/libpthread-stubs-{version}.tar.xz \
"

sha256="\
  <sha256-libpthread-stubs-{version}.tar.xz> \
"

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d libpthread-stubs-${version} ]]; then
    cd libpthread-stubs-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
