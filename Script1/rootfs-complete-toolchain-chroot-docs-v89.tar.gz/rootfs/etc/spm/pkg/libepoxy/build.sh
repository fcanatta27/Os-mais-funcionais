name=libepoxy
version=1.5.10

source="\
  libepoxy-{version}.tar.xz::https://download.gnome.org/sources/libepoxy/1.5/libepoxy-{version}.tar.xz \
"

sha256="\
  <sha256-libepoxy-{version}.tar.xz> \
"

# Biblioteca de abstração de OpenGL usada por GTK4.
deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d libepoxy-${version} ]]; then
    cd libepoxy-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  :
}
