name=coreutils
version=9.7

source="\
  coreutils-{version}.tar.xz::https://ftp.gnu.org/gnu/coreutils/coreutils-{version}.tar.xz \
"

# Use 'spm checksum coreutils' para preencher corretamente
sha256="\
  <sha256-coreutils-{version}.tar.xz> \
"

# Dependências principais (podem ser ajustadas conforme o seu universo de pacotes)
deps=(glibc attr acl libcap)

build() {
  set -euo pipefail

  # Garante que estamos no diretório do código-fonte
  if [[ -d coreutils-${version} && ! -x ./configure ]]; then
    cd coreutils-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var/lib \
    --enable-no-install-program=kill,uptime

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"

  # Em sistemas com /bin separado, podemos criar links de compatibilidade
  if [[ -d "$DESTDIR/bin" ]]; then
    for prog in cat chgrp chmod chown cp date dd df echo false ln ls \
                mkdir mknod mv pwd rm rmdir stty sync true uname \
                head sleep nice; do
      if [[ -x "$DESTDIR/usr/bin/$prog" && ! -e "$DESTDIR/bin/$prog" ]]; then
        ln -sv "../usr/bin/$prog" "$DESTDIR/bin/$prog"
      fi
    done
  fi
}

post_install() {
  # Testes rápidos não destrutivos
  if command -v ls >/dev/null 2>&1; then
    ls --version | head -n1 || true
  fi
  if command -v stat >/dev/null 2>&1; then
    stat / || true
  fi
}
