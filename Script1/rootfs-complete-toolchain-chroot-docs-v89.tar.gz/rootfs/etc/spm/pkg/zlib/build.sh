# Definição de pacote SPM para zlib (biblioteca de compressão)
name=zlib
version=1.3.1

# Tarball oficial da zlib
source="zlib-{version}.tar.xz::https://zlib.net/zlib-{version}.tar.xz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' enquanto não tiver o hash real.
sha256="-"

# zlib depende de um toolchain funcional e da libc (glibc) para uso normal
deps=(glibc)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:zlib] Configurando zlib-${version}..."
  "$srcdir/configure" --prefix=/usr

  echo "[spm:zlib] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  # Testes opcionais
  if [[ "${ZLIB_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:zlib] Executando 'make test'..."
    make test || echo "[spm:zlib][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:zlib] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  # Em muitas distros, a zlib instala tanto libz.so quanto libz.a.
  # Se quiser evitar estática, poderia remover libz.a aqui, mas deixamos como está
  # para dar flexibilidade ao usuário.

  echo "[spm:zlib] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional para rodar ldconfig ou outros ajustes.
  # Exemplo (ajuste conforme o seu ambiente):
  #
  # if command -v ldconfig >/dev/null 2>&1; then
  #   echo "[spm:zlib] Executando ldconfig..."
  #   ldconfig
  # fi
  :
}
