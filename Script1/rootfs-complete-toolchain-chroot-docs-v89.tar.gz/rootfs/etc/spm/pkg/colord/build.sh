name=colord
version=1.4.8

source="  colord-{version}.tar.xz::https://www.freedesktop.org/software/colord/releases/colord-{version}.tar.xz "

sha256="  <sha256-colord-{version}.tar.xz> "

deps=(glibc glib dbus systemd libxslt)

build() {
  set -euo pipefail
  cd colord-${version}
  meson setup build --prefix=/usr --sysconfdir=/etc --libdir=/usr/lib
  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}
