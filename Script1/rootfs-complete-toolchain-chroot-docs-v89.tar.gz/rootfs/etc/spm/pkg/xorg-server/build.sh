name=xorg-server
version=virtual-1
source=""
sha256=""

deps=(xorg-server-core)

build() { :; }
