name=x265
version=3.5

source="\
  x265-{version}.tar.gz::https://bitbucket.org/multicoreware/x265_git/get/{version}.tar.gz \
"

sha256="\
  <sha256-x265-{version}.tar.gz> \
"

deps=(glibc cmake)

build() {
  set -euo pipefail
  cd multicoreware-x265_git-*
  cd source
  mkdir -p build && cd build
  cmake -DCMAKE_INSTALL_PREFIX=/usr -DENABLE_SHARED=ON ..
  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
