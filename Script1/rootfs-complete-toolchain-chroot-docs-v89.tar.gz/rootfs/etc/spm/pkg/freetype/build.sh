name=freetype
version=2.13.3

source="\
  freetype-{version}.tar.xz::https://download.savannah.gnu.org/releases/freetype/freetype-{version}.tar.xz \
"

sha256="\
  <sha256-freetype-{version}.tar.xz> \
"

# Engine de fontes vetoriais.
deps=(glibc zlib bzip2 libpng)

build() {
  set -euo pipefail

  if [[ -d freetype-${version} ]]; then
    cd freetype-${version}
  fi

  # Opcionalmente, você pode habilitar harfbuzz depois de ter o ciclo resolvido.
  ./configure \
    --prefix=/usr \
    --enable-freetype-config \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libfreetype*.la' -delete 2>/dev/null || true
}

post_install() {
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --modversion freetype2 2>/dev/null || true
  fi
}
