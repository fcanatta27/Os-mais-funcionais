name=yasm
version=1.3.0

source="\
  yasm-{version}.tar.gz::https://www.tortall.net/projects/yasm/releases/yasm-{version}.tar.gz \
"

sha256="\
  <sha256-yasm-{version}.tar.gz> \
"

# Montador usado frequentemente por projetos multimídia.
deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d yasm-${version} ]]; then
    cd yasm-${version}
  fi

  ./configure \
    --prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
