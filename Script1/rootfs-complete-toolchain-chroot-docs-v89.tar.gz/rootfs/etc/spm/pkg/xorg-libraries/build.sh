name=xorg-libraries
version=2024.1

# Meta pacote: representa um conjunto coerente de bibliotecas Xorg já empacotadas pelo SPM.
# Não compila código próprio, mas instala um manifesto com o snapshot das libs instaladas.

source="xorg-libraries-{version}.meta::local://spm/xorg-libraries-{version}.meta"

# Mantém a lista explícita para dar semântica real ao pacote
deps=(xorgproto libXau libXdmcp libxcb libxcvt xcb-util)

build() {
  set -euo pipefail

  mkdir -p "${DESTDIR}/var/lib/spm/meta"

  # Manifesto com a lista de libs de X.org esperadas
  local manifest="${DESTDIR}/var/lib/spm/meta/xorg-libraries-${version}.txt"

  cat > "${manifest}" << 'EOF'
xorg-libraries meta package
Conjunto mínimo esperado de bibliotecas X.org fornecidas por outros pacotes SPM:
  - xorgproto
  - libXau
  - libXdmcp
  - libxcb
  - libxcvt
  - xcb-util
EOF
}

post_install() {
  :
}
