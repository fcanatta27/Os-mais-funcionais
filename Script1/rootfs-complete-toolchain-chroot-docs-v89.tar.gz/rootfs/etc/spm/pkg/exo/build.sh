name=exo
version=4.20.0

source="\
  exo-{version}.tar.bz2::https://archive.xfce.org/src/xfce/exo/4.20/exo-{version}.tar.bz2 \
"

sha256="\
  <sha256-exo-{version}.tar.bz2> \
"

# Biblioteca de helpers do Xfce (launcher, handlers etc).
deps=(glibc glib2 gtk3 libxfce4util libxfce4ui)

build() {
  set -euo pipefail

  if [[ -d exo-${version} ]]; then
    cd exo-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libexo*.la' -delete 2>/dev/null || true
}

post_install() {
  :
}
