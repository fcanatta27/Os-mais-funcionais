name=sysstat
version=12.7.8

source="\
  sysstat-{version}.tar.xz::https://github.com/sysstat/sysstat/archive/v{version}/sysstat-{version}.tar.gz \
"

sha256="\
  <sha256-sysstat-{version}.tar.gz> \
"

deps=(glibc)

build() {
  set -euo pipefail

  # O tar do GitHub usualmente extrai como sysstat-{version}
  if [[ -d sysstat-${version} && ! -x ./configure ]]; then
    cd sysstat-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --disable-file-attr

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  # Garante diretório de config
  mkdir -p "${DESTDIR}/etc/sysconfig"

  # Config padrão se não existir
  if [[ ! -f "${DESTDIR}/etc/sysconfig/sysstat" && -f sysstat.sysconfig ]; then
    install -m644 sysstat.sysconfig "${DESTDIR}/etc/sysconfig/sysstat"
  fi
}

post_install() {
  if command -v sar >/dev/null 2>&1; then
    sar -V 2>/dev/null || true
  fi
}
