name=tk
version=8.6.16

source="  tk{version}-src.tar.gz::https://downloads.sourceforge.net/tcl/tk{version}-src.tar.gz "

sha256="<sha256-tk{version}-src.tar.gz>"

deps=(glibc tcl x11-lib)

build() {
  set -euo pipefail
  cd tk${version}/unix

  ./configure --prefix=/usr --with-tcl=/usr/lib
  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
