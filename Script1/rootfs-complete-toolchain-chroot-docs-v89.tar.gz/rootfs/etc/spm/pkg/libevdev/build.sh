name=libevdev
version=1.13.4

source="\
  libevdev-{version}.tar.xz::https://www.freedesktop.org/software/libevdev/libevdev-{version}.tar.xz \
"

sha256="\
  <sha256-libevdev-{version}.tar.xz> \
"

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d libevdev-${version} ]]; then
    cd libevdev-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dtests=false

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build

  find "${DESTDIR}/usr/lib" -name 'libevdev*.la' -delete 2>/dev/null || true
}

post_install() {
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --modversion libevdev 2>/dev/null || true
  fi
}
