name=libXmu
version=1.1.4

source="\
  libXmu-{version}.tar.xz::https://www.x.org/releases/individual/lib/libXmu-{version}.tar.xz \
"

sha256="\
  <sha256-libXmu-{version}.tar.xz> \
"

# Misc X utilities library, usada por vários apps X clássicos.
deps=(glibc libX11 libXt libXext xorgproto)

build() {
  set -euo pipefail

  if [[ -d libXmu-${version} ]]; then
    cd libXmu-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libXmu*.la' -delete 2>/dev/null || true
}

post_install() {
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --modversion xmu 2>/dev/null || true
  fi
}
