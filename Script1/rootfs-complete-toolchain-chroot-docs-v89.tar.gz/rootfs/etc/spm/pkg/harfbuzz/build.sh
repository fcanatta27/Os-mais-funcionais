name=harfbuzz
version=10.2.0

source="\
  harfbuzz-{version}.tar.xz::https://github.com/harfbuzz/harfbuzz/releases/download/{version}/harfbuzz-{version}.tar.xz \
"

sha256="\
  <sha256-harfbuzz-{version}.tar.xz> \
"

deps=(glibc freetype glib2)

build() {
  set -euo pipefail

  if [[ -d harfbuzz-${version} ]]; then
    cd harfbuzz-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dtests=disabled \
    -Dbenchmark=disabled \
    -Dicu=disabled

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --modversion harfbuzz 2>/dev/null || true
  fi
}
