name=e2fsprogs
version=1.47.3

source="\
  e2fsprogs-{version}.tar.gz::https://downloads.sourceforge.net/project/e2fsprogs/e2fsprogs/v{version}/e2fsprogs-{version}.tar.gz \
"

sha256="\
  <sha256-e2fsprogs-{version}.tar.gz> \
"

# Dependência principal: glibc. Opcionalmente util-linux para blkid/libuuid, mas aqui
# construímos as libs do próprio e2fsprogs.
deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d e2fsprogs-${version} && ! -f configure ]]; then
    cd e2fsprogs-${version}
  fi

  # Build em subdiretório, como recomendado
  rm -rf build
  mkdir -p build
  cd build

  ../configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --enable-elf-shlibs \
    --disable-libblkid \
    --disable-libuuid \
    --disable-uuidd \
    --disable-fsck

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"

  # Instala apenas as libs compartilhadas, removendo estáticas se sobrar alguma
  find "$DESTDIR/usr/lib" -name 'libe2p*.a' -delete 2>/dev/null || true
  find "$DESTDIR/usr/lib" -name 'libext2fs*.a' -delete 2>/dev/null || true
}

post_install() {
  # Teste leve: mostrar versão do e2fsck sem mexer em disco
  if command -v e2fsck >/dev/null 2>&1; then
    e2fsck -V || true
  fi
}
