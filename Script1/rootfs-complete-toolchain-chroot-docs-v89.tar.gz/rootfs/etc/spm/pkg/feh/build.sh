name=feh
version=3.10.2

source="\
  feh-{version}.tar.bz2::https://feh.finalrewind.org/feh-{version}.tar.bz2 \
"

sha256="\
  <sha256-feh-{version}.tar.bz2> \
"

deps=(glibc libX11 libXinerama libjpeg libpng imlib2)

build() {
  set -euo pipefail
  cd feh-${version}
  make -j"${JOBS:-1}"
  make install PREFIX=/usr DESTDIR="${DESTDIR}"
}
