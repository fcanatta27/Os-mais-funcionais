name=bash-completion
version=2.14.0

source="\
  bash-completion-{version}.tar.xz::https://github.com/scop/bash-completion/releases/download/{version}/bash-completion-{version}.tar.xz \
"

sha256="\
  <sha256-bash-completion-{version}.tar.xz> \
"

deps=(bash)

build() {
  set -euo pipefail
  cd bash-completion-${version}

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"
}

post_install() {
  echo "source /usr/share/bash-completion/bash_completion" \
    > "$DESTDIR/etc/profile.d/bash_completion.sh"
}
