name=xcb-util-xrm
version=1.3

source="\
  xcb-util-xrm-{version}.tar.gz::https://github.com/Airblader/xcb-util-xrm/archive/refs/tags/v{version}.tar.gz \
"

sha256="\
  <sha256-xcb-util-xrm-{version}.tar.gz> \
"

# Suporte a X resource manager para XCB, usado por bspwm.
deps=(glibc libxcb xcb-util)

build() {
  set -euo pipefail

  if [[ -d xcb-util-xrm-${version} ]]; then
    cd xcb-util-xrm-${version}
  fi

  ./autogen.sh || true

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
