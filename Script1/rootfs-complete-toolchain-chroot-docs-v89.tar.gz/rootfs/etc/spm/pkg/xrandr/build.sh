name=xrandr
version=1.5.2

source="\
  xrandr-{version}.tar.xz::https://www.x.org/releases/individual/app/xrandr-{version}.tar.xz \
"

sha256="\
  <sha256-xrandr-{version}.tar.xz> \
"

deps=(glibc libX11 libXrandr xorgproto)

build() {
  set -euo pipefail

  if [[ -d xrandr-${version} ]]; then
    cd xrandr-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  command -v xrandr >/dev/null 2>&1 || true
}
