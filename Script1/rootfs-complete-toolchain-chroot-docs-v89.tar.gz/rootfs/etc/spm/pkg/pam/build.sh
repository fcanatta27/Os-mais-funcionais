name=pam
version=virtual-1

source=""
sha256=""

# Meta-pacote que expõe Linux-PAM como 'pam'.
deps=(linux-pam)

build() {
  set -euo pipefail
  echo "pam é um meta-pacote; nenhuma build necessária."
}

post_install() {
  :
}
