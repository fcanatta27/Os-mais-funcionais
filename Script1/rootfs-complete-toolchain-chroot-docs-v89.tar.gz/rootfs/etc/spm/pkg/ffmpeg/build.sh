name=ffmpeg
version=7.0.1

source="\
  ffmpeg-{version}.tar.xz::https://ffmpeg.org/releases/ffmpeg-{version}.tar.xz \
"

sha256="\
  <sha256-ffmpeg-{version}.tar.xz> \
"

deps=(glibc x264 x265 alsa-lib libX11)

build() {
  set -euo pipefail
  cd ffmpeg-${version}
  ./configure \
    --prefix=/usr \
    --enable-gpl \
    --enable-shared \
    --enable-libx264 \
    --enable-libx265 \
    --enable-alsa
  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
