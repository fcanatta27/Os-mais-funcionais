name=xorgproto
version=2024.1

source="\
  xorgproto-{version}.tar.xz::https://www.x.org/pub/individual/proto/xorgproto-{version}.tar.xz \
"

sha256="\
  <sha256-xorgproto-{version}.tar.xz> \
"

deps=(glibc util-macros)

build() {
  set -euo pipefail

  if [[ -d xorgproto-${version} && ! -f xorgproto-${version}/meson.build ]]; then
    cd xorgproto-${version}
  elif [[ -d xorgproto-${version} ]]; then
    cd xorgproto-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --buildtype=release

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  # Cabeçalhos de protocolo em /usr/include
  ls /usr/include/X11 2>/dev/null || true
}
