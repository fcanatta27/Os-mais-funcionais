name=gptfdisk
version=1.0.10

source="  gptfdisk-{version}.tar.gz::https://sourceforge.net/projects/gptfdisk/files/gptfdisk/{version}/gptfdisk-{version}.tar.gz "

sha256="  <sha256-gptfdisk-{version}.tar.gz> "

deps=(glibc ncurses popt)

build() {
  set -euo pipefail
  cd gptfdisk-${version}

  make -j"${JOBS:-1}"
  make DESTDIR="${DESTDIR}" install
}
