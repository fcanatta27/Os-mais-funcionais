# Definição de pacote SPM para XML::Parser (módulo Perl baseado em Expat)
name=xml-parser
version=2.47

# Tarball oficial do XML::Parser no CPAN
source="XML-Parser-{version}.tar.gz::https://www.cpan.org/authors/id/T/TO/TODDR/XML-Parser-{version}.tar.gz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
sha256="-"

# Depende de Perl e Expat
deps=(glibc perl expat)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"

  echo "[spm:xml-parser] Preparando XML-Parser-${version}..."

  # Diretórios padrão de include/lib do expat
  local EXPAT_INC="/usr/include"
  local EXPAT_LIB="/usr/lib"

  echo "[spm:xml-parser] Gerando Makefile via perl Makefile.PL..."
  perl Makefile.PL \
    EXPATLIBPATH="${EXPAT_LIB}" \
    EXPATINCPATH="${EXPAT_INC}" \
    INSTALLDIRS=vendor

  echo "[spm:xml-parser] Compilando..."
  make -j"${JOBS:-1}"

  if [[ "${XMLPARSER_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:xml-parser] Executando 'make test'..."
    make test || echo "[spm:xml-parser][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:xml-parser] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  # Remover perllocal.pod/packlist específicos de build
  find "$DESTDIR/usr/lib/perl5" -name perllocal.pod -delete 2>/dev/null || true
  find "$DESTDIR/usr/lib/perl5" -name ".packlist" -delete 2>/dev/null || true

  echo "[spm:xml-parser] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do XML::Parser.
  :
}
