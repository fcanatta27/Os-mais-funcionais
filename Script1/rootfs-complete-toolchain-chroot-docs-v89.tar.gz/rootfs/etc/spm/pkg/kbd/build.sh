name=kbd
version=2.8.0

source="      kbd-{version}.tar.xz::https://www.kernel.org/pub/linux/utils/kbd/kbd-{version}.tar.xz     "

# Use 'spm checksum kbd' para preencher corretamente
sha256="      <sha256-kbd-{version}.tar.xz>     "

# Dependências típicas: glibc, libxcrypt (para pam/tty), e opcionalmente eudev/systemd
# Ajuste de acordo com os pacotes disponíveis no seu SPM.
deps=(glibc libxcrypt)

build() {
  set -euo pipefail

  if [[ -d kbd-${version} && ! -x ./configure ]]; then
    cd kbd-${version}
  fi

  # Remover traduções russas problemáticas em alguns ambientes, como em LFS
  sed -i 's/\(RESIZECONS_PROGS=.*\) setfont/\1/' configure || true
  sed -i 's/resizecons.8 //' docs/man/man8/Makefile.in || true

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --datadir=/usr/share

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"

  # Instala keymaps em local padrão
  if [[ -d "$DESTDIR/usr/share/kbd" ]]; then
    mkdir -p "$DESTDIR/etc/kbd" 2>/dev/null || true
  fi
}

post_install() {
  # Teste leve: verifica se loadkeys responde
  if command -v loadkeys >/dev/null 2>&1; then
    loadkeys -h >/dev/null 2>&1 || true
  fi
}
