name=fluxbox
version=1.3.7

source="\
  fluxbox-{version}.tar.xz::https://downloads.sourceforge.net/fluxbox/fluxbox-{version}.tar.xz \
"

sha256="\
  <sha256-fluxbox-{version}.tar.xz> \
"

# Window manager leve baseado em Blackbox, com tabs e menu altamente configurável.
deps=(glibc libX11 libXpm libXft fontconfig freetype xorgproto)

build() {
  set -euo pipefail

  if [[ -d fluxbox-${version} ]]; then
    cd fluxbox-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  command -v fluxbox >/dev/null 2>&1 || true
}
