name=libXaw
version=1.0.16

source="\
  libXaw-{version}.tar.xz::https://www.x.org/releases/individual/lib/libXaw-{version}.tar.xz \
"

sha256="\
  <sha256-libXaw-{version}.tar.xz> \
"

deps=(glibc libX11 libXmu libXt xorgproto)

build() {
  set -euo pipefail

  if [[ -d libXaw-${version} ]]; then
    cd libXaw-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libXaw*.la' -delete 2>/dev/null || true
}

post_install() {
  :
}
