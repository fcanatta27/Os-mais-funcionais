name=upower
version=1.90.9

source="\
  upower-{version}.tar.gz::https://gitlab.freedesktop.org/upower/upower/-/archive/{version}/upower-{version}.tar.gz \
"

sha256="\
  <sha256-upower-{version}.tar.gz> \
"

# Dependências principais: glib, systemd, dbus, polkit
deps=(glibc glib systemd dbus polkit)

build() {
  set -euo pipefail

  if [[ -d upower-${version} && ! -f upower-${version}/meson.build ]]; then
    cd upower-${version}
  elif [[ -d upower-${version} ]]; then
    cd upower-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --buildtype=release \
    -Dsystemdsystemunitdir=/usr/lib/systemd/system \
    -Dman=true

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build

  # Diretório de configuração
  mkdir -p "${DESTDIR}/etc/UPower"
}

post_install() {
  if command -v upower >/dev/null 2>&1; then
    upower --version || true
  fi
}
