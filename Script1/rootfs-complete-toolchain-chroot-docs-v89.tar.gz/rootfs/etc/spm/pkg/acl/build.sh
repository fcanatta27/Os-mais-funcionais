name=acl
version=2.3.2
source="acl-{version}.tar.gz::https://download.savannah.gnu.org/releases/acl/acl-{version}.tar.gz"
sha256="-"
deps=(glibc attr)

build() {
  set -euo pipefail
  : "${DESTDIR:?}" ; : "${TMP:?}"

  local src="$PWD"
  local b="$TMP/acl-${version}-build"
  rm -rf "$b"; mkdir -p "$b"; cd "$b"

  "$src/configure" --prefix=/usr --disable-static --sysconfdir=/etc
  make -j"${JOBS:-1}"

  if [[ "${ACL_RUN_TESTS:-0}" = 1 ]]; then
    make check || echo "[acl] WARN: test failures"
  fi

  make install DESTDIR="$DESTDIR"
}
post_install(){ :; }
