name=xsetroot
version=1.1.3

source="\
  xsetroot-{version}.tar.xz::https://www.x.org/releases/individual/app/xsetroot-{version}.tar.xz \
"

sha256="\
  <sha256-xsetroot-{version}.tar.xz> \
"

# Define cor ou bitmap do root window do X, muito usado por WMs.
deps=(glibc libX11 xorgproto)

build() {
  set -euo pipefail

  if [[ -d xsetroot-${version} ]]; then
    cd xsetroot-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  command -v xsetroot >/dev/null 2>&1 || true
}
