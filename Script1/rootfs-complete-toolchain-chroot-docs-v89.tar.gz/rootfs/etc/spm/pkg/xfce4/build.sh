name=xfce4
version=4.20-meta1

source=""
sha256=""

# Meta-pacote que puxa um desktop Xfce completo.
deps=(libxfce4util xfconf libxfce4ui garcon exo thunar xfce4-panel xfwm4 xfdesktop xfce4-session xfce4-settings xfce4-appfinder xfce4-terminal)

build() {
  set -euo pipefail
  echo "xfce4 é um meta-pacote, nenhuma build necessária."
}

post_install() {
  :
}

# dependências extras para desktop completo
