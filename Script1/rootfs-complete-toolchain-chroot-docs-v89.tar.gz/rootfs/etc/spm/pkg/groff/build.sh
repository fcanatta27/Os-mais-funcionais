name=groff
version=1.23.0

source="      groff-{version}.tar.gz::https://ftp.gnu.org/gnu/groff/groff-{version}.tar.gz     "

# Use 'spm checksum groff' para preencher corretamente
sha256="      <sha256-groff-{version}.tar.gz>     "

# groff depende basicamente de glibc e de um toolchain C funcional.
# Se você tiver texinfo instalado, ajuda para gerar alguma documentação extra.
deps=(glibc)

build() {
  set -euo pipefail

  # O spm normalmente já entra no diretório groff-${version}.
  # Este fallback garante que estamos no lugar certo se isso mudar.
  if [[ -d groff-${version} && ! -x ./configure ]]; then
    cd groff-${version}
  fi

  # Página A4 é o padrão mais comum em PT-BR.
  PAGE=${PAGE:-A4}

  PAGE="$PAGE" ./configure \
    --prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"

  # Instala documentação adicional se existir
  if [[ -d doc ]]; then
    mkdir -p "$DESTDIR/usr/share/doc/groff-${version}"
    cp -v doc/* "$DESTDIR/usr/share/doc/groff-${version}" 2>/dev/null || true
  fi
}

post_install() {
  # Teste rápido: renderizar uma página simples
  if command -v groff >/dev/null 2>&1; then
    echo '.TH TEST 1 "SPM" "groff" "Test"' | groff -Tutf8 -man >/dev/null 2>&1 || true
  fi
}
