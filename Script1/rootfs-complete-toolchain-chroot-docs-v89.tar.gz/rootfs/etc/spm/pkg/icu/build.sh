name=icu
version=78.2

source="  icu4c-{version}-src.tgz::https://github.com/unicode-org/icu/releases/download/release-{version}/icu4c-{version}-src.tgz "

sha256="<sha256-icu4c-{version}-src.tgz>"

deps=(glibc)

build() {
  set -euo pipefail
  cd icu/source

  ./configure --prefix=/usr --disable-static
  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
