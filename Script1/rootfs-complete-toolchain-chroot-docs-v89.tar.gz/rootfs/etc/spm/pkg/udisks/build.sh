name=udisks
version=2.10.2

source="\
  udisks-{version}.tar.gz::https://github.com/storaged-project/udisks/archive/udisks-{version}.tar.gz \
"

sha256="\
  <sha256-udisks-{version}.tar.gz> \
"

# Dependências principais: glib, systemd, polkit, dbus
deps=(glibc glib systemd polkit dbus)

build() {
  set -euo pipefail

  if [[ -d udisks-${version} && ! -f udisks-${version}/meson.build ]]; then
    cd udisks-${version}
  elif [[ -d udisks-${version} ]]; then
    cd udisks-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --buildtype=release \
    -Dsystemdsystemunitdir=/usr/lib/systemd/system \
    -Dman=true

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build

  # Garante diretórios de configuração
  mkdir -p "${DESTDIR}/etc/udisks2" \
           "${DESTDIR}/etc/polkit-1/rules.d"
}

post_install() {
  if command -v udisksctl >/dev/null 2>&1; then
    udisksctl status 2>/dev/null || true
  fi
}
