name=xwayland
version=24.1.8

source="\
  xwayland-{version}.tar.xz::https://www.x.org/releases/individual/xserver/xwayland-{version}.tar.xz \
"

sha256="\
  <sha256-xwayland-{version}.tar.xz> \
"

# Xwayland depende de boa parte da stack gráfica/Wayland.
deps=(glibc xorgproto pixman libX11 libXext libXdamage libXfixes libXrender \
      libxcb xcb-util libdrm mesa libepoxy libxcvt wayland wayland-protocols)

build() {
  set -euo pipefail

  if [[ -d xwayland-${version} ]]; then
    cd xwayland-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dxwayland-path=/usr/bin/Xwayland

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  command -v Xwayland >/dev/null 2>&1 || true
}
