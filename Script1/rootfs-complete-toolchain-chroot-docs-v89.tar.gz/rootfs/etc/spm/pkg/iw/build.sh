name=iw
version=5.21

source="\
  iw-{version}.tar.xz::https://www.kernel.org/pub/software/network/iw/iw-{version}.tar.xz \
"

sha256="\
  <sha256-iw-{version}.tar.xz> \
"

# Ferramenta em linha de comando para controlar Wi-Fi via nl80211.
deps=(glibc libnl)

build() {
  set -euo pipefail

  if [[ -d iw-${version} ]]; then
    cd iw-${version}
  fi

  make CC="${CC:-gcc}" -j"${JOBS:-1}"

  make DESTDIR="${DESTDIR}" PREFIX=/usr install
}

post_install() {
  command -v iw >/dev/null 2>&1 || true
}
