name=diffutils
version=3.12

source="\
  diffutils-{version}.tar.xz::https://ftp.gnu.org/gnu/diffutils/diffutils-{version}.tar.xz \
"

sha256="\
  <sha256-diffutils-{version}.tar.xz> \
"

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d diffutils-${version} && ! -x ./configure ]]; then
    cd diffutils-${version}
  fi

  ./configure \
    --prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"
}

post_install() {
  if command -v diff >/dev/null 2>&1; then
    diff --version | head -n1 || true
  fi
}
