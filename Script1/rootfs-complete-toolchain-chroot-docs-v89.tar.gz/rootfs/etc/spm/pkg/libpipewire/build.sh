name=libpipewire
version=virtual-1

source=""
sha256=""

# Meta-pacote expondo libpipewire provida por 'pipewire'.
deps=(pipewire)

build() {
  set -euo pipefail
  echo "libpipewire é um meta-pacote; nenhuma build necessária."
}

post_install() {
  :
}
