name=curl
version=8.15.0

source="\
 curl-{version}.tar.xz::https://curl.se/download/curl-{version}.tar.xz \
"

sha256="\
 <sha256-curl-{version}.tar.xz> \
"

deps=(glibc openssl zlib brotli libssh2)

build() {
 set -euo pipefail
 cd curl-${version}
 ./configure \
   --prefix=/usr \
   --with-openssl \
   --enable-ipv6 \
   --enable-unix-sockets
 make -j"${JOBS:-1}"
 make install DESTDIR="${DESTDIR}"
}
