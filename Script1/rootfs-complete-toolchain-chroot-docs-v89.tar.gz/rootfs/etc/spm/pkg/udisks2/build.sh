name=udisks2
version=virtual-1

source=""
sha256=""

# Meta-pacote para satisfazer dependências que usam o nome 'udisks2'.
# Implementado via pacote 'udisks' real.
deps=(udisks)

build() {
  set -euo pipefail
  echo "udisks2 é um meta-pacote; nenhuma build necessária."
}

post_install() {
  :
}
