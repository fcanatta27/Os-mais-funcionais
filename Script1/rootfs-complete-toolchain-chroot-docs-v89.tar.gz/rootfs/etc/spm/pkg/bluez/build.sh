name=bluez
version=5.81

source="  bluez-{version}.tar.xz::https://www.kernel.org/pub/linux/bluetooth/bluez-{version}.tar.xz "

sha256="  <sha256-bluez-{version}.tar.xz> "

# Dependências aproximadas: glibc, dbus, systemd, readline, ncurses
deps=(glibc dbus systemd readline ncurses)

build() {
  set -euo pipefail

  if [[ -d bluez-${version} && ! -x ./configure ]]; then
    cd bluez-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --libexecdir=/usr/lib/bluetooth \
    --enable-library \
    --enable-mesh \
    --enable-systemd \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  # Configuração básica de /etc/bluetooth/main.conf (somente se não existir)
  local etcb="${DESTDIR}/etc/bluetooth"
  mkdir -p "${etcb}"
  if [[ ! -f "${etcb}/main.conf" ]]; then
    cat > "${etcb}/main.conf" << 'EOF'
[General]
Name = bluez-host
Class = 0x000100
DiscoverableTimeout = 0
PairableTimeout = 0
AutoEnable=true
EOF
  fi

  # Habilita auto-ativação via D-Bus (symlink dbus-org.bluez.service)
  local sysd="${DESTDIR}/etc/systemd/system"
  mkdir -p "${sysd}"
  if [[ ! -e "${sysd}/dbus-org.bluez.service" ]]; then
    ln -sv "/usr/lib/systemd/system/bluetooth.service" "${sysd}/dbus-org.bluez.service"
  fi
}

post_install() {
  if command -v bluetoothctl >/dev/null 2>&1; then
    bluetoothctl --version || true
  fi
}
