name=pango
version=1.54.0

source="\
  pango-{version}.tar.xz::https://download.gnome.org/sources/pango/1.54/pango-{version}.tar.xz \
"

sha256="\
  <sha256-pango-{version}.tar.xz> \
"

# Layout de texto em alto nível.
deps=(glib2 freetype fontconfig cairo harfbuzz)

build() {
  set -euo pipefail

  if [[ -d pango-${version} ]]; then
    cd pango-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dgtk_doc=false \
    -Dintrospection=disabled \
    -Dtests=false

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build

  find "${DESTDIR}/usr/lib" -name 'libpango*.la' -delete 2>/dev/null || true
}

post_install() {
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --modversion pango 2>/dev/null || true
  fi
}
