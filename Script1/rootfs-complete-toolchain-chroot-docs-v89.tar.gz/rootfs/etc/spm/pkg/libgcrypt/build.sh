name=libgcrypt
version=1.11.0

source="\
  libgcrypt-{version}.tar.bz2::https://www.gnupg.org/ftp/gcrypt/libgcrypt/libgcrypt-{version}.tar.bz2 \
"

sha256="\
  <sha256-libgcrypt-{version}.tar.bz2> \
"

deps=(glibc libgpg-error)

build() {
  set -euo pipefail
  cd libgcrypt-${version}

  ./configure     --prefix=/usr     --disable-static     --enable-shared     --with-libgpg-error-prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
