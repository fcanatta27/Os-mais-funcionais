name=libsoup3
version=3.6.4

source="\
  libsoup-{version}.tar.xz::https://download.gnome.org/sources/libsoup/3.6/libsoup-{version}.tar.xz \
"

sha256="\
  <sha256-libsoup-{version}.tar.xz> \
"

# Biblioteca HTTP baseada em glib, usada por WebKitGTK.
deps=(glibc glib2 gio openssl libpsl sqlite3)

build() {
  set -euo pipefail

  if [[ -d libsoup-${version} ]]; then
    cd libsoup-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dvapi=false \
    -Dtests=false

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  :
}
