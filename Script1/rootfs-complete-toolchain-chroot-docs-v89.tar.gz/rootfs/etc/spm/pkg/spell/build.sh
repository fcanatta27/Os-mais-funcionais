name=spell
version=1.0

source="  spell-{version}.tar.gz::https://ftp.gnu.org/gnu/spell/spell-{version}.tar.gz "

sha256="  <sha256-spell-{version}.tar.gz> "

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d spell-${version} && ! -x ./configure ]]; then
    cd spell-${version}
  fi

  ./configure \
    --prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  if command -v spell >/dev/null 2>&1; then
    spell --help >/dev/null 2>&1 || true
  fi
}
