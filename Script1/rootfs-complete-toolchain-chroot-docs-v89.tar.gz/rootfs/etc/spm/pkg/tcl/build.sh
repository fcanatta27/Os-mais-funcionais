# Definição de pacote SPM para Tcl (Tool Command Language)
name=tcl
version=8.6.17

# Tarball oficial do Tcl
source="tcl{version}-src.tar.gz::https://prdownloads.sourceforge.net/tcl/tcl{version}-src.tar.gz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' enquanto não tiver o hash real.
sha256="-"

# Tcl depende de glibc e normalmente usa zlib/threads, mas aqui
# declaramos apenas glibc como base. Ajuste deps conforme for empacotando.
deps=(glibc zlib)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  # O tarball do Tcl extrai um diretório tcl8.6.17 com subdiretório unix/
  local srcdir="$PWD"
  local unixdir="$srcdir/unix"

  if [[ ! -d "$unixdir" ]]; then
    echo "[spm:tcl][ERRO] Diretório 'unix' não encontrado em ${srcdir}."
    exit 1
  fi

  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"

  # Usaremos o próprio unix/ como diretório de build, conforme recomendação do projeto.
  # Copiar para builddir evita sujar a árvore original se desejado.
  cp -a "$unixdir"/. "$builddir/"
  cd "$builddir"

  # Habilita 64-bit se a arquitetura for x86_64
  local extra_opts=()
  if [[ "$(uname -m)" = "x86_64" ]]; then
    extra_opts+=(--enable-64bit)
  fi

  echo "[spm:tcl] Configurando tcl-${version}..."
  ./configure \
    --prefix=/usr \
    --mandir=/usr/share/man \
    "${extra_opts[@]}"

  echo "[spm:tcl] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  # Testes opcionais
  if [[ "${TCL_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:tcl] Executando 'make test' (pode ser demorado)..."
    make test || echo "[spm:tcl][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:tcl] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  # Instalar headers privados, conforme práticas comuns de empacotamento
  make install-private-headers DESTDIR="$DESTDIR"

  # Ajustar link simbólico tclsh
  if [[ -x "$DESTDIR/usr/bin/tclsh8.6" ]]; then
    ln -sf tclsh8.6 "$DESTDIR/usr/bin/tclsh"
  fi

  # Ajustes em tclConfig.sh para apontar para locais finais (não estritamente necessário,
  # pois o SPM instala diretamente em /usr no sistema alvo, mas mantemos o padrão).
  # Aqui assumimos que tclConfig.sh fica em /usr/lib no DESTDIR.
  local tclconfig="$DESTDIR/usr/lib/tclConfig.sh"
  if [[ -f "$tclconfig" ]]; then
    sed -i "s@^TCL_SRC_DIR='.*'@TCL_SRC_DIR='/usr/include'@" "$tclconfig" || true
    sed -i "s@^TCL_BIN_DIR='.*'@TCL_BIN_DIR='/usr/bin'@" "$tclconfig" || true
  fi

  echo "[spm:tcl] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do Tcl.
  :
}
