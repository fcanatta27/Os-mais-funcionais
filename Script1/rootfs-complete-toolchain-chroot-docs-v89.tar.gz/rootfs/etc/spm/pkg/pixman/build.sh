name=pixman
version=0.42.2

source="\
  pixman-{version}.tar.gz::https://cairographics.org/releases/pixman-{version}.tar.gz \
"

sha256="\
  <sha256-pixman-{version}.tar.gz> \
"

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d pixman-${version} ]]; then
    cd pixman-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
