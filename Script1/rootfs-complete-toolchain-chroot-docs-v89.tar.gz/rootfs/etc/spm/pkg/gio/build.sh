name=gio
version=virtual-1

source=""
sha256=""

# Meta-pacote expondo GIO provido por glib2.
deps=(glib2)

build() {
  set -euo pipefail
  echo "gio é um meta-pacote; nenhuma build necessária."
}

post_install() {
  :
}
