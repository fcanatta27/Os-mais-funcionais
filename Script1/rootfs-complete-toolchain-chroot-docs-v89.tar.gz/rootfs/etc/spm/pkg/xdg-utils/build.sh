name=xdg-utils
version=1.2.1

source="\
  xdg-utils-{version}.tar.gz::https://gitlab.freedesktop.org/xdg/xdg-utils/-/archive/v{version}/xdg-utils-v{version}.tar.gz \
"

sha256="\
  <sha256-xdg-utils-{version}.tar.gz> \
"

deps=(glibc)

build() {
  set -euo pipefail
  cd xdg-utils-v{version}
  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}" prefix=/usr
}
