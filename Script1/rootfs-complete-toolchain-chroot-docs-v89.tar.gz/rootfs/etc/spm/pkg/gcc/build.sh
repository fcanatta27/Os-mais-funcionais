# Definição de pacote SPM para GCC final do sistema
name=gcc
version=15.2.0

# Tarball principal direto do FTP GNU
source="gcc-{version}.tar.xz::https://ftp.gnu.org/gnu/gcc/gcc-{version}/gcc-{version}.tar.xz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' para desativar a checagem por enquanto, até preencher com o hash real.
sha256="-"

# GCC final depende de binutils já instalado e de uma libc funcional (glibc).
# Ajuste a lista conforme você for empacotando mais componentes pelo SPM,
# mas evite ciclos (ex.: não coloque gcc como dependência de glibc se glibc
# depender de gcc).
deps=(binutils glibc)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  # Configuração típica para GCC final em /usr.
  # Pressupõe que as bibliotecas GMP/MPFR/MPC/Zlib estejam presentes no sistema
  # (ou incorporadas na árvore de fontes do GCC).
  local CONFIG_OPTS=(
    "--prefix=/usr"
    "--libdir=/usr/lib"
    "--libexecdir=/usr/lib"
    "--enable-languages=c,c++"
    "--enable-default-pie"
    "--enable-default-ssp"
    "--disable-multilib"
    "--disable-bootstrap"
    "--disable-libsanitizer"
    "--disable-libquadmath"
    "--disable-libquadmath-support"
    "--with-system-zlib"
  )

  # Detecta triplet de build usando config.guess do GCC
  if [[ -x "$srcdir/config.guess" ]]; then
    local build_triplet
    build_triplet="$("$srcdir/config.guess")"
    CONFIG_OPTS+=("--build=$build_triplet")
  fi

  echo "[spm:gcc] Configurando gcc-${version}..."
  "$srcdir/configure" "${CONFIG_OPTS[@]}"

  echo "[spm:gcc] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  # Testes opcionais (costumam ser muito pesados)
  if [[ "${GCC_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:gcc] Executando 'make -k check' (pode ser MUITO demorado)..."
    make -k check || echo "[spm:gcc][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:gcc] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  # Ajustes pós-instalação típicos (links simbólicos, limpeza, etc.) podem ser feitos aqui.
  echo "[spm:gcc] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional executado após a instalação real no sistema.
  # Ex: atualizar alternativas de /usr/bin/cc, limpar headers temporários, etc.
  :
}
