name=spectrumwm
version=3.3.0

source="\
  spectrum-{version}.tar.gz::https://github.com/spectrumwm/spectrum/archive/refs/tags/v{version}.tar.gz \
"

sha256="\
  <sha256-spectrum-{version}.tar.gz> \
"

# Window manager leve baseado em Xlib.
deps=(glibc libX11 libXft libXinerama)

build() {
  set -euo pipefail

  if [[ -d spectrum-${version} ]]; then
    cd spectrum-${version}
  fi

  if [[ ! -f config.h ]]; then
    cp config.def.h config.h || true
  fi

  make -j"${JOBS:-1}"
  make install PREFIX=/usr DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
