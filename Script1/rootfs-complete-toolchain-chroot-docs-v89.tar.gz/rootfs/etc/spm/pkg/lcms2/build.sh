name=lcms2
version=2.16

source="  lcms2-{version}.tar.gz::https://downloads.sourceforge.net/project/lcms/lcms/{version}/lcms2-{version}.tar.gz "

sha256="  <sha256-lcms2-{version}.tar.gz> "

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d lcms2-${version} && ! -x ./configure ]]; then
    cd lcms2-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static \
    --with-jpeg \
    --with-tiff

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'liblcms2*.la' -delete 2>/dev/null || true
}

post_install() {
  ls /usr/lib/liblcms2* 2>/dev/null || true
}
