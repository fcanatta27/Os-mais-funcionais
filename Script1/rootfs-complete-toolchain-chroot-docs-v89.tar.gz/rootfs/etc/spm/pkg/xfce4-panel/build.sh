name=xfce4-panel
version=4.20.0

source="\
  xfce4-panel-{version}.tar.bz2::https://archive.xfce.org/src/xfce/xfce4-panel/4.20/xfce4-panel-{version}.tar.bz2 \
"

sha256="\
  <sha256-xfce4-panel-{version}.tar.bz2> \
"

# Painel principal do Xfce (systray, menus, lançadores, etc).
deps=(glibc glib2 gtk3 libxfce4ui libxfce4util garcon exo xfconf)

build() {
  set -euo pipefail

  if [[ -d xfce4-panel-${version} ]]; then
    cd xfce4-panel-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
