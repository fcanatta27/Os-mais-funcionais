name=rxvt-unicode
version=9.31

source="\
  rxvt-unicode-{version}.tar.bz2::http://dist.schmorp.de/rxvt-unicode/rxvt-unicode-{version}.tar.bz2 \
"

sha256="\
  <sha256-rxvt-unicode-{version}.tar.bz2> \
"

deps=(glibc libX11 libXft freetype fontconfig)

build() {
  set -euo pipefail
  cd rxvt-unicode-${version}
  ./configure --prefix=/usr --enable-unicode3
  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
