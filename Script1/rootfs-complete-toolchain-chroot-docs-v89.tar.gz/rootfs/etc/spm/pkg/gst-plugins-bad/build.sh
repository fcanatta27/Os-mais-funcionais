
name=gst-plugins-bad
version=1.24.9

source="\
  gst-plugins-bad-{version}.tar.xz::https://gstreamer.freedesktop.org/src/gst-plugins-bad/gst-plugins-bad-{version}.tar.xz \
"

sha256="\
  <sha256-gst-plugins-bad-{version}.tar.xz> \
"

# Coleção "bad" de plugins GStreamer (APIs ainda instáveis ou menos mantidas).
# Habilitamos um build padrão, com testes/examples desabilitados, apoiado em ffmpeg e libs gráficas básicas.
deps=(glibc gstreamer gst-plugins-base glib2 orc ffmpeg libdrm wayland)

build() {
  set -euo pipefail
  : "${DESTDIR:?}"

  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dexamples=disabled \
    -Dtests=disabled

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  :
}
