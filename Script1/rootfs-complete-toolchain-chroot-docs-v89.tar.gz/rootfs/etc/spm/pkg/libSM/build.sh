name=libSM
version=1.2.4

source="\
  libSM-{version}.tar.xz::https://www.x.org/releases/individual/lib/libSM-{version}.tar.xz \
"

sha256="\
  <sha256-libSM-{version}.tar.xz> \
"

# Session Management library (SM), usada por toolkits e gerenciadores de sessão.
deps=(glibc libICE xorgproto)

build() {
  set -euo pipefail

  if [[ -d libSM-${version} ]]; then
    cd libSM-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libSM*.la' -delete 2>/dev/null || true
}

post_install() {
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --modversion sm 2>/dev/null || true
  fi
}
