name=tar
version=1.35

source="\
  tar-{version}.tar.xz::https://ftp.gnu.org/gnu/tar/tar-{version}.tar.xz \
"


# Use 'spm checksum tar' para preencher corretamente
sha256="\
  <sha256-tar-{version}.tar.xz> \
"


deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d tar-${version} && ! -x ./configure ]]; then
    cd tar-${version}
  fi

  ./configure \
    --prefix=/usr \
    --bindir=/usr/bin \
    --libexecdir=/usr/lib/tar \
    --sysconfdir=/etc

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"

  # Em sistemas com /bin separado, criamos link de compatibilidade
  if [[ -d "$DESTDIR/bin" ]]; then
    if [[ -x "$DESTDIR/usr/bin/tar" && ! -e "$DESTDIR/bin/tar" ]]; then
      ln -sv "../usr/bin/tar" "$DESTDIR/bin/tar"
    fi
  fi
}

post_install() {
  if command -v tar >/dev/null 2>&1; then
    tar --version | head -n1 || true
  fi
}
