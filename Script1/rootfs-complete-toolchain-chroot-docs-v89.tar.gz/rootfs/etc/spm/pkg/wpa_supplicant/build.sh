name=wpa_supplicant
version=2.11

source="\
  wpa_supplicant-{version}.tar.gz::https://w1.fi/releases/wpa_supplicant-{version}.tar.gz \
"

sha256="\
  <sha256-wpa_supplicant-{version}.tar.gz> \
"

# Suporte a WPA/WPA2/WPA3, usado para Wi-Fi.
deps=(glibc openssl libnl dbus readline)

build() {
  set -euo pipefail

  if [[ -d wpa_supplicant-${version} ]]; then
    cd wpa_supplicant-${version}
  fi

  cd wpa_supplicant

  # Usa defconfig padrão e ajusta opções mínimas.
  cp defconfig .config

  sed -i 's/^#\?CONFIG_TLS=openssl/CONFIG_TLS=openssl/' .config
  sed -i 's/^#\?CONFIG_BACKEND=file/CONFIG_BACKEND=file/' .config
  sed -i 's/^#\?CONFIG_CTRL_IFACE=unix/CONFIG_CTRL_IFACE=unix/' .config

  make BINDIR=/usr/sbin LIBDIR=/usr/lib -j"${JOBS:-1}"
  make DESTDIR="${DESTDIR}" BINDIR=/usr/sbin LIBDIR=/usr/lib install

  install -Dm644 README "${DESTDIR}/usr/share/doc/wpa_supplicant/README"
}

post_install() {
  command -v wpa_supplicant >/dev/null 2>&1 || true
}
