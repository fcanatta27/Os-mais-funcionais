# Definição de pacote SPM para sed (stream editor)
name=sed
version=4.9

# Tarball oficial do sed
source="sed-{version}.tar.xz::https://ftp.gnu.org/gnu/sed/sed-{version}.tar.xz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' enquanto não tiver o hash real.
sha256="-"

deps=(glibc)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:sed] Configurando sed-${version}..."
  "$srcdir/configure" \
    --prefix=/usr \
    --bindir=/usr/bin \
    --sysconfdir=/etc \
    --disable-static \
    --docdir=/usr/share/doc/sed-${version}

  echo "[spm:sed] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  if [[ "${SED_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:sed] Executando 'make check' (pode ser demorado)..."
    make check || echo "[spm:sed][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:sed] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  echo "[spm:sed] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do sed.
  :
}
