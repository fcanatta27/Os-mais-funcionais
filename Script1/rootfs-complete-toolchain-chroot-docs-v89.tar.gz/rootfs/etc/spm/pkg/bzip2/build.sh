# Definição de pacote SPM para bzip2 (utilitários e biblioteca de compressão bzip2)
name=bzip2
version=1.0.8

# Tarball oficial do bzip2
source="bzip2-{version}.tar.gz::https://sourceware.org/pub/bzip2/bzip2-{version}.tar.gz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' enquanto não tiver o hash real.
sha256="-"

# bzip2 precisa apenas de uma libc funcional (glibc) e toolchain básico
deps=(glibc)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:bzip2] Copiando fontes para diretório de build..."
  cp -a "$srcdir"/. .

  echo "[spm:bzip2] Construindo biblioteca compartilhada (Makefile-libbz2_so)..."
  make -f Makefile-libbz2_so

  echo "[spm:bzip2] Limpando e construindo binários estáticos/padrão..."
  make clean
  make -j"${JOBS:-1}"

  echo "[spm:bzip2] Preparando instalação em DESTDIR=${DESTDIR}..."
  mkdir -p "$DESTDIR/usr/bin" "$DESTDIR/usr/lib" "$DESTDIR/usr/include" "$DESTDIR/usr/share/man/man1"

  # Instalar executáveis
  install -m 755 bzip2      "$DESTDIR/usr/bin/bzip2"
  install -m 755 bzip2recover "$DESTDIR/usr/bin/bzip2recover"
  install -m 755 bunzip2    "$DESTDIR/usr/bin/bunzip2"
  install -m 755 bzcat      "$DESTDIR/usr/bin/bzcat"

  # Biblioteca compartilhada
  install -m 755 libbz2.so.1.0.8 "$DESTDIR/usr/lib/libbz2.so.1.0.8"
  ln -sf libbz2.so.1.0.8 "$DESTDIR/usr/lib/libbz2.so.1.0"
  ln -sf libbz2.so.1.0.8 "$DESTDIR/usr/lib/libbz2.so"

  # Headers
  install -m 644 bzlib.h "$DESTDIR/usr/include/bzlib.h"

  # Manpages
  install -m 644 bzip2.1 "$DESTDIR/usr/share/man/man1/bzip2.1"
  ( cd "$DESTDIR/usr/share/man/man1"
    ln -sf bzip2.1 bunzip2.1
    ln -sf bzip2.1 bzcat.1
    ln -sf bzip2.1 bzip2recover.1
  )

  echo "[spm:bzip2] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do bzip2.
  :
}
