name=gpm
version=1.20.7

source="  gpm-{version}.tar.bz2::https://anduin.linuxfromscratch.org/BLFS/gpm-{version}.tar.bz2 "

sha256="  <sha256-gpm-{version}.tar.bz2> "

deps=(glibc ncurses)

build() {
  set -euo pipefail

  if [[ -d gpm-${version} && ! -x ./configure ]]; then
    cd gpm-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --libdir=/usr/lib \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  mkdir -p "${DESTDIR}/etc"
  if [[ ! -f "${DESTDIR}/etc/gpm-root.conf" && -f conf/gpm-root.conf ]]; then
    install -m644 conf/gpm-root.conf "${DESTDIR}/etc/gpm-root.conf"
  fi
}

post_install() {
  if command -v gpm >/dev/null 2>&1; then
    gpm -v 2>/dev/null || true
  fi
}
