name=openssh
version=10.0p1

source="\
  openssh-{version}.tar.gz::https://ftp.openbsd.org/pub/OpenBSD/OpenSSH/portable/openssh-{version}.tar.gz \
"

sha256="\
  <sha256-openssh-{version}.tar.gz> \
"

deps=(glibc zlib openssl libxcrypt)

build() {
  set -euo pipefail
  cd openssh-${version}

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc/ssh \
    --with-privsep-path=/var/lib/sshd \
    --with-md5-passwords \
    --with-pam=no

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"

  mkdir -p "$DESTDIR/var/lib/sshd"
}

post_install() {
  ssh -V || true
}
