name=bspwm
version=0.9.10

source="\
  bspwm-{version}.tar.gz::https://github.com/baskerville/bspwm/archive/refs/tags/{version}.tar.gz \
"

sha256="\
  <sha256-bspwm-{version}.tar.gz> \
"

# Window manager em mosaico bspwm.
deps=(glibc libxcb xcb-util xcb-util-wm xcb-util-keysyms xcb-util-xrm)

build() {
  set -euo pipefail

  if [[ -d bspwm-${version} ]]; then
    cd bspwm-${version}
  fi

  make -j"${JOBS:-1}"
  make install PREFIX=/usr DESTDIR="${DESTDIR}"

  install -Dm644 examples/bspwmrc "${DESTDIR}/etc/skel/.config/bspwm/bspwmrc"
}

post_install() {
  :
}
