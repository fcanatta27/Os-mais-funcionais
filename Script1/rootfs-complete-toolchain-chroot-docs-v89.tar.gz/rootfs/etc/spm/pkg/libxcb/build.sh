name=libxcb
version=1.17.0

source="\
  libxcb-{version}.tar.xz::https://xorg.freedesktop.org/archive/individual/lib/libxcb-{version}.tar.xz \
"

sha256="\
  <sha256-libxcb-{version}.tar.xz> \
"

# Dependências: glibc, xorgproto, xcb-proto, libXau, libXdmcp
deps=(glibc xorgproto xcb-proto libXau libXdmcp)

build() {
  set -euo pipefail

  if [[ -d libxcb-${version} && ! -f libxcb-${version}/meson.build ]]; then
    cd libxcb-${version}
  elif [[ -d libxcb-${version} ]]; then
    cd libxcb-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Ddefault_library=shared \
    -Ddocs=disabled

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build

  # Remover .la se existirem (caso algum módulo crie)
  find "${DESTDIR}/usr/lib" -name 'libxcb*.la' -delete 2>/dev/null || true
}

post_install() {
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --modversion xcb 2>/dev/null || true
  fi
}
