name=sudo
version=1.9.17p2

source="  sudo-{version}.tar.gz::https://www.sudo.ws/dist/sudo-{version}.tar.gz "

sha256="  <sha256-sudo-{version}.tar.gz> "

# Dependências principais: glibc, Linux-PAM, openssl, zlib
deps=(glibc linux-pam openssl zlib)

build() {
  set -euo pipefail

  if [[ -d sudo-${version} && ! -x ./configure ]]; then
    cd sudo-${version}
  fi

  ./configure \
    --prefix=/usr \
    --libexecdir=/usr/lib/sudo \
    --sysconfdir=/etc \
    --with-rundir=/run/sudo \
    --with-pam \
    --with-editor=/usr/bin/vim \
    --with-env-editor \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  # Garante diretório sudoers.d
  mkdir -p "${DESTDIR}/etc/sudoers.d"
  chmod 750 "${DESTDIR}/etc/sudoers.d" || true

  # Arquivo PAM de sudo (caso Linux-PAM não tenha criado)
  local pamd="${DESTDIR}/etc/pam.d"
  mkdir -p "${pamd}"
  if [[ ! -f "${pamd}/sudo" ]]; then
    cat > "${pamd}/sudo" << 'EOF'
#%PAM-1.0
auth      include   system-auth
account   include   system-auth
password  include   system-auth
session   include   system-auth
EOF
  fi
}

post_install() {
  if command -v sudo >/dev/null 2>&1; then
    sudo -V | head -n5 || true
  fi
}
