name=xfce4-settings
version=4.20.0

source="\
  xfce4-settings-{version}.tar.bz2::https://archive.xfce.org/src/xfce/xfce4-settings/4.20/xfce4-settings-{version}.tar.bz2 \
"

sha256="\
  <sha256-xfce4-settings-{version}.tar.bz2> \
"

# Centro de configurações do Xfce (teclado, tema, display, etc).
deps=(glibc glib2 gtk3 libxfce4ui libxfce4util xfconf garcon)

build() {
  set -euo pipefail

  if [[ -d xfce4-settings-${version} ]]; then
    cd xfce4-settings-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
