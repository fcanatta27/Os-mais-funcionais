name=xfce4-appfinder
version=4.20.0

source="\
  xfce4-appfinder-{version}.tar.bz2::https://archive.xfce.org/src/xfce/xfce4-appfinder/4.20/xfce4-appfinder-{version}.tar.bz2 \
"

sha256="\
  <sha256-xfce4-appfinder-{version}.tar.bz2> \
"

# Lançador de aplicativos (Alt+F2) do Xfce.
deps=(glibc glib2 gtk3 libxfce4ui libxfce4util garcon exo)

build() {
  set -euo pipefail

  if [[ -d xfce4-appfinder-${version} ]]; then
    cd xfce4-appfinder-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
