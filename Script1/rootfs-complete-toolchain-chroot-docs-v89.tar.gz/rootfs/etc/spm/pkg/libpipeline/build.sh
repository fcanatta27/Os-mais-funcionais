name=libpipeline
version=1.5.8

source="      libpipeline-{version}.tar.gz::https://download.savannah.nongnu.org/releases/libpipeline/libpipeline-{version}.tar.gz     "

sha256="      <sha256-libpipeline-{version}.tar.gz>     "

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d libpipeline-${version} && ! -x ./configure ]]; then
    cd libpipeline-${version}
  fi

  ./configure \
    --prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"

  # Libs estáticas em geral não são desejadas no sistema final;
  # remova-as se não forem necessárias.
  find "$DESTDIR/usr/lib" -name 'libpipeline*.la' -delete 2>/dev/null || true
}

post_install() {
  # Não há um binário principal, é uma biblioteca. Apenas valida a presença da so.
  if ls "$DESTDIR"/usr/lib/libpipeline*.so* >/dev/null 2>&1; then
    : # OK
  fi
}
