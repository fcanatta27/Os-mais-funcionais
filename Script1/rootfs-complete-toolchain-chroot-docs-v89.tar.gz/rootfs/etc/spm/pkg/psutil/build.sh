name=psutil
version=7.0.0

source="\
  psutil-{version}.tar.gz::https://files.pythonhosted.org/packages/source/p/psutil/psutil-{version}.tar.gz \
"

sha256="\
  <sha256-psutil-{version}.tar.gz> \
"

deps=(python setuptools)

build() {
  set -euo pipefail
  if [[ -d psutil-${version} ]]; then
    cd psutil-${version}
  fi

  python setup.py build
  python setup.py install --root="${DESTDIR}" --optimize=1
}
