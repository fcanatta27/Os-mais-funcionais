# Definição de pacote SPM para Perl
name=perl
version=5.42.0

# Tarball oficial do Perl
source="perl-{version}.tar.xz::https://www.cpan.org/src/5.0/perl-{version}.tar.xz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' enquanto não tiver o hash real.
sha256="-"

# Perl depende de glibc e de bibliotecas de compressão/banco de dados
deps=(glibc gdbm zlib bzip2)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cp -a "$srcdir"/. "$builddir"/
  cd "$builddir"

  echo "[spm:perl] Configurando perl-${version}..."

  # Não queremos que Perl construa suas próprias cópias de zlib/bzip2.
  export BUILD_ZLIB=False
  export BUILD_BZIP2=0

  sh Configure -des \
    -Dprefix=/usr \
    -Dvendorprefix=/usr \
    -Dman1dir=/usr/share/man/man1 \
    -Dman3dir=/usr/share/man/man3 \
    -Dpager="/usr/bin/less -isR" \
    -Duseshrplib \
    -Dusethreads \
    -Dprivlib=/usr/lib/perl5/5.42/core_perl \
    -Darchlib=/usr/lib/perl5/5.42/core_perl \
    -Dsitelib=/usr/lib/perl5/5.42/site_perl \
    -Dsitearch=/usr/lib/perl5/5.42/site_perl \
    -Dvendorlib=/usr/lib/perl5/5.42/vendor_perl \
    -Dvendorarch=/usr/lib/perl5/5.42/vendor_perl

  echo "[spm:perl] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  if [[ "${PERL_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:perl] Executando 'make test' (pode ser bem demorado)..."
    make test || echo "[spm:perl][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:perl] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  # Limpar arquivos de registro de build que não são úteis em runtime
  find "$DESTDIR/usr/lib/perl5" -name perllocal.pod -delete 2>/dev/null || true
  find "$DESTDIR/usr/lib/perl5" -name ".packlist" -delete 2>/dev/null || true

  echo "[spm:perl] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do Perl.
  :
}
