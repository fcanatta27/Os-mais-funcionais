name=polkit-gnome
version=0.105

source="\
  polkit-gnome-{version}.tar.gz::https://ftp.gnome.org/pub/gnome/sources/polkit-gnome/0.105/polkit-gnome-{version}.tar.gz \
"

sha256="\
  <sha256-polkit-gnome-{version}.tar.gz> \
"

# Agente gráfico de autenticação para PolicyKit.
deps=(glibc glib2 gtk3 polkit)

build() {
  set -euo pipefail

  if [[ -d polkit-gnome-${version} ]]; then
    cd polkit-gnome-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --libexecdir=/usr/lib \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  # Binário típico: /usr/lib/polkit-gnome-authentication-agent-1
  ls /usr/lib/polkit-gnome-authentication-agent-1 2>/dev/null || true
}
