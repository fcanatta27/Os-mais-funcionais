name=glu
version=9.0.3

source="\
  glu-{version}.tar.xz::https://mesa.freedesktop.org/archive/glu/glu-{version}.tar.xz \
"

sha256="\
  <sha256-glu-{version}.tar.xz> \
"

# Implementação da biblioteca GLU baseada em Mesa.
deps=(glibc mesa)

build() {
  set -euo pipefail

  if [[ -d glu-${version} ]]; then
    cd glu-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
