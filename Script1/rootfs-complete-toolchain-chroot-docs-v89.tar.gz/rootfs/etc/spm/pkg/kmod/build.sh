name=kmod
version=34.2

source="\
  kmod-{version}.tar.xz::https://www.kernel.org/pub/linux/utils/kernel/kmod/kmod-{version}.tar.xz \
"

sha256="\
  <sha256-kmod-{version}.tar.xz> \
"

deps=(zlib xz zstd)

build() {
  set -euo pipefail

  cd "kmod-${version}"

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --with-rootlibdir=/usr/lib \
    --bindir=/usr/bin \
    --libdir=/usr/lib \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"

  # Alguns sistemas preferem links de compatibilidade em /sbin
  # Aqui criamos links se /sbin existir no DESTDIR
  if [[ -d "$DESTDIR/sbin" ]]; then
    for prog in depmod insmod lsmod modinfo modprobe rmmod; do
      if [[ -x "$DESTDIR/usr/bin/$prog" && ! -e "$DESTDIR/sbin/$prog" ]]; then
        ln -sv "../usr/bin/$prog" "$DESTDIR/sbin/$prog"
      fi
    done
  fi
}

post_install() {
  # Teste rápido: listar módulos carregados (não falha o install se der erro)
  if command -v lsmod >/dev/null 2>&1; then
    lsmod >/dev/null 2>&1 || true
  fi
}
