# Definição de pacote SPM para Iana-Etc (arquivos /etc/protocols e /etc/services)
name=iana-etc
version=20240913

# Tarball do projeto iana-etc (versão baseada em data, ajuste se desejar)
source="iana-etc-{version}.tar.gz::https://github.com/Mic92/iana-etc/releases/download/{version}/iana-etc-{version}.tar.gz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' enquanto não tiver o hash real.
sha256="-"

deps=()

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  # Diretório da árvore extraída do iana-etc
  local srcdir="$PWD"

  echo "[spm:iana-etc] Instalando /etc/protocols e /etc/services a partir de ${srcdir}..."

  mkdir -p "$DESTDIR/etc"

  # Não queremos misturar arquivos velhos com novos.
  # Opcionalmente, podemos fazer backup se quiser, mas o SPM já rastreia via manifesto.
  if [[ -f "$DESTDIR/etc/protocols" ]]; then
    rm -f "$DESTDIR/etc/protocols"
  fi
  if [[ -f "$DESTDIR/etc/services" ]]; then
    rm -f "$DESTDIR/etc/services"
  fi

  # Os arquivos "protocols" e "services" ficam na raiz do tarball iana-etc.
  install -m 644 "$srcdir/protocols" "$DESTDIR/etc/protocols"
  install -m 644 "$srcdir/services"  "$DESTDIR/etc/services"

  echo "[spm:iana-etc] Instalação de /etc/protocols e /etc/services concluída."
}

post_install() {
  # Nada específico necessário após instalação desses arquivos.
  :
}
