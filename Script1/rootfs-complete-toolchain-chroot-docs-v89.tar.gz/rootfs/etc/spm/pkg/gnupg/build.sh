name=gnupg
version=2.4.8

source="\
  gnupg-{version}.tar.bz2::https://gnupg.org/ftp/gcrypt/gnupg/gnupg-{version}.tar.bz2 \
"

sha256="\
  <sha256-gnupg-{version}.tar.bz2> \
"

deps=(glibc libgcrypt libassuan libksba npth pinentry)

build() {
  set -euo pipefail
  cd gnupg-${version}

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --enable-gpg-is-gpg2

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"
}

post_install() {
  gpg --version | head -n1 || true
}
