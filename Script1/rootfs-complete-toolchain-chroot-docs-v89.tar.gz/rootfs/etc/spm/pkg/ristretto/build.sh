name=ristretto
version=0.13.3

source="\
  ristretto-{version}.tar.bz2::https://archive.xfce.org/src/apps/ristretto/0.13/ristretto-{version}.tar.bz2 \
"

sha256="\
  <sha256-ristretto-{version}.tar.bz2> \
"

# Visualizador de imagens leve do Xfce.
deps=(glibc glib2 gtk3 exo tumbler gdk-pixbuf)

build() {
  set -euo pipefail

  if [[ -d ristretto-${version} ]]; then
    cd ristretto-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
