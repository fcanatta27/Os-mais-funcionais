name=xorg-applications
version=2025.1

# Meta pacote para agrupar aplicações Xorg básicas.
# Não possui fonte própria; registra apenas manifesto/meta.
source="xorg-applications-{version}.meta::local://spm/xorg-applications-{version}.meta"

# Ajuste esta lista conforme você for empacotando xterm, xclock, xset, xrdb, etc.
deps=(xclock xinit xterm xset xrdb xev xprop xrandr xsetroot)

build() {
  set -euo pipefail

  mkdir -p "${DESTDIR}/var/lib/spm/meta"

  local manifest="${DESTDIR}/var/lib/spm/meta/xorg-applications-${version}.txt"

  cat > "${manifest}" << 'EOF'
xorg-applications meta package

Conjunto sugerido de aplicações Xorg:
  - xterm
  - xclock
  - xinit
  - xset
  - xrdb
  - xev
  - xprop
  - xrandr
  - xsetroot

Instale estes pacotes via SPM para ter um ambiente Xorg de linha de comando completo.
EOF
}

post_install() {
  :
}
