name=git
version=2.50.1

source="\
  git-{version}.tar.xz::https://www.kernel.org/pub/software/scm/git/git-{version}.tar.xz \
"

sha256="\
  <sha256-git-{version}.tar.xz> \
"

deps=(glibc openssl zlib curl expat perl)

build() {
  set -euo pipefail
  if [[ -d git-${version} ]]; then
    cd git-${version}
  fi

  make configure
  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --with-openssl \
    --with-curl \
    --with-expat

  make -j"${JOBS:-1}" all
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  git --version 2>/dev/null || true
}
