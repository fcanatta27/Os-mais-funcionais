name=libXpm
version=3.5.17

source="\
  libXpm-{version}.tar.xz::https://www.x.org/releases/individual/lib/libXpm-{version}.tar.xz \
"

sha256="\
  <sha256-libXpm-{version}.tar.xz> \
"

deps=(glibc libX11 xorgproto)

build() {
  set -euo pipefail

  if [[ -d libXpm-${version} ]]; then
    cd libXpm-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
