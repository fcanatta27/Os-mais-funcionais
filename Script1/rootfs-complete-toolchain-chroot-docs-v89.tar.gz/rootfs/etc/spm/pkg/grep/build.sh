name=grep
version=3.12
source="grep-{version}.tar.xz::https://ftp.gnu.org/gnu/grep/grep-{version}.tar.xz"
sha256="-"
deps=(glibc pcre2)

build() {
  set -euo pipefail
  : "${DESTDIR:?}" "${TMP:?}"
  local src="$PWD"
  local b="$TMP/${name}-${version}-build"
  rm -rf "$b"; mkdir -p "$b"; cd "$b"

  "$src/configure" \
    --prefix=/usr \
    --disable-static \
    --with-pcre2

  make -j"${JOBS:-1}"
  [[ "${GREP_RUN_TESTS:-0}" == 1 ]] && make check || true
  make install DESTDIR="$DESTDIR"
}
