name=xcb-proto
version=1.17.0

source="\
  xcb-proto-{version}.tar.xz::https://xorg.freedesktop.org/archive/individual/proto/xcb-proto-{version}.tar.xz \
"

sha256="\
  <sha256-xcb-proto-{version}.tar.xz> \
"

deps=(glibc python)

build() {
  set -euo pipefail
  cd xcb-proto-${version}

  python3 setup.py install \
    --prefix=/usr \
    --root="${DESTDIR}" \
    --optimize=1
}

post_install() {
  python3 - <<'EOF' 2>/dev/null || true
import xcbgen
print("xcb-proto OK")
EOF
}
