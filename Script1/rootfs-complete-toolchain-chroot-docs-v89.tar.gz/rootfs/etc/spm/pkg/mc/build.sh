name=mc
version=4.8.33

source="\
  mc-{version}.tar.xz::https://ftp.midnight-commander.org/mc-{version}.tar.xz \
"

sha256="\
  <sha256-mc-{version}.tar.xz> \
"

# Dependências principais: glib, ncurses, slang (opcional)
deps=(glib ncurses slang)

build() {
  set -euo pipefail

  if [[ -d mc-${version} && ! -x ./configure ]]; then
    cd mc-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --enable-charset \
    --enable-vfs-sftp \
    --with-screen=ncurses \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  # Garante diretório de config global
  mkdir -p "${DESTDIR}/etc/mc"
}

post_install() {
  if command -v mc >/dev/null 2>&1; then
    mc --version || true
  fi
}
