name=libuv
version=1.50.0

source="\
  libuv-v{version}.tar.gz::https://dist.libuv.org/dist/v{version}/libuv-v{version}.tar.gz \
"

sha256="\
  <sha256-libuv-v{version}.tar.gz> \
"

deps=(glibc)

build() {
  set -euo pipefail

  srcdir="libuv-v${version}"
  [ -d "$srcdir" ] && cd "$srcdir"

  sh autogen.sh

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
