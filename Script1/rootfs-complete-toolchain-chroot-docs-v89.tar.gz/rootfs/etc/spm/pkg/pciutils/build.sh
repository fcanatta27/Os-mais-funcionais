name=pciutils
version=3.14.0

source="\
  pciutils-{version}.tar.xz::https://www.kernel.org/pub/software/utils/pciutils/pciutils-{version}.tar.xz \
"

sha256="\
  <sha256-pciutils-{version}.tar.xz> \
"

# Dependências principais: glibc, zlib
deps=(glibc zlib)

build() {
  set -euo pipefail

  if [[ -d pciutils-${version} && ! -f pciutils-${version}/Makefile ]]; then
    cd pciutils-${version}
  elif [[ -d pciutils-${version} ]]; then
    cd pciutils-${version}
  fi

  make -j"${JOBS:-1}" \
    PREFIX=/usr \
    SBINDIR=/usr/sbin \
    SHARED=yes \
    ZLIB=yes \
    IDSDIR=/usr/share/hwdata

  make install \
    PREFIX=/usr \
    SBINDIR=/usr/sbin \
    SHARED=yes \
    ZLIB=yes \
    IDSDIR=/usr/share/hwdata \
    DESTDIR="${DESTDIR}"
}

post_install() {
  if command -v lspci >/dev/null 2>&1; then
    lspci -nn 2>/dev/null || true
  fi
}
