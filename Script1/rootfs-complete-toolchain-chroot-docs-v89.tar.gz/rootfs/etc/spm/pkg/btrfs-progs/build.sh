name=btrfs-progs
version=6.16

source="  btrfs-progs-v{version}.tar.xz::https://kernel.org/pub/linux/kernel/people/kdave/btrfs-progs/btrfs-progs-v{version}.tar.xz "

sha256="  <sha256-btrfs-progs-v{version}.tar.xz> "

deps=(glibc zlib zstd lzo util-linux e2fsprogs)

build() {
  set -euo pipefail
  cd btrfs-progs-v${version}

  ./configure     --prefix=/usr     --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
