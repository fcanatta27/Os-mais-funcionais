name=linux-firmware
version=20240610

source="\
  linux-firmware-{version}.tar.gz::https://git.kernel.org/pub/scm/linux/kernel/git/firmware/linux-firmware.git/snapshot/linux-firmware-{version}.tar.gz \
"

sha256="\
  <sha256-linux-firmware-{version}.tar.gz> \
"

deps=()

build() {
  set -euo pipefail
  cd linux-firmware-${version}

  mkdir -p "$DESTDIR/usr/lib/firmware"
  cp -a * "$DESTDIR/usr/lib/firmware"

  # Remove docs e arquivos inúteis
  rm -rf "$DESTDIR/usr/lib/firmware"/{WHENCE,README*,LICEN*} 2>/dev/null || true
}

post_install() {
  echo "[linux-firmware] firmware instalado em /usr/lib/firmware"
}
