name=valgrind
version=3.25.1

source="  valgrind-{version}.tar.bz2::https://sourceware.org/pub/valgrind/valgrind-{version}.tar.bz2 "

sha256="  <sha256-valgrind-{version}.tar.bz2> "

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d valgrind-${version} && ! -x ./configure ]]; then
    cd valgrind-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  if command -v valgrind >/dev/null 2>&1; then
    valgrind --version || true
  fi
}
