name=libXinerama
version=1.1.5

source="\
  libXinerama-{version}.tar.xz::https://www.x.org/releases/individual/lib/libXinerama-{version}.tar.xz \
"

sha256="\
  <sha256-libXinerama-{version}.tar.xz> \
"

deps=(glibc libX11 xorgproto)

build() {
  set -euo pipefail

  if [[ -d libXinerama-${version} ]]; then
    cd libXinerama-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
