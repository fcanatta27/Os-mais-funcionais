# Definição de pacote SPM para ncurses (biblioteca de UI em terminal)
name=ncurses
version=6.5

# Tarball oficial do ncurses
source="ncurses-{version}.tar.gz::https://ftp.gnu.org/pub/gnu/ncurses/ncurses-{version}.tar.gz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' enquanto não tiver o hash real.
sha256="-"

deps=(glibc)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:ncurses] Configurando ncurses-${version} (wide-char)..."
  "$srcdir/configure" \
    --prefix=/usr \
    --mandir=/usr/share/man \
    --with-shared \
    --without-debug \
    --without-normal \
    --enable-widec \
    --with-termlib \
    --enable-pc-files \
    --with-pkg-config-libdir=/usr/lib/pkgconfig

  echo "[spm:ncurses] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  echo "[spm:ncurses] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  # Criar links de compatibilidade para libncurses
  # ncurses wide instala libncursesw; muitos programas ainda procuram libncurses.so
  if [[ -f "$DESTDIR/usr/lib/libncursesw.so" ]]; then
    ln -sf libncursesw.so "$DESTDIR/usr/lib/libncurses.so"
  fi
  if [[ -f "$DESTDIR/usr/lib/libtinfow.so" ]]; then
    ln -sf libtinfow.so "$DESTDIR/usr/lib/libtinfo.so"
  fi

  # Ajustar terminfo global em /usr/share/terminfo (já padrão, mas garantimos dir)
  mkdir -p "$DESTDIR/usr/share/terminfo"

  echo "[spm:ncurses] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do ncurses.
  :
}
