name=systemd
version=257.8

source="\
  systemd-{version}.tar.gz::https://github.com/systemd/systemd-stable/archive/refs/tags/v{version}.tar.gz \
"

sha256="\
  <sha256-systemd-{version}.tar.gz> \
"

# Conjunto de dependências típico para um build razoável de systemd.
# Ajuste conforme os pacotes disponíveis no seu SPM.
deps=(glibc pkgconf meson ninja libcap libxcrypt kmod util-linux zstd xz lz4 openssl libffi gperf expat)

build() {
  set -euo pipefail

  # O tarball do systemd-stable extrai para algo como systemd-stable-257.8;
  # damos suporte tanto a systemd-${version} quanto a systemd-stable-${version}.
  if [[ -d systemd-${version} && -f systemd-${version}/meson.build ]]; then
    cd systemd-${version}
  elif [[ -d systemd-stable-${version} && -f systemd-stable-${version}/meson.build ]]; then
    cd systemd-stable-${version}
  else
    echo "[spm] não foi possível encontrar diretório de código-fonte do systemd" >&2
    exit 1
  fi

  # Diretório de build separado
  rm -rf build
  meson setup build \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --libdir=/usr/lib \
    --buildtype=release \
    -Ddefault-libraries=shared \
    -Dlink-udev-shared=false \
    -Dfirstboot=false \
    -Dldconfig=false \
    -Dcreate-log-dirs=false \
    -Dsysvinit-path= \
    -Dsysvrcnd-path= \
    -Dinstall-sysconfdir=true

  meson compile -C build -j"${JOBS:-1}"

  DESTDIR="$DESTDIR" meson install -C build

  # systemd espera alguns diretórios padrão existirem
  mkdir -p "$DESTDIR"/var/log/journal "$DESTDIR"/var/lib/systemd
}

post_install() {
  # Não tentamos iniciar serviços, apenas verificamos a versão do systemd
  if command -v systemd-analyze >/dev/null 2>&1; then
    systemd-analyze --version || true
  fi
}
