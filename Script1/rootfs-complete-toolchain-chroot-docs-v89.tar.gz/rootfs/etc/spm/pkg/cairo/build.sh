name=cairo
version=1.18.0

source="\
  cairo-{version}.tar.xz::https://cairographics.org/releases/cairo-{version}.tar.xz \
"

sha256="\
  <sha256-cairo-{version}.tar.xz> \
"

deps=(glibc pixman fontconfig freetype libpng zlib)

build() {
  set -euo pipefail

  if [[ -d cairo-${version} ]]; then
    cd cairo-${version}
  fi

  ./configure \
    --prefix=/usr \
    --enable-xlib \
    --enable-xlib-xrender \
    --enable-ft \
    --enable-png \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libcairo*.la' -delete 2>/dev/null || true
}

post_install() {
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --modversion cairo 2>/dev/null || true
  fi
}
