name=libnl
version=3.9.0

source="\
  libnl-{version}.tar.gz::https://github.com/thom311/libnl/releases/download/libnl3_{version}/libnl-{version}.tar.gz \
"

sha256="\
  <sha256-libnl-{version}.tar.gz> \
"

# Biblioteca de alto nível para netlink (usada por iw, wpa_supplicant).
deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d libnl-${version} ]]; then
    cd libnl-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libnl-*.la' -delete 2>/dev/null || true
}

post_install() {
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --modversion libnl-3.0 2>/dev/null || true
  fi
}
