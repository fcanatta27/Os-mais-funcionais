name=man-db
version=2.13.1

source="\
  man-db-{version}.tar.xz::https://download.savannah.gnu.org/releases/man-db/man-db-{version}.tar.xz \
"

sha256="\
  <sha256-man-db-{version}.tar.xz> \
"

# man-db depende de groff e libpipeline
deps=(glibc groff libpipeline)

build() {
  set -euo pipefail

  if [[ -d man-db-${version} && ! -x ./configure ]]; then
    cd man-db-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --disable-setuid \
    --with-systemdsystemunitdir=/usr/lib/systemd/system

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"

  # Configuração padrão do mandb
  mkdir -p "$DESTDIR/etc"
  if [[ -f src/man_db.conf ]]; then
    cp -v src/man_db.conf "$DESTDIR/etc/man_db.conf"
  fi
}

post_install() {
  if command -v man >/dev/null 2>&1; then
    man --version | head -n1 || true
  fi
}
