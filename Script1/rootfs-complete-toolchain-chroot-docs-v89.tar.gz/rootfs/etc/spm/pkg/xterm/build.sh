name=xterm
version=401

source="\
  xterm-{version}.tgz::https://invisible-island.net/datafiles/release/xterm-{version}.tgz \
"

sha256="\
  <sha256-xterm-{version}.tgz> \
"

# Terminal clássico X, com suporte a 256 cores, UTF-8 etc.
deps=(glibc xorg-server libX11 libXaw libXmu libXt libXft libXrender ncurses)

build() {
  set -euo pipefail

  if [[ -d xterm-${version} ]]; then
    cd xterm-${version}
  fi

  # Use um prefixo padrão e asegure UTF-8 e 256 cores.
  ./configure \
    --prefix=/usr \
    --with-app-defaults=/usr/share/X11/app-defaults \
    --enable-256-color \
    --enable-wide-chars \
    --enable-luit \
    --enable-vt52 \
    --enable-logging \
    --with-utmpsetgid \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  # Exemplos de app-defaults podem ser aproveitados depois para temas.
}

post_install() {
  command -v xterm >/dev/null 2>&1 || true
}
