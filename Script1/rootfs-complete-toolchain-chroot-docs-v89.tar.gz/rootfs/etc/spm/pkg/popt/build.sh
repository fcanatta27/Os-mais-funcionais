name=popt
version=1.19

source="\
  popt-{version}.tar.gz::https://ftp.osuosl.org/pub/rpm/popt/releases/popt-1.x/popt-{version}.tar.gz \
"

sha256="\
  <sha256-popt-{version}.tar.gz> \
"

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d popt-${version} ]]; then
    cd popt-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
