name=lightdm
version=1.32.0

source="\
  lightdm-{version}.tar.xz::https://github.com/canonical/lightdm/releases/download/{version}/lightdm-{version}.tar.xz \
"

sha256="\
  <sha256-lightdm-{version}.tar.xz> \
"

# Display manager leve, com suporte a greeters GTK.
deps=(glibc glib2 pam systemd dbus gtk3 xorg-server)

build() {
  set -euo pipefail

  if [[ -d lightdm-${version} ]]; then
    cd lightdm-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --libdir=/usr/lib \
    --with-systemd \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  # Arquivo de serviço systemd (se não vier pronto)
  mkdir -p "${DESTDIR}/usr/lib/systemd/system"
  cat > "${DESTDIR}/usr/lib/systemd/system/lightdm.service" << 'EOF'
[Unit]
Description=LightDM Display Manager
Documentation=man:lightdm(1)
Conflicts=getty@tty7.service
After=systemd-user-sessions.service getty@tty7.service plymouth-quit.service systemd-logind.service
Requires=systemd-user-sessions.service systemd-logind.service

[Service]
ExecStart=/usr/sbin/lightdm
Restart=always
IgnoreSIGPIPE=no
BusName=org.freedesktop.DisplayManager

[Install]
Alias=display-manager.service
EOF
}

post_install() {
  :
}
