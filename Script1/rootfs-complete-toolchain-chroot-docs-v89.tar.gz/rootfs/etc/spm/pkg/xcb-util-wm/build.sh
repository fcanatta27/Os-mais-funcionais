name=xcb-util-wm
version=0.4.2

source="\
  xcb-util-wm-{version}.tar.xz::https://xcb.freedesktop.org/dist/xcb-util-wm-{version}.tar.xz \
"

sha256="\
  <sha256-xcb-util-wm-{version}.tar.xz> \
"

# Extensões de window manager para XCB.
deps=(glibc libxcb)

build() {
  set -euo pipefail

  if [[ -d xcb-util-wm-${version} ]]; then
    cd xcb-util-wm-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
