name=net-tools
version=2.10

source="\
 net-tools-{version}.tar.xz::https://downloads.sourceforge.net/project/net-tools/net-tools-{version}.tar.xz \
"

sha256="\
 <sha256-net-tools-{version}.tar.xz> \
"

deps=(glibc)

build() {
 set -euo pipefail
 cd net-tools-${version}
 yes "" | make config
 make -j"${JOBS:-1}"
 make install DESTDIR="${DESTDIR}"
}
