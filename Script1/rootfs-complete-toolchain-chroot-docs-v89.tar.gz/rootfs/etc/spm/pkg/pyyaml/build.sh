name=pyyaml
version=6.0.2

source="\
  PyYAML-{version}.tar.gz::https://files.pythonhosted.org/packages/source/P/PyYAML/PyYAML-{version}.tar.gz \
"

sha256="\
  <sha256-PyYAML-{version}.tar.gz> \
"

deps=(python setuptools)

build() {
  set -euo pipefail
  if [[ -d PyYAML-${version} ]]; then
    cd PyYAML-${version}
  fi

  python setup.py build
  python setup.py install --root="${DESTDIR}" --optimize=1
}
