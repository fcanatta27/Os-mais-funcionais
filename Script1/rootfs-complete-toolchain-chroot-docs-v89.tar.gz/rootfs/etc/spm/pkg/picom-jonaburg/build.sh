name=picom-jonaburg
version=git-2025.01

source="\
  picom-jonaburg-{version}.tar.gz::https://github.com/jonaburg/picom/archive/refs/heads/master.tar.gz \
"

sha256="\
  <sha256-picom-jonaburg-{version}.tar.gz> \
"

# Outro fork com animações e efeitos avançados.
deps=(glibc pixman libX11 libXcomposite libXdamage libXext libXrender libXrandr libconfig libxcb xcb-util xorgproto)

build() {
  set -euo pipefail

  srcdir="$(find . -maxdepth 1 -type d -name 'picom-*' | head -n1)"
  [ -n "$srcdir" ] && cd "$srcdir"

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --buildtype=release \
    -Dwith_docs=false \
    -Dwith_xrender=true \
    -Dwith_xext=true

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  command -v picom >/dev/null 2>&1 || true
}
