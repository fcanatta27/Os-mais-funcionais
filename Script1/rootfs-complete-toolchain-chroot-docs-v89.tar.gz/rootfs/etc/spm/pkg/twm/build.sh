name=twm
version=1.0.13.1

source="\
  twm-{version}.tar.xz::https://www.x.org/releases/individual/app/twm-{version}.tar.xz \
"

sha256="\
  <sha256-twm-{version}.tar.xz> \
"

# Window manager clássico Xorg.
deps=(glibc xorg-server libX11 libXext libXmu libXt xorgproto xbitmaps)

build() {
  set -euo pipefail

  if [[ -d twm-${version} ]]; then
    cd twm-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  command -v twm >/dev/null 2>&1 || true
}
