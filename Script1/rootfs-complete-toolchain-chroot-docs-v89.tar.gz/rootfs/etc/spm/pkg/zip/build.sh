name=zip
version=3.0

source="\
  zip{version/./}.tar.gz::https://downloads.sourceforge.net/infozip/zip30.tar.gz \
"

sha256="\
  <sha256-zip{version/./}.tar.gz> \
"

deps=(glibc)

build() {
  set -euo pipefail

  # O tarball costuma extrair para zip30
  local srcdir
  srcdir=$(find . -maxdepth 1 -type d -name 'zip*' | head -n1 || true)
  if [[ -n "${srcdir:-}" ]]; then
    cd "${srcdir}"
  fi

  # Build padrão para Unix
  make -f unix/Makefile generic -j"${JOBS:-1}"

  # Instala binário e manpage
  install -Dm755 zip "${DESTDIR}/usr/bin/zip"

  if [[ -f man/zip.1 ]]; then
    install -Dm644 man/zip.1 "${DESTDIR}/usr/share/man/man1/zip.1"
  fi
}

post_install() {
  if command -v zip >/dev/null 2>&1; then
    zip -h >/dev/null 2>&1 || true
  fi
}
