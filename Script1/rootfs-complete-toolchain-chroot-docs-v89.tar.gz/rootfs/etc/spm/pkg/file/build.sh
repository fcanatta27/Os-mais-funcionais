# Definição de pacote SPM para file (libmagic e utilitário file)
name=file
version=5.46

# Tarball oficial do file
source="file-{version}.tar.gz::https://astron.com/pub/file/file-{version}.tar.gz"

sha256="-"

# file depende de zlib, zstd e bzip2 para suporte a múltiplos formatos
deps=(glibc zlib zstd bzip2)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:file] Configurando file-${version}..."
  "$srcdir/configure" \
    --prefix=/usr \
    --sysconfdir=/etc \
    --enable-fsect-man5 \
    --enable-shared \
    --disable-static

  echo "[spm:file] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  # Testes opcionais
  if [[ "${FILE_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:file] Executando 'make check'..."
    make check || echo "[spm:file][WARN] Alguns testes falharam."
  fi

  echo "[spm:file] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  echo "[spm:file] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional
  :
}
