name=ntp
version=4.2.8p18

source="\
 ntp-{version}.tar.gz::https://archive.ntp.org/ntp4/ntp-{version}.tar.gz \
"

sha256="\
 <sha256-ntp-{version}.tar.gz> \
"

deps=(glibc openssl)

build() {
 set -euo pipefail
 cd ntp-${version}
 ./configure \
   --prefix=/usr \
   --sysconfdir=/etc \
   --enable-linuxcaps \
   --with-yielding-select=yes
 make -j"${JOBS:-1}"
 make install DESTDIR="${DESTDIR}"
 mkdir -p "${DESTDIR}/var/lib/ntp"
}
