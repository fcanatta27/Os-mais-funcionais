name=sqlite
version=3510200

source="  sqlite-autoconf-{version}.tar.gz::https://www.sqlite.org/2025/sqlite-autoconf-{version}.tar.gz "

sha256="  <sha256-sqlite-autoconf-{version}.tar.gz> "

deps=(glibc readline zlib)

build() {
  set -euo pipefail

  if [[ -d sqlite-autoconf-${version} && ! -x ./configure ]]; then
    cd sqlite-autoconf-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static \
    --enable-fts5 \
    --enable-rtree \
    --enable-json1

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  if command -v sqlite3 >/dev/null 2>&1; then
    sqlite3 --version || true
  fi
}
