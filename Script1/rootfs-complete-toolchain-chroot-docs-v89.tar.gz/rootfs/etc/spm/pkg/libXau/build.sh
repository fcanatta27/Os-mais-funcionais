name=libXau
version=1.0.12

source="\
  libXau-{version}.tar.xz::https://www.x.org/pub/individual/lib/libXau-{version}.tar.xz \
"

sha256="\
  <sha256-libXau-{version}.tar.xz> \
"

deps=(glibc xorgproto)

build() {
  set -euo pipefail

  if [[ -d libXau-${version} && ! -x ./configure ]]; then
    cd libXau-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  # Remove .la se existirem
  find "${DESTDIR}/usr/lib" -name 'libXau*.la' -delete 2>/dev/null || true
}

post_install() {
  ls /usr/lib/libXau* 2>/dev/null || true
}
