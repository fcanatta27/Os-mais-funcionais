name=xdg-desktop-portal
version=1.18.4

source="\
  xdg-desktop-portal-{version}.tar.xz::https://github.com/flatpak/xdg-desktop-portal/releases/download/{version}/xdg-desktop-portal-{version}.tar.xz \
"

sha256="\
  <sha256-xdg-desktop-portal-{version}.tar.xz> \
"

deps=(glibc glib2 dbus libpipewire)

build() {
  set -euo pipefail
  cd xdg-desktop-portal-${version}
  meson setup build \
    --prefix=/usr \
    -Dsystemd=true \
    -Dtests=false
  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}
