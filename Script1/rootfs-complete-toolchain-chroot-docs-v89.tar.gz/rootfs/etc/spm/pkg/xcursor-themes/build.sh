name=xcursor-themes
version=1.0.7

source="\
  xcursor-themes-{version}.tar.xz::https://www.x.org/pub/individual/data/xcursor-themes/xcursor-themes-{version}.tar.xz \
"

sha256="\
  <sha256-xcursor-themes-{version}.tar.xz> \
"

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d xcursor-themes-${version} && -x xcursor-themes-${version}/configure ]]; then
    cd xcursor-themes-${version}
  elif [[ -d xcursor-themes-${version} ]]; then
    cd xcursor-themes-${version}
  fi

  ./configure \
    --prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  ls /usr/share/icons 2>/dev/null || true
}
