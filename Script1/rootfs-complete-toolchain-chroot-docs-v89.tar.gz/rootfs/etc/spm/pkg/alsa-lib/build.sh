name=alsa-lib
version=1.2.12

source="\
  alsa-lib-{version}.tar.bz2::https://www.alsa-project.org/files/pub/lib/alsa-lib-{version}.tar.bz2 \
"

sha256="\
  <sha256-alsa-lib-{version}.tar.bz2> \
"

# Biblioteca principal do ALSA (libasound).
deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d alsa-lib-${version} ]]; then
    cd alsa-lib-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libasound.la' -delete 2>/dev/null || true
}

post_install() {
  :
}
