name=procps-ng
version=4.0.5

source="\
  procps-ng-{version}.tar.xz::https://sourceforge.net/projects/procps-ng/files/Production/procps-ng-{version}.tar.xz/download \
"

sha256="\
  <sha256-procps-ng-{version}.tar.xz> \
"

# Dependências principais: glibc, ncurses.
deps=(glibc ncurses)

build() {
  set -euo pipefail

  if [[ -d procps-ng-${version} && ! -x ./configure ]]; then
    cd procps-ng-${version}
  fi

  ./configure \
    --prefix=/usr \
    --docdir=/usr/share/doc/procps-ng-${version} \
    --disable-static \
    --disable-kill

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"
}

post_install() {
  # Teste leve: verifica se ps responde
  if command -v ps >/dev/null 2>&1; then
    ps -o pid,cmd | head -n5 || true
  fi
}
