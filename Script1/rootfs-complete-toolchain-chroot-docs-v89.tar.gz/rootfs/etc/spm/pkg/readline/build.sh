# Definição de pacote SPM para readline (biblioteca de edição de linha)
name=readline
version=8.3

# Tarball oficial do readline
source="readline-{version}.tar.gz::https://ftp.gnu.org/gnu/readline/readline-{version}.tar.gz"

sha256="-"

# readline depende de libc; ncurses é opcional mas recomendado
deps=(glibc ncurses)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:readline] Configurando readline-${version}..."
  "$srcdir/configure" \
    --prefix=/usr \
    --disable-static \
    --with-curses

  echo "[spm:readline] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  # Testes opcionais
  if [[ "${READLINE_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:readline] Executando 'make check'..."
    make check || echo "[spm:readline][WARN] Alguns testes falharam."
  fi

  echo "[spm:readline] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  echo "[spm:readline] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional
  :
}
