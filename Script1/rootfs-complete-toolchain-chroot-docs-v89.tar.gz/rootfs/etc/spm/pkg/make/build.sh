name=make
version=4.4.1

source="      make-{version}.tar.gz::https://ftp.gnu.org/gnu/make/make-{version}.tar.gz     "

sha256="      <sha256-make-{version}.tar.gz>     "

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d make-${version} && ! -x ./configure ]]; then
    cd make-${version}
  fi

  ./configure \
    --prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"

  # Em sistemas que ainda usam /bin separado, podemos instalar um symlink
  if [[ -d "$DESTDIR/bin" ]]; then
    if [[ -x "$DESTDIR/usr/bin/make" && ! -e "$DESTDIR/bin/make" ]]; then
      ln -sv "../usr/bin/make" "$DESTDIR/bin/make"
    fi
  fi
}

post_install() {
  if command -v make >/dev/null 2>&1; then
    make --version | head -n1 || true
  fi
}
