name=linux-pam
version=1.7.1

source="  Linux-PAM-{version}.tar.xz::https://github.com/linux-pam/linux-pam/releases/download/v{version}/Linux-PAM-{version}.tar.xz "

sha256="  <sha256-Linux-PAM-{version}.tar.xz> "

# PAM é base de autenticação: depende de glibc, libxcrypt, libcap, shadow (para /etc/shadow).
deps=(glibc libxcrypt libcap shadow)

build() {
  set -euo pipefail

  if [[ -d Linux-PAM-${version} && ! -x ./configure ]]; then
    cd Linux-PAM-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --libdir=/usr/lib \
    --includedir=/usr/include/security \
    --enable-securedir=/usr/lib/security \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  # Garante diretório de configuração do PAM
  mkdir -p "${DESTDIR}/etc/pam.d"

  # Cria um stack genérico system-auth somente se ainda não existir
  local pamd="${DESTDIR}/etc/pam.d"

  if [[ ! -f "${pamd}/system-auth" ]]; then
    cat > "${pamd}/system-auth" << 'EOF'
# system-auth - pilha padrão de autenticação
auth      required   pam_unix.so
account   required   pam_unix.so
password  required   pam_unix.so
session   required   pam_unix.so
EOF
  fi

  # Arquivos básicos usando system-auth
  for svc in login passwd su sudo; do
    if [[ ! -f "${pamd}/${svc}" ]]; then
      cat > "${pamd}/${svc}" << 'EOF'
#%PAM-1.0
auth      include   system-auth
account   include   system-auth
password  include   system-auth
session   include   system-auth
EOF
    fi
  done
}

post_install() {
  # Apenas informa que os arquivos de configuração base estão presentes
  if [[ -d /etc/pam.d ]]; then
    echo "[linux-pam] Arquivos PAM instalados em /etc/pam.d."
  fi
}
