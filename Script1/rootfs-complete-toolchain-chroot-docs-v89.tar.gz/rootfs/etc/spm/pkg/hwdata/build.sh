name=hwdata
version=0.398

source="  hwdata-{version}.tar.gz::https://github.com/vcrhonek/hwdata/releases/download/v{version}/hwdata-{version}.tar.gz "

sha256="  <sha256-hwdata-{version}.tar.gz> "

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d hwdata-${version} && ! -x ./configure ]]; then
    cd hwdata-${version}
  fi

  if [[ -x ./configure ]]; then
    ./configure --prefix=/usr
    make -j"${JOBS:-1}"
    make install DESTDIR="${DESTDIR}"
  else
    make -j"${JOBS:-1}" prefix=/usr
    make install DESTDIR="${DESTDIR}" prefix=/usr
  fi
}

post_install() {
  ls /usr/share/hwdata 2>/dev/null || true
}
