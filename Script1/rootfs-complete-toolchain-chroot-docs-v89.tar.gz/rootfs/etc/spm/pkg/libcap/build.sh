name=libcap
version=2.76

source="  libcap-{version}.tar.xz::https://www.kernel.org/pub/linux/libs/security/linux-privs/libcap2/libcap-{version}.tar.xz "

sha256="  <sha256-libcap-{version}.tar.xz> "

# Versão com suporte ao módulo PAM (pam_cap) – requer Linux-PAM.
deps=(glibc linux-pam)

build() {
  set -euo pipefail

  if [[ -d libcap-${version} && ! -f libcap-${version}/Makefile ]]; then
    cd libcap-${version}
  elif [[ -d libcap-${version} ]]; then
    cd libcap-${version}
  fi

  # Build principal (bibliotecas e ferramentas)
  make prefix=/usr lib=lib

  make prefix=/usr lib=lib DESTDIR="${DESTDIR}" install

  # Remove possíveis .la
  find "${DESTDIR}/usr/lib" -name 'libcap*.la' -delete 2>/dev/null || true

  # Build e instalação do módulo pam_cap, se o diretório existir
  if [[ -d pam_cap ]]; then
    make -C pam_cap

    mkdir -p "${DESTDIR}/usr/lib/security" "${DESTDIR}/etc/security"
    if [[ -f pam_cap/pam_cap.so ]]; then
      install -m755 pam_cap/pam_cap.so "${DESTDIR}/usr/lib/security/pam_cap.so"
    fi
    if [[ -f pam_cap/capability.conf ]]; then
      install -m644 pam_cap/capability.conf "${DESTDIR}/etc/security/capability.conf"
    fi
  fi
}

post_install() {
  if command -v getcap >/dev/null 2>&1; then
    getcap --help >/dev/null 2>&1 || true
  fi
}
