name=iconv
version=virtual-1

source=""

sha256=""

# Meta-package: o suporte a iconv é fornecido pela glibc.
deps=(glibc)

build() {
  set -euo pipefail
  echo "iconv é fornecido pela glibc; nenhum build necessário."
}

post_install() {
  :
}
