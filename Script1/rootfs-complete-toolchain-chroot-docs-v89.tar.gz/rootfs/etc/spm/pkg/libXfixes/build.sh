name=libXfixes
version=6.0.1

source="\
  libXfixes-{version}.tar.xz::https://www.x.org/releases/individual/lib/libXfixes-{version}.tar.xz \
"

sha256="\
  <sha256-libXfixes-{version}.tar.xz> \
"

deps=(glibc libX11 xorgproto)

build() {
  set -euo pipefail

  if [[ -d libXfixes-${version} ]]; then
    cd libXfixes-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
