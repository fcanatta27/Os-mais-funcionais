# Definição de pacote SPM para expat (XML parser)
name=expat
version=2.7.1

# Tarball oficial do expat
# Atenção: ajuste R_2_7_1 se a convenção mudar na upstream.
source="expat-{version}.tar.xz::https://github.com/libexpat/libexpat/releases/download/R_2_7_1/expat-{version}.tar.xz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
sha256="-"

deps=(glibc)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:expat] Configurando expat-${version}..."
  "$srcdir/configure" \
    --prefix=/usr \
    --disable-static \
    --docdir=/usr/share/doc/expat-${version}

  echo "[spm:expat] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  if [[ "${EXPAT_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:expat] Executando 'make check'..."
    make check || echo "[spm:expat][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:expat] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  echo "[spm:expat] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do expat.
  :
}
