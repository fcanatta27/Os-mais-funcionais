name=texinfo
version=7.2

source="\
  texinfo-{version}.tar.xz::https://ftp.gnu.org/gnu/texinfo/texinfo-{version}.tar.xz \
"


sha256="\
  <sha256-texinfo-{version}.tar.xz> \
"


# texinfo usa ncurses para o 'info' interativo e depende de glibc.
deps=(glibc ncurses)

build() {
  set -euo pipefail

  if [[ -d texinfo-${version} && ! -x ./configure ]]; then
    cd texinfo-${version}
  fi

  ./configure \
    --prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"

  # Instala documentação extra, se existir
  if [[ -d doc ]]; then
    mkdir -p "$DESTDIR/usr/share/doc/texinfo-${version}"
    cp -v doc/* "$DESTDIR/usr/share/doc/texinfo-${version}" 2>/dev/null || true
  fi
}

post_install() {
  if command -v info >/dev/null 2>&1; then
    info --version | head -n1 || true
  fi
}
