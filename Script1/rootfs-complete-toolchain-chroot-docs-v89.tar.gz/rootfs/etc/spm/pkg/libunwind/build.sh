name=libunwind
version=1.8.2

source="\
  libunwind-{version}.tar.gz::https://github.com/libunwind/libunwind/releases/download/v{version}/libunwind-{version}.tar.gz \
"

sha256="\
  <sha256-libunwind-{version}.tar.gz> \
"

deps=(glibc)

build() {
  set -euo pipefail
  if [[ -d libunwind-${version} ]]; then
    cd libunwind-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
