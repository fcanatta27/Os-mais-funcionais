# Definição de pacote SPM para autoconf (gerador de scripts configure)
name=autoconf
version=2.72

# Tarball oficial do autoconf
source="autoconf-{version}.tar.xz::https://ftp.gnu.org/gnu/autoconf/autoconf-{version}.tar.xz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
sha256="-"

# autoconf depende de m4 e Perl
deps=(glibc m4 perl)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:autoconf] Configurando autoconf-${version}..."
  "$srcdir/configure" \
    --prefix=/usr \
    --disable-static \
    --docdir=/usr/share/doc/autoconf-${version}

  echo "[spm:autoconf] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  if [[ "${AUTOCONF_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:autoconf] Executando 'make check' (pode ser demorado)..."
    make check || echo "[spm:autoconf][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:autoconf] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  echo "[spm:autoconf] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do autoconf.
  :
}
