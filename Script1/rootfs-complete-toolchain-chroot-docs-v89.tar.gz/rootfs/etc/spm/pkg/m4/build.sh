# Definição de pacote SPM para m4 (macro processor)
name=m4
version=1.4.20

# Tarball oficial do m4
source="m4-{version}.tar.xz::https://ftp.gnu.org/gnu/m4/m4-{version}.tar.xz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' enquanto não tiver o hash real.
sha256="-"

# m4 precisa essencialmente de glibc e toolchain básico
deps=(glibc)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:m4] Configurando m4-${version}..."
  "$srcdir/configure" \
    --prefix=/usr \
    --sysconfdir=/etc \
    --disable-static

  echo "[spm:m4] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  # Testes opcionais
  if [[ "${M4_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:m4] Executando 'make check'..."
    make check || echo "[spm:m4][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:m4] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  echo "[spm:m4] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do m4.
  :
}
