name=libXdamage
version=1.1.6

source="\
  libXdamage-{version}.tar.xz::https://www.x.org/releases/individual/lib/libXdamage-{version}.tar.xz \
"

sha256="\
  <sha256-libXdamage-{version}.tar.xz> \
"

deps=(glibc libX11 libXfixes xorgproto)

build() {
  set -euo pipefail

  if [[ -d libXdamage-${version} ]]; then
    cd libXdamage-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
