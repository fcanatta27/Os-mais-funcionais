# Definição de pacote SPM para wheel (formato de distribuição binária Python)
name=wheel
version=0.46.1

# Tarball oficial do wheel no PyPI
source="wheel-{version}.tar.gz::https://files.pythonhosted.org/packages/source/w/wheel/wheel-{version}.tar.gz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
sha256="-"

deps=(glibc python)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"

  echo "[spm:wheel] Instalando wheel-{version} via pip no prefix /usr (DESTDIR)..."

  PYTHONUTF8=1 python3 -m pip install . \
    --no-deps \
    --no-build-isolation \
    --prefix=/usr \
    --root="$DESTDIR"

  echo "[spm:wheel] Instalação em staging concluída."
}

post_install() {
  # Hook opcional após instalação real do wheel.
  :
}
