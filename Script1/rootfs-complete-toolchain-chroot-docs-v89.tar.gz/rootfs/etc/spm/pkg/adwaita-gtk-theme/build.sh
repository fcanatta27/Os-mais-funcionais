name=adwaita-gtk-theme
version=3.28.0

source="\
  gnome-themes-extra-{version}.tar.xz::https://download.gnome.org/sources/gnome-themes-extra/3.28/gnome-themes-extra-{version}.tar.xz \
"

sha256="\
  <sha256-gnome-themes-extra-{version}.tar.xz> \
"

# Tema Adwaita para GTK2/GTK3 compatível com um desktop leve.
deps=(glibc gtk3)

build() {
  set -euo pipefail

  if [[ -d gnome-themes-extra-${version} ]]; then
    cd gnome-themes-extra-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
