name=libinput
version=1.29.0

source="\
  libinput-{version}.tar.xz::https://www.freedesktop.org/software/libinput/libinput-{version}.tar.xz \
"

sha256="\
  <sha256-libinput-{version}.tar.xz> \
"

deps=(glibc libevdev mtdev udev systemd)

build() {
  set -euo pipefail

  if [[ -d libinput-${version} ]]; then
    cd libinput-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dudev-dir=/lib/udev \
    -Dtests=false \
    -Ddocumentation=false

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build

  find "${DESTDIR}/usr/lib" -name 'libinput*.la' -delete 2>/dev/null || true
}

post_install() {
  if command -v libinput >/dev/null 2>&1; then
    libinput --version 2>/dev/null || true
  fi
}
