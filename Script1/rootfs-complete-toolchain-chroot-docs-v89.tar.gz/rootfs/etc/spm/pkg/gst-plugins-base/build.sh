name=gst-plugins-base
version=1.24.9

source="\
  gst-plugins-base-{version}.tar.xz::https://gstreamer.freedesktop.org/src/gst-plugins-base/gst-plugins-base-{version}.tar.xz \
"

sha256="\
  <sha256-gst-plugins-base-{version}.tar.xz> \
"

# Conjunto base de plugins do GStreamer.
deps=(glibc gstreamer glib2 orc)

build() {
  set -euo pipefail

  if [[ -d gst-plugins-base-${version} ]]; then
    cd gst-plugins-base-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dexamples=disabled \
    -Dtests=disabled

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  :
}
