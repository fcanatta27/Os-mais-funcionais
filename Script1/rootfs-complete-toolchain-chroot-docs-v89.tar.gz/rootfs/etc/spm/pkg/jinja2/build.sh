    name=jinja2
    version=3.1.6

    source="\
      Jinja2-{version}.tar.gz::https://files.pythonhosted.org/packages/source/J/Jinja2/Jinja2-{version}.tar.gz \
    "

    sha256="\
      <sha256-Jinja2-{version}.tar.gz> \
    "

    # Jinja2 depende de MarkupSafe em tempo de execução.
    deps=(python markupsafe)

    build() {
      set -euo pipefail

      # Tarball do PyPI normalmente extrai para Jinja2-{version}
      if [[ -d Jinja2-${version} && ! -f pyproject.toml && ! -f setup.py ]]; then
        cd Jinja2-${version}
      elif [[ -d Jinja2-${version} ]]; then
        cd Jinja2-${version}
      fi

      PYTHON=${PYTHON:-python3}

      "$PYTHON" -m pip install . \
        --root="$DESTDIR" \
        --prefix=/usr \
        --no-deps \
        --no-build-isolation
    }

    post_install() {
      if command -v python3 >/dev/null 2>&1; then
        python3 - << 'EOF' || true
try:
    import jinja2
    print("[spm] Jinja2", jinja2.__version__, "instalado.")
except Exception as e:
    print("[spm] aviso: não foi possível importar Jinja2:", e)
EOF
      fi
    }
