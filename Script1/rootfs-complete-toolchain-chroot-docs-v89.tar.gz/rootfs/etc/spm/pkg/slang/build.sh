name=slang
version=2.3.3

source="  slang-{version}.tar.bz2::https://www.jedsoft.org/releases/slang/slang-{version}.tar.bz2 "

sha256="<sha256-slang-{version}.tar.bz2>"

deps=(glibc ncurses)

build() {
  set -euo pipefail
  cd slang-${version}

  ./configure --prefix=/usr --sysconfdir=/etc
  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
