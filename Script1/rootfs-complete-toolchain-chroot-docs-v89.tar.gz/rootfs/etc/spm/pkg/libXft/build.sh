name=libXft
version=2.3.8

source="\
  libXft-{version}.tar.xz::https://www.x.org/releases/individual/lib/libXft-{version}.tar.xz \
"

sha256="\
  <sha256-libXft-{version}.tar.xz> \
"

deps=(glibc libX11 freetype fontconfig xorgproto)

build() {
  set -euo pipefail

  if [[ -d libXft-${version} ]]; then
    cd libXft-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
