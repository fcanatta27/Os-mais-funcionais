name=libXext
version=1.3.6

source="\
  libXext-{version}.tar.xz::https://www.x.org/releases/individual/lib/libXext-{version}.tar.xz \
"

sha256="\
  <sha256-libXext-{version}.tar.xz> \
"

# Extensões variadas para X11 (Render, etc), base para vários apps.
deps=(glibc libX11 xorgproto)

build() {
  set -euo pipefail

  if [[ -d libXext-${version} ]]; then
    cd libXext-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libXext*.la' -delete 2>/dev/null || true
}

post_install() {
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --modversion xext 2>/dev/null || true
  fi
}
