name=libXrandr
version=1.5.4

source="\
  libXrandr-{version}.tar.xz::https://www.x.org/releases/individual/lib/libXrandr-{version}.tar.xz \
"

sha256="\
  <sha256-libXrandr-{version}.tar.xz> \
"

deps=(glibc libX11 xorgproto)

build() {
  set -euo pipefail

  if [[ -d libXrandr-${version} ]]; then
    cd libXrandr-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
