name=libxkbcommon
version=1.7.0

source="\
  libxkbcommon-{version}.tar.xz::https://xkbcommon.org/download/libxkbcommon-{version}.tar.xz \
"

sha256="\
  <sha256-libxkbcommon-{version}.tar.xz> \
"

# Biblioteca de manipulação de keymaps (usada por Wayland/GTK4).
deps=(glibc xkeyboard-config)

build() {
  set -euo pipefail

  if [[ -d libxkbcommon-${version} ]]; then
    cd libxkbcommon-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Denable-x11=true

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  :
}
