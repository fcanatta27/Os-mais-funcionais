name=pinentry
version=1.3.0

source="\
  pinentry-{version}.tar.bz2::https://gnupg.org/ftp/gcrypt/pinentry/pinentry-{version}.tar.bz2 \
"

sha256="\
  <sha256-pinentry-{version}.tar.bz2> \
"

deps=(glibc ncurses libassuan libgpg-error)

build() {
  set -euo pipefail

  if [[ -d pinentry-${version} ]]; then
    cd pinentry-${version}
  fi

  ./configure \
    --prefix=/usr \
    --enable-pinentry-tty \
    --enable-pinentry-curses \
    --disable-pinentry-gtk2 \
    --disable-pinentry-qt \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
