# Definição de pacote SPM para libelf (a partir do elfutils)
# Este pacote constrói e instala apenas a biblioteca libelf de elfutils.
name=libelf
version=0.193

# Tarball oficial do elfutils (contém libelf, libdw, etc.)
source="elfutils-{version}.tar.bz2::https://sourceware.org/ftp/elfutils/{version}/elfutils-{version}.tar.bz2"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
sha256="-"

# Dependências típicas do elfutils/libelf
deps=(glibc zlib bzip2 xz zstd)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/elfutils-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:libelf] Configurando elfutils-${version} (apenas libelf)..."
  "$srcdir/configure" \
    --prefix=/usr \
    --disable-debuginfod \
    --disable-libdebuginfod \
    --disable-nls

  echo "[spm:libelf] Compilando libelf com ${JOBS:-1} jobs..."
  make -C libelf -j"${JOBS:-1}"

  if [[ "${LIBELF_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:libelf] Executando testes de libelf (se disponíveis)..."
    make -C libelf check || echo "[spm:libelf][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:libelf] Instalando libelf em DESTDIR=${DESTDIR}..."
  make -C libelf install DESTDIR="$DESTDIR"

  echo "[spm:libelf] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do libelf.
  :
}
