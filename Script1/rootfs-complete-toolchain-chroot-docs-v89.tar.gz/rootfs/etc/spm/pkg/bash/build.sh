name=bash
version=5.3
source="bash-{version}.tar.gz::https://ftp.gnu.org/gnu/bash/bash-{version}.tar.gz"
sha256="-"
deps=(glibc readline ncurses)

build() {
  set -euo pipefail
  : "${DESTDIR:?}" "${TMP:?}"
  local src="$PWD"
  local b="$TMP/${name}-${version}-build"
  rm -rf "$b"; mkdir -p "$b"; cd "$b"

  "$src/configure" \
    --prefix=/usr \
    --bindir=/bin \
    --without-bash-malloc \
    --with-installed-readline

  make -j"${JOBS:-1}"
  [[ "${BASH_RUN_TESTS:-0}" == 1 ]] && make tests || true
  make install DESTDIR="$DESTDIR"

  ln -sf bash "$DESTDIR/bin/sh"
}
