name=acpid
version=2.0.34

source="  acpid-{version}.tar.xz::https://downloads.sourceforge.net/acpid2/acpid-{version}.tar.xz "

sha256="  <sha256-acpid-{version}.tar.xz> "

deps=(glibc systemd)

build() {
  set -euo pipefail
  cd acpid-${version}
  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
  install -Dm644 samples/acpid.service     "${DESTDIR}/usr/lib/systemd/system/acpid.service"
}
