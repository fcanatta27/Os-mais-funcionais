name=wayland-protocols
version=1.40

source="\
  wayland-protocols-{version}.tar.xz::https://gitlab.freedesktop.org/wayland/wayland-protocols/-/releases/{version}/downloads/wayland-protocols-{version}.tar.xz \
"

sha256="\
  <sha256-wayland-protocols-{version}.tar.xz> \
"

# Conjunto de protocolos adicionais (xdg-shell, etc).
deps=(glibc wayland)

build() {
  set -euo pipefail

  if [[ -d wayland-protocols-${version} ]]; then
    cd wayland-protocols-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --buildtype=release

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  ls /usr/share/wayland-protocols 2>/dev/null || true
}
