name=gmp
version=6.3.0

source="gmp-{version}.tar.xz::https://ftp.gnu.org/gnu/gmp/gmp-{version}.tar.xz"
sha256="-"

deps=(glibc)

build() {
  set -euo pipefail
  : "${DESTDIR:?}" "${TMP:?}"

  local src="$PWD"
  local build="$TMP/${name}-${version}-build"
  rm -rf "$build"
  mkdir -p "$build"
  cd "$build"

  "$src/configure" \
    --prefix=/usr \
    --enable-cxx \
    --disable-static \
    --docdir=/usr/share/doc/gmp-${version}

  make -j"${JOBS:-1}"

  if [[ "${GMP_RUN_TESTS:-0}" = 1 ]]; then
    make check || echo "[spm:gmp][WARN] testes falharam"
  fi

  make install DESTDIR="$DESTDIR"
}

post_install() { :; }
