name=xbitmaps
version=1.1.3

source="\
  xbitmaps-{version}.tar.xz::https://www.x.org/pub/individual/data/xbitmaps/xbitmaps-{version}.tar.xz \
"

sha256="\
  <sha256-xbitmaps-{version}.tar.xz> \
"

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d xbitmaps-${version} ]]; then
    cd xbitmaps-${version}
  fi

  ./configure \
    --prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  ls /usr/include/X11/bitmaps 2>/dev/null || true
}
