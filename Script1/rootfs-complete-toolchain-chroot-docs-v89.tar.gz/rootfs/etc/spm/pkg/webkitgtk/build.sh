name=webkitgtk
version=2.46.0

source="\
  webkitgtk-{version}.tar.xz::https://webkitgtk.org/releases/webkitgtk-{version}.tar.xz \
"

sha256="\
  <sha256-webkitgtk-{version}.tar.xz> \
"

# Engine WebKitGTK (webkit2gtk), para browsers e webviews GTK.
deps=(glibc glib2 gtk3 libsoup3 cairo pango gdk-pixbuf libwebp libjpeg libpng harfbuzz libepoxy icu)

build() {
  set -euo pipefail

  if [[ -d webkitgtk-${version} ]]; then
    cd webkitgtk-${version}
  fi

  rm -rf build
  cmake -S . -B build \
    -DCMAKE_INSTALL_PREFIX=/usr \
    -DCMAKE_BUILD_TYPE=Release \
    -DPORT=GTK \
    -DENABLE_MINIBROWSER=ON \
    -DUSE_GTK4=OFF

  cmake --build build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" cmake --install build
}

post_install() {
  :
}
