name=cpio
version=2.15

source="  cpio-{version}.tar.xz::https://ftp.gnu.org/gnu/cpio/cpio-{version}.tar.xz "

sha256="  <sha256-cpio-{version}.tar.xz> "

deps=(glibc)

build() {
  set -euo pipefail
  cd cpio-${version}
  ./configure --prefix=/usr
  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
