name=adwaita-icon-theme
version=46.0

source="\
  adwaita-icon-theme-{version}.tar.xz::https://download.gnome.org/sources/adwaita-icon-theme/46/adwaita-icon-theme-{version}.tar.xz \
"

sha256="\
  <sha256-adwaita-icon-theme-{version}.tar.xz> \
"

# Tema de ícones Adwaita padrão do GNOME.
deps=(glibc hicolor-icon-theme)

build() {
  set -euo pipefail

  if [[ -d adwaita-icon-theme-${version} ]]; then
    cd adwaita-icon-theme-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  :
}
