name=bitstream-vera-fonts
version=1.10

source="vera-fonts.tar.bz2::https://ftp.gnome.org/pub/GNOME/sources/ttf-bitstream-vera/1.10/ttf-bitstream-vera-1.10.tar.bz2"
sha256="<sha256-bitstream-vera>"

deps=()

build() {
  set -euo pipefail
  cd ttf-bitstream-vera-1.10

  install -d "${DESTDIR}/usr/share/fonts/vera"
  install -m644 *.ttf "${DESTDIR}/usr/share/fonts/vera/"
}
