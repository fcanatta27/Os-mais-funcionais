
name=parted
version=3.7

source="parted-{version}.tar.xz::https://ftp.gnu.org/gnu/parted/parted-{version}.tar.xz"
sha256="<sha256-parted-{version}.tar.xz>"

# GNU Parted - particionador de disco.
# Aqui configurado para uso em modo texto, sem dependência obrigatória de device-mapper.
deps=(glibc readline)

build() {
  set -euo pipefail
  : "${DESTDIR:?}" "${TMP:?}"

  local src="$PWD"
  local b="${TMP}/${name}-${version}-build"
  rm -rf "${b}"
  mkdir -p "${b}"
  cd "${b}"

  "${src}/configure" \
    --prefix=/usr \
    --disable-static \
    --without-readline=no \
    --disable-device-mapper

  make -j"${JOBS:-1}"

  # Testes são interessantes mas podem ser longos; deixe opcional via env.
  if [[ "${PARTED_RUN_TESTS:-0}" == 1 ]]; then
    make check
  fi

  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
