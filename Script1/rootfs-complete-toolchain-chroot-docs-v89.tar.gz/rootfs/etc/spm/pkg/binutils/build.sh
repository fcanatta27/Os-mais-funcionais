# Definição de pacote SPM para binutils final do sistema
name=binutils
version=2.45

# Tarball principal direto do FTP GNU
source="binutils-{version}.tar.xz::https://ftp.gnu.org/gnu/binutils/binutils-{version}.tar.xz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' para desativar a checagem por enquanto, até preencher com o hash real.
sha256="-"

# Em um sistema já funcional, binutils final normalmente só precisa do ambiente base,
# mas no modelo SPM é razoável declarar que ele deve ser instalado antes do GCC final.
# (Cuidado para não criar ciclos!)
deps=()

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  # Diretório do código-fonte (SPM já entrou no diretório extraído)
  local srcdir="$PWD"

  # Diretório de build fora da árvore de fontes
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  # Configuração típica para binutils final em /usr
  local CONFIG_OPTS=(
    "--prefix=/usr"
    "--sysconfdir=/etc"
    "--enable-gold"
    "--enable-ld=default"
    "--enable-plugins"
    "--enable-shared"
    "--disable-werror"
    "--with-system-zlib"
    "--enable-64-bit-bfd"
  )

  # Usa config.guess da árvore de fontes para detectar o triplet de build, se disponível
  if [[ -x "$srcdir/build-aux/config.guess" ]]; then
    local build_triplet
    build_triplet="$("$srcdir/build-aux/config.guess")"
    CONFIG_OPTS+=("--build=$build_triplet")
  fi

  echo "[spm:binutils] Configurando binutils-${version}..."
  "$srcdir/configure" "${CONFIG_OPTS[@]}"

  echo "[spm:binutils] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}" tooldir=/usr

  # Testes opcionais: podem ser longos, então só roda se explicitamente habilitado
  if [[ "${BINUTILS_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:binutils] Executando 'make -k check' (pode ser demorado)..."
    # -k para continuar o máximo possível mesmo com falhas isoladas
    make -k check || echo "[spm:binutils][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:binutils] Instalando em DESTDIR=${DESTDIR}..."
  make tooldir=/usr install DESTDIR="$DESTDIR"

  # Ajustes pós-instalação típicos podem ser adicionados aqui se necessário.
  echo "[spm:binutils] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional executado após a instalação real no sistema (DESTDIR final).
  # Exemplo: atualizar cache de ldconfig, limpar arquivos, etc.
  :
}
