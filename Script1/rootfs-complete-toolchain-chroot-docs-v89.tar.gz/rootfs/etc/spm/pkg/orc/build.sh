name=orc
version=0.4.39

source="\
  orc-{version}.tar.xz::https://gstreamer.freedesktop.org/src/orc/orc-{version}.tar.xz \
"

sha256="\
  <sha256-orc-{version}.tar.xz> \
"

# Optimized inner loop runtime compiler usado por GStreamer.
deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d orc-${version} ]]; then
    cd orc-${version}
  fi

  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  :
}
