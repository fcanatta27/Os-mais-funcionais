name=7zip
version=25.01

source="  7zip-{version}.tar.xz::https://www.7-zip.org/a/7z{version.replace('.','')}-src.tar.xz "

sha256="  <sha256-7zip-{version}.tar.xz> "

deps=(glibc gcc make)

build() {
  set -euo pipefail
  cd 7zip*/CPP/7zip/Bundles/Alone
  make -j"${JOBS:-1}"
  install -Dm755 b/gcc/7zz "${DESTDIR}/usr/bin/7zz"
  ln -sv 7zz "${DESTDIR}/usr/bin/7z"
}
