name=wget
version=1.25.0

source="\
 wget-{version}.tar.gz::https://ftp.gnu.org/gnu/wget/wget-{version}.tar.gz \
"

sha256="\
 <sha256-wget-{version}.tar.gz> \
"

deps=(glibc openssl zlib libidn2)

build() {
 set -euo pipefail
 cd wget-${version}
 ./configure \
   --prefix=/usr \
   --sysconfdir=/etc \
   --with-ssl=openssl
 make -j"${JOBS:-1}"
 make install DESTDIR="${DESTDIR}"
}
