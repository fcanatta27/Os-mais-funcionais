name=startup-notification
version=0.12

source="\
  startup-notification-{version}.tar.gz::https://www.freedesktop.org/software/startup-notification/releases/startup-notification-{version}.tar.gz \
"

sha256="\
  <sha256-startup-notification-{version}.tar.gz> \
"

# Biblioteca para notificação de inicialização de apps (usada por Openbox, etc).
deps=(glibc glib2 xorgproto libX11)

build() {
  set -euo pipefail

  if [[ -d startup-notification-${version} ]]; then
    cd startup-notification-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libstartup-notification*.la' -delete 2>/dev/null || true
}

post_install() {
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --modversion libstartup-notification-1.0 2>/dev/null || true
  fi
}
