name=parole
version=4.18.0

source="\
  parole-{version}.tar.bz2::https://archive.xfce.org/src/apps/parole/4.18/parole-{version}.tar.bz2 \
"

sha256="\
  <sha256-parole-{version}.tar.bz2> \
"

# Player multimídia do Xfce, baseado em GStreamer.
deps=(glibc glib2 gtk3 xfce4-panel gstreamer gst-plugins-base)

build() {
  set -euo pipefail

  if [[ -d parole-${version} ]]; then
    cd parole-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
