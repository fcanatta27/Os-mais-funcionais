name=luit
version=20240910

source="\
  luit-{version}.tar.xz::https://www.x.org/pub/individual/app/luit-{version}.tar.xz \
"

sha256="\
  <sha256-luit-{version}.tar.xz> \
"

deps=(glibc iconv)

build() {
  set -euo pipefail

  if [[ -d luit-${version} && -x luit-${version}/configure ]]; then
    cd luit-${version}
  elif [[ -d luit-${version} ]]; then
    cd luit-${version}
  fi

  ./configure \
    --prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  command -v luit >/dev/null 2>&1 || true
}
