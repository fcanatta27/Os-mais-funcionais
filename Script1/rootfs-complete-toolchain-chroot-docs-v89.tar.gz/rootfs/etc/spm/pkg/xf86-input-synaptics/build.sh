name=xf86-input-synaptics
version=1.10.0

source="\
  xf86-input-synaptics-{version}.tar.bz2::https://www.x.org/releases/individual/driver/xf86-input-synaptics-{version}.tar.bz2 \
"

sha256="\
  <sha256-xf86-input-synaptics-{version}.tar.bz2> \
"

deps=(glibc xorg-server xorgproto)

build() {
  set -euo pipefail

  if [[ -d xf86-input-synaptics-${version} ]]; then
    cd xf86-input-synaptics-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc/X11 \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libsynaptics*.la' -delete 2>/dev/null || true
}

post_install() {
  ls /usr/lib/xorg/modules/input/synaptics_drv.* 2>/dev/null || true
}
