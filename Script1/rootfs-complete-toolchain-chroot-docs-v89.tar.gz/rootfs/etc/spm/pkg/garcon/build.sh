name=garcon
version=4.20.0

source="\
  garcon-{version}.tar.bz2::https://archive.xfce.org/src/xfce/garcon/4.20/garcon-{version}.tar.bz2 \
"

sha256="\
  <sha256-garcon-{version}.tar.bz2> \
"

# Biblioteca de menus (desktop entries) do Xfce.
deps=(glibc glib2 libxfce4util libxfce4ui)

build() {
  set -euo pipefail

  if [[ -d garcon-${version} ]]; then
    cd garcon-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libgarcon*.la' -delete 2>/dev/null || true
}

post_install() {
  :
}
