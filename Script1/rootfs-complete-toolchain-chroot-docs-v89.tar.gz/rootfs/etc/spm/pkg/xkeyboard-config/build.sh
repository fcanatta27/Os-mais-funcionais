name=xkeyboard-config
version=2.45

source="\
  xkeyboard-config-{version}.tar.xz::https://www.x.org/pub/data/xkeyboard-config/xkeyboard-config-{version}.tar.xz \
"

sha256="\
  <sha256-xkeyboard-config-{version}.tar.xz> \
"

# Layouts de teclado usados por Xorg/Xwayland/Wayland compositors.
# Depende basicamente de glibc e xorgproto (para definições XKB).
deps=(glibc xorgproto)

build() {
  set -euo pipefail

  if [[ -d xkeyboard-config-${version} ]]; then
    cd xkeyboard-config-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --buildtype=release \
    -Dlocalstatedir=/var \
    -Dxkb_base=/usr/share/X11/xkb

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  ls /usr/share/X11/xkb 2>/dev/null || true
}
