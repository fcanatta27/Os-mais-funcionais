name=xdg-desktop-portal-gtk
version=1.15.1

source="\
  xdg-desktop-portal-gtk-{version}.tar.xz::https://github.com/flatpak/xdg-desktop-portal-gtk/releases/download/{version}/xdg-desktop-portal-gtk-{version}.tar.xz \
"

sha256="\
  <sha256-xdg-desktop-portal-gtk-{version}.tar.xz> \
"

deps=(glibc gtk3 xdg-desktop-portal)

build() {
  set -euo pipefail
  cd xdg-desktop-portal-gtk-${version}
  meson setup build --prefix=/usr
  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}
