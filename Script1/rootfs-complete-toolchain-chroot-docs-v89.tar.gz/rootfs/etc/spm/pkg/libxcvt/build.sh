name=libxcvt
version=0.1.3

source="\
  libxcvt-{version}.tar.xz::https://www.x.org/pub/individual/lib/libxcvt-{version}.tar.xz \
"

sha256="\
  <sha256-libxcvt-{version}.tar.xz> \
"

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d libxcvt-${version} && ! -f libxcvt-${version}/meson.build ]]; then
    cd libxcvt-${version}
  elif [[ -d libxcvt-${version} ]]; then
    cd libxcvt-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build

  # Remover .la caso apareçam
  find "${DESTDIR}/usr/lib" -name 'libxcvt*.la' -delete 2>/dev/null || true
}

post_install() {
  ls /usr/lib/libxcvt* 2>/dev/null || true
}
