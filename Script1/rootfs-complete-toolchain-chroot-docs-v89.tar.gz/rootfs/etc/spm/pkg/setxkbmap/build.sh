name=setxkbmap
version=1.3.4

source="\
  setxkbmap-{version}.tar.xz::https://www.x.org/releases/individual/app/setxkbmap-{version}.tar.xz \
"

sha256="\
  <sha256-setxkbmap-{version}.tar.xz> \
"

# Ferramenta para configurar layout de teclado em X.
deps=(glibc xkeyboard-config libX11 xorgproto)

build() {
  set -euo pipefail

  if [[ -d setxkbmap-${version} ]]; then
    cd setxkbmap-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  command -v setxkbmap >/dev/null 2>&1 || true
}
