name=attr
version=2.5.2
source="attr-{version}.tar.gz::https://download.savannah.gnu.org/releases/attr/attr-{version}.tar.gz"
sha256="-"
deps=(glibc)

build() {
  set -euo pipefail
  : "${DESTDIR:?}" ; : "${TMP:?}"

  local src="$PWD"
  local b="$TMP/attr-${version}-build"
  rm -rf "$b"; mkdir -p "$b"; cd "$b"

  "$src/configure" --prefix=/usr --disable-static --sysconfdir=/etc
  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"
}
post_install(){ :; }
