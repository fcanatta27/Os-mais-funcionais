name=imlib2
version=1.12.2

source="\
  imlib2-{version}.tar.gz::https://downloads.sourceforge.net/enlightenment/imlib2-{version}.tar.gz \
"

sha256="\
  <sha256-imlib2-{version}.tar.gz> \
"

# Biblioteca de imagens usada por feh.
deps=(glibc libX11 libXext libXrender)

build() {
  set -euo pipefail

  if [[ -d imlib2-${version} ]]; then
    cd imlib2-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
