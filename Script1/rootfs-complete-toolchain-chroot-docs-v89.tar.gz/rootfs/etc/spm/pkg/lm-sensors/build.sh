name=lm-sensors
version=3.6.2

source="\
  lm-sensors-{version}.tar.gz::https://github.com/lm-sensors/lm-sensors/archive/refs/tags/V3-6-2.tar.gz \
"

sha256="\
  <sha256-lm-sensors-{version}.tar.gz> \
"

deps=(glibc)

build() {
  set -euo pipefail

  # O tarball do GitHub costuma extrair para lm-sensors-V3-6-2 ou similar
  local srcdir
  srcdir=$(find . -maxdepth 1 -type d -iname 'lm-sensors*' | head -n1 || true)
  if [[ -n "${srcdir:-}" ]]; then
    cd "${srcdir}"
  fi

  make -j"${JOBS:-1}" PREFIX=/usr

  make install PREFIX=/usr DESTDIR="${DESTDIR}"

  # Configuração padrão
  mkdir -p "${DESTDIR}/etc"
  if [[ -f etc/sensors3.conf && ! -f "${DESTDIR}/etc/sensors3.conf" ]]; then
    install -m644 etc/sensors3.conf "${DESTDIR}/etc/sensors3.conf"
  fi
}

post_install() {
  if command -v sensors >/dev/null 2>&1; then
    sensors -v 2>/dev/null || true
  fi
}
