name=openbox
version=3.6.1

source="\
  openbox-{version}.tar.gz::https://openbox.org/dist/openbox/openbox-{version}.tar.gz \
"

sha256="\
  <sha256-openbox-{version}.tar.gz> \
"

# Window manager leve e altamente configurável.
deps=(glibc libX11 libXft libXrandr libXinerama libXcursor pango glib2 startup-notification)

build() {
  set -euo pipefail

  if [[ -d openbox-${version} ]]; then
    cd openbox-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --disable-static \
    --enable-startup-notification

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  # Copia configs padrão para /etc se ainda não existirem
  if [ -d "${DESTDIR}/etc/xdg/openbox" ]; then
    :
  fi
}

post_install() {
  command -v openbox-session >/dev/null 2>&1 || command -v openbox >/dev/null 2>&1 || true
}
