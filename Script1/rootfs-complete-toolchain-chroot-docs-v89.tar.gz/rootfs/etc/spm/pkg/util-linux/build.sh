name=util-linux
version=2.41.1

source="\
  util-linux-{version}.tar.xz::https://www.kernel.org/pub/linux/utils/util-linux/v2.41/util-linux-{version}.tar.xz \
"

sha256="\
  <sha256-util-linux-{version}.tar.xz> \
"

# Dependências sugeridas: glibc, zlib, xz, zstd, libcap
deps=(glibc zlib xz zstd libcap)

build() {
  set -euo pipefail

  if [[ -d util-linux-${version} && ! -x ./configure ]]; then
    cd util-linux-${version}
  fi

  # Não queremos sobrescrever ferramentas de login/su/chsh/chfn
  # porque você provavelmente terá um pacote "shadow" gerenciando isso.
  ./configure \
    --prefix=/usr \
    --libdir=/usr/lib \
    --sysconfdir=/etc \
    --runstatedir=/run \
    --localstatedir=/var \
    --disable-static \
    --without-python \
    --without-systemd \
    --disable-chfn-chsh \
    --disable-login \
    --disable-nologin \
    --disable-su \
    --disable-setpriv \
    --disable-runuser \
    --disable-pylibmount \
    --disable-liblastlog2 \
    --enable-libmount-force-mountinfo

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"

  # Remove .la que não servem para quase nada em sistemas modernos
  find "$DESTDIR/usr/lib" -name '*.la' -delete 2>/dev/null || true
}

post_install() {
  # Teste leve: verifica se mount e lsblk respondem
  if command -v mount >/dev/null 2>&1; then
    mount --version | head -n1 || true
  fi
  if command -v lsblk >/dev/null 2>&1; then
    lsblk >/dev/null 2>&1 || true
  fi
}
