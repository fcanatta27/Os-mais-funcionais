# Definição de pacote SPM para inetutils (conjunto de clientes/servidores de rede)
name=inetutils
version=2.6

# Tarball oficial do inetutils
source="inetutils-{version}.tar.xz::https://ftp.gnu.org/gnu/inetutils/inetutils-{version}.tar.xz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
sha256="-"

deps=(glibc)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:inetutils] Configurando inetutils-${version}..."
  # Desabilitamos alguns programas que podem conflitar com outros pacotes
  # (por exemplo, ping/iputils, logger/util-linux, etc.).
  "$srcdir/configure" \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-logger \
    --disable-whois \
    --disable-rcp \
    --disable-rexec \
    --disable-rlogin \
    --disable-rsh \
    --disable-servers

  echo "[spm:inetutils] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  if [[ "${INETUTILS_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:inetutils] Executando 'make check' (muitos testes requerem rede configurada)..."
    make check || echo "[spm:inetutils][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:inetutils] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  echo "[spm:inetutils] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do inetutils.
  :
}
