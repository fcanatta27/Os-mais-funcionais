name=pm-utils
version=1.4.1

source="\
  pm-utils-{version}.tar.gz::https://pm-utils.freedesktop.org/releases/pm-utils-{version}.tar.gz \
"

sha256="\
  <sha256-pm-utils-{version}.tar.gz> \
"

# Scripts de suspensão e power management
deps=(glibc bash coreutils)

build() {
  set -euo pipefail

  if [[ -d pm-utils-${version} && ! -x ./configure ]]; then
    cd pm-utils-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --libexecdir=/usr/lib/pm-utils

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  # Estrutura de diretórios de configuração
  mkdir -p "${DESTDIR}/etc/pm/config.d" \
           "${DESTDIR}/etc/pm/sleep.d" \
           "${DESTDIR}/var/log/pm"

  # Exemplo de config vazio se não existir
  if [[ ! -f "${DESTDIR}/etc/pm/config.d/local" ]]; then
    cat > "${DESTDIR}/etc/pm/config.d/local" << 'EOF'
# Arquivo de configuração local do pm-utils
# Exemplo:
# SUSPEND_MODULES="xhci_hcd"
EOF
  fi
}

post_install() {
  if command -v pm-suspend >/dev/null 2>&1; then
    pm-suspend --help >/dev/null 2>&1 || true
  fi
}
