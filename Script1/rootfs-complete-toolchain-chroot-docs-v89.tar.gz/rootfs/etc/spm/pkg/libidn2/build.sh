name=libidn2
version=2.3.7

source="\
  libidn2-{version}.tar.gz::https://ftp.gnu.org/gnu/libidn/libidn2-{version}.tar.gz \
"

sha256="\
  <sha256-libidn2-{version}.tar.gz> \
"

# Dependências principais: glibc, libunistring
deps=(glibc libunistring)

build() {
  set -euo pipefail

  if [[ -d libidn2-${version} && ! -x ./configure ]]; then
    cd libidn2-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  # Remove .la se existirem
  find "${DESTDIR}/usr/lib" -name 'libidn2*.la' -delete 2>/dev/null || true
}

post_install() {
  if command -v idn2 >/dev/null 2>&1; then
    idn2 --version || true
  fi
}
