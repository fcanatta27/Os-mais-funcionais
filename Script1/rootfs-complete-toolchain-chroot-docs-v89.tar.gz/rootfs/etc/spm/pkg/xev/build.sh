name=xev
version=1.2.6

source="\
  xev-{version}.tar.xz::https://www.x.org/releases/individual/app/xev-{version}.tar.xz \
"

sha256="\
  <sha256-xev-{version}.tar.xz> \
"

deps=(glibc libX11 xorgproto)

build() {
  set -euo pipefail

  if [[ -d xev-${version} ]]; then
    cd xev-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  command -v xev >/dev/null 2>&1 || true
}
