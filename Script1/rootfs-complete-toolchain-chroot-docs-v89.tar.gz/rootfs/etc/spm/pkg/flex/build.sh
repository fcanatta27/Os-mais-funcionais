# Definição de pacote SPM para flex (scanner lexical)
name=flex
version=2.6.4

# Tarball oficial do flex
source="flex-{version}.tar.gz::https://github.com/westes/flex/releases/download/v{version}/flex-{version}.tar.gz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' enquanto não tiver o hash real.
sha256="-"

# flex depende de glibc e de m4 (para macro processing)
deps=(glibc m4)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:flex] Configurando flex-${version}..."
  "$srcdir/configure" \
    --prefix=/usr \
    --sysconfdir=/etc \
    --disable-static \
    --docdir=/usr/share/doc/flex-${version}

  echo "[spm:flex] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  # Testes opcionais
  if [[ "${FLEX_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:flex] Executando 'make check'..."
    make check || echo "[spm:flex][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:flex] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  # Em muitos sistemas, lex é um wrapper para flex
  if [[ -x "$DESTDIR/usr/bin/flex" ]]; then
    ln -sf flex "$DESTDIR/usr/bin/lex"
  fi

  echo "[spm:flex] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do flex.
  :
}
