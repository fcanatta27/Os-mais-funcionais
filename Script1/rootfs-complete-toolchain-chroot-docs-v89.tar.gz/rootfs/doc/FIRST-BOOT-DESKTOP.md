# FIRST BOOT — GUIA COMPLETO PARA TER UM DESKTOP FUNCIONAL

Este documento descreve, passo a passo, o que fazer no **primeiro boot**
do seu sistema para chegar a um desktop Xfce4 funcional, com rede, SPM e Xorg.

Ele assume que:
- O sistema inicializa com **systemd** como PID 1.
- Você já instalou os binários base usando o `spm` conforme o projeto.
- O rootfs deste projeto está montado como `/`.

---

## 1. Login inicial como root

No primeiro boot, você normalmente cai em um prompt de login no **tty1**.

Entre como `root`:

```bash
login: root
password: <sua-senha-ou-vazio-se-não-configurou>
```

Se ainda não definiu senha de root, faça isso agora:

```bash
passwd
```

---

## 2. Criar um usuário normal

Crie um usuário normal para uso diário (exemplo: `fernando`):

```bash
useradd -m -G wheel,audio,video,storage,lp,netdev fernando
passwd fernando
```

- `-m` cria o diretório home em `/home/fernando`.
- Os grupos são pensados para:
  - `wheel` → sudo (se você configurar sudoers para isso).
  - `audio`, `video` → acesso a dispositivos de áudio/vídeo.
  - `storage`, `lp` → discos removíveis e impressoras.
  - `netdev` → utilitários de rede.

Se ainda não configurou o `sudo`, você pode usar `su - fernando` para testar como usuário normal.

---

## 3. Verificar serviços básicos do systemd

Verifique se os serviços essenciais estão ativos:

```bash
systemctl status systemd-logind
systemctl status systemd-networkd
systemctl status systemd-resolved
systemctl status systemd-timesyncd
```

Se algum estiver desabilitado:

```bash
systemctl enable systemd-logind.service
systemctl enable systemd-networkd.service
systemctl enable systemd-resolved.service
systemctl enable systemd-timesyncd.service

systemctl start systemd-logind.service
systemctl start systemd-networkd.service
systemctl start systemd-resolved.service
systemctl start systemd-timesyncd.service
```

---

## 4. Configurar relógio, timezone e locale

### 4.1 Timezone

Exemplo para São Paulo:

```bash
ln -sf /usr/share/zoneinfo/America/Sao_Paulo /etc/localtime
hwclock --systohc
```

### 4.2 Locale

Edite `/etc/locale.gen` (se existir) e habilite as linhas desejadas, por exemplo:

```text
en_US.UTF-8 UTF-8
pt_BR.UTF-8 UTF-8
```

Então:

```bash
locale-gen  # se seu sistema usa esse passo
```

Defina locale global em `/etc/locale.conf`:

```bash
cat > /etc/locale.conf << 'EOF'
LANG=pt_BR.UTF-8
LC_COLLATE=C
EOF
```

---

## 5. Teclado, console e fonte de terminal

Para o console (fora do X), você pode ajustar em `/etc/vconsole.conf`:

```bash
cat > /etc/vconsole.conf << 'EOF'
KEYMAP=br-abnt2
FONT=lat9w-16
EOF
```

No Xorg, o layout já é configurado via `/etc/X11/xorg.conf.d/00-keyboard.conf`
(gerado pelo projeto) com:

```conf
Section "InputClass"
    Identifier "system-keyboard"
    MatchIsKeyboard "on"
    Option "XkbLayout" "br"
EndSection
```

---

## 6. Rede cabeada

Com o systemd-networkd configurado (arquivo `20-wired-dhcp.network`),
ao conectar um cabo de rede em uma interface `en*` ou `eth*`, você deve obter IP via DHCP automaticamente.

Verifique:

```bash
ip addr
ping -c3 8.8.8.8
ping -c3 google.com
```

Se não estiver ativo:

```bash
systemctl restart systemd-networkd
journalctl -u systemd-networkd --no-pager
```

---

## 7. Wi-Fi com `iw` + `wpa_supplicant`

### 7.1 Confirmar interface Wi-Fi

```bash
ip link
iw dev
```

Supondo que a interface seja `wlan0`.

### 7.2 Preparar configuração WPA

Um modelo de arquivo foi criado em:

```bash
ls /etc/wpa_supplicant
# wpa_supplicant-wlan0.conf.example
```

Copie e edite:

```bash
cp /etc/wpa_supplicant/wpa_supplicant-wlan0.conf.example \
   /etc/wpa_supplicant/wpa_supplicant-wlan0.conf

$EDITOR /etc/wpa_supplicant/wpa_supplicant-wlan0.conf
```

Ajuste:

```text
ssid="MINHA_REDE_WIFI"
psk="minha_senha_wifi"
country=BR
```

### 7.3 Habilitar serviço wpa_supplicant@wlan0

```bash
systemctl enable wpa_supplicant@wlan0.service
systemctl start  wpa_supplicant@wlan0.service
```

Verificar:

```bash
systemctl status wpa_supplicant@wlan0.service
ip addr show wlan0
ping -c3 8.8.8.8
ping -c3 google.com
```

---

## 8. Verificar o SPM e base de pacotes

### 8.1 Listar pacotes instalados

```bash
spm list
```

### 8.2 Verificar integridade de um pacote

```bash
spm --check coreutils
spm --check xfce4
```

### 8.3 (Opcional) Rebuild se algo quebrar

- `spm rebuild <nome>` → reconstruir um pacote.
- `spm rebuild --all` → reconstruir tudo.

---

## 9. Instalar um desktop Xfce completo via SPM

O projeto inclui um meta-pacote `xfce4` que puxa um desktop completo.

### 9.1 Resolver dependências e construir

No chroot ou sistema já com toolchain:

```bash
spm -b --with-deps xfce4
```

Isso:
- vai resolver dependências,
- baixar, verificar checksums,
- compilar todos os componentes do Xfce,
- gerar pacotes binários no cache do SPM.

### 9.2 Instalar o desktop

```bash
spm -i xfce4
```

---

## 10. Preparar o `.xinitrc` para iniciar o Xfce

O projeto já inclui um `.xinitrc` inteligente, mas vamos garantir que o usuário normal
tenha algo assim em `~/.xinitrc`:

```bash
cat > ~/.xinitrc << 'EOF'
#!/bin/sh

# Exemplo de seleção simples: se existir xfce4-session, usar Xfce.
if command -v xfce4-session >/dev/null 2>&1; then
    exec xfce4-session
fi

# fallback: twm + xclock + xterm
twm &
xclock -geometry 50x50-1+1 &
xterm &
exec xterm
EOF

chmod +x ~/.xinitrc
```

---

## 11. Primeiro teste gráfico

Logado como usuário normal (não root):

```bash
startx
```

Se tudo estiver ok, você deve ver o ambiente Xfce4 iniciar com:

- painel (xfce4-panel),
- desktop com wallpapers/ícones (xfdesktop),
- gerenciador de janelas (xfwm4),
- centro de configurações (xfce4-settings),
- appfinder (xfce4-appfinder),
- terminal (xfce4-terminal),
- gerenciador de arquivos (thunar).

Em caso de erro, veja:

```bash
cat ~/.local/share/xorg/Xorg.0.log  # dependendo de onde Xorg loga
```

ou:

```bash
journalctl -b | grep -iE 'Xorg|xfce|xfwm4|xfdesktop'
```

---

## 12. Checklist rápido de primeiro boot

1. **Login root**
2. `passwd` → definir senha do root.
3. `useradd -m -G wheel,audio,video,storage,lp,netdev <user>`.
4. `passwd <user>`.
5. Ajustar:
   - `/etc/localtime` (timezone)
   - `/etc/locale.conf`
   - `/etc/vconsole.conf`
6. Conferir serviços:
   - `systemctl status systemd-logind`
   - `systemctl status systemd-networkd`
   - `systemctl status systemd-resolved`
   - `systemctl status systemd-timesyncd`
7. Rede:
   - IP no cabo (`ip addr`, `ping 8.8.8.8`).
   - Wi-Fi (`wpa_supplicant@wlan0.service`, `iw dev`).
8. SPM:
   - `spm list`
   - `spm --check coreutils`
9. Desktop:
   - `spm -b --with-deps xfce4`
   - `spm -i xfce4`
   - configurar `~/.xinitrc` com `exec xfce4-session`.
10. Logar como usuário normal e rodar:
    - `startx`.

Seguindo esses passos, você terá um sistema base com systemd + rede + Wi-Fi + Xorg + Xfce4 funcional a partir desse rootfs.
