# SPM – Guia Completo de Uso Avançado

Este documento explica fluxos reais e completos de uso do SPM (Simple Package Manager),
incluindo rebuild total, repositório offline, checksum correto, sanity-check e repositórios
binários online.

---

## 1. Rebuild completo de tudo que está instalado

Para reconstruir TODOS os pacotes instalados:

spm rebuild

Para rebuild de apenas um pacote:

spm rebuild gcc

---

## 2. Preparando um repositório OFF-LINE de binários

### Construir tudo:

spm -b --with-deps base-system

Os binários ficam em /var/cache/spm/pkg.

Copie esse diretório para mídia externa ou servidor.

---

## 3. Reinstalar sistema completo offline

export SPM_BIN_STRICT=1
spm -i --bin /mnt/usb/spm-bin base-system

---

## 4. Fluxo correto de checksum

1. Crie build.sh com sha256="-"
2. Execute:

spm checksum pacote

3. Copie o bloco gerado para o build.sh.

---

## 5. Usando spm check

Checar tudo:

spm check

Checar pacote específico:

spm check glibc

---

## 6. Repositório binário online

Estrutura:

repo/pkg/*.spm.tar.zst

Sincronize com rsync ou wget e use:

spm upgrade

---

## 7. Tabela de comandos

spm -b pkg
spm -b --with-deps pkg
spm -i pkg
spm -i --bin DIR pkg
spm rebuild
spm upgrade
spm check
spm checksum pkg


## 9. Pacotes gráficos e Xorg com SPM

Você pode empacotar e gerenciar toda a stack gráfica (Mesa, Xorg, temas, fontes)
usando o mesmo fluxo de `build.sh`, `spm -b --with-deps`, `spm -i` e `spm upgrade`.
Os pacotes `mesa`, `xbitmaps`, `xorg-applications`, `xcursor-themes` e `luit`
seguem exatamente esse padrão.
