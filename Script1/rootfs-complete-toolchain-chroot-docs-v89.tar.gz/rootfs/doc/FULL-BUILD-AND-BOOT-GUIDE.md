# GUIA COMPLETO – DO HOST ATÉ O PRIMEIRO BOOT (CONSOLE E DESKTOP)

Este documento amarra **todos os passos** do projeto:

- Preparar a máquina host
- Construir a toolchain e o rootfs com os scripts em `scripts/`
- Entrar no chroot e montar a base do sistema com o **SPM**
- Gerar kernel, initramfs e imagens de rootfs com o `mkrootfs`
- Instalar em disco real
- Fazer o **primeiro boot em modo texto** (sem lightdm, com `xinit + WM`)
- Depois subir em **modo gráfico com lightdm + Xfce4**

> Este guia não substitui outros docs (`BUILD-SYSTEM.md`, `CHROOT.md`,
> `ROOTFS-IMAGES.md`, `INSTALL-ON-DISK.md`, `FIRST-BOOT-DESKTOP.md`, `SYSTEMD-BASE-SETUP.md`),  
> ele é um **“fio condutor”** com comandos concretos.

---

## 0. Preparando o HOST

No host (sua distro atual), você precisa de:

- compilador C/C++ (gcc ou clang)
- ferramentas de build: `make`, `cmake`, `ninja`, `pkg-config`, `m4`
- ferramentas de desenvolvimento: `bison`, `flex`, `texinfo`
- ferramentas de compressão: `xz`, `zstd`, `gzip`, `bzip2`
- ferramentas de arquivo: `tar`, `cpio`
- git e wget/curl

Em uma distro tipo Arch, isso seria algo como:

```bash
sudo pacman -S --needed base-devel git cmake ninja python meson \
  flex bison texinfo \
  xz zstd gzip bzip2 \
  cpio wget curl
```

Crie um diretório de trabalho, por exemplo:

```bash
mkdir -p $HOME/projects/rootfs
cd $HOME/projects/rootfs
```

Coloque o `rootfs` deste projeto aqui (por exemplo, descompactando o bundle `rootfs-complete-toolchain-chroot-docs-vXX.tar.gz`).

---

## 1. Construindo a TOOLCHAIN e o ROOTFS base (fora do chroot)

Dentro do diretório do projeto:

```bash
cd $HOME/projects/rootfs/rootfs
```

Você já tem scripts em `scripts/` que constroem:

- binutils pass1/pass2
- gcc pass1/pass2
- linux headers
- glibc
- ferramentas temporárias
- toolchain final

### 1.1. Construir a toolchain inteira

O script orquestrador está em:

```bash
cd $HOME/projects/rootfs/rootfs
bash scripts/build-toolchain-full.sh
```

Ele:

- cria `tools/` quando necessário;
- constrói toolchain cross (pass1/pass2);
- constrói glibc e libs base;
- prepara o rootfs para o chroot.

Se algo falhar:

- leia o log do pacote (os scripts normalmente logam em `/tmp` ou em diretórios específicos),
- corrija o problema,
- **rode de novo**: os scripts são pensados para serem **idempotentes** e retomáveis.

---

## 2. Entrando no CHROOT

Com a toolchain construída, você vai entrar no chroot do rootfs.

Use o script de gerenciamento de chroot que já existe:

```bash
cd $HOME/projects/rootfs/rootfs
sudo bash scripts/manage-chroot.sh enter
```

Ele:

- faz bind mount de `/dev`, `/dev/pts`, `/proc`, `/sys`, `/run` do host para o rootfs;
- entra com `chroot` em um ambiente limpo;
- configura PATH adequado para toolchain e SPM.

Para sair:

```bash
exit                   # sai do shell do chroot
sudo bash scripts/manage-chroot.sh leave
```

---

## 3. Dentro do CHROOT – preparando a base do sistema

Agora, **todos os comandos a seguir são executados dentro do chroot**, com `/` sendo o root do seu novo sistema.

### 3.1. Checando a toolchain

Antes de qualquer coisa:

```bash
toolchain-sanity-check
echo $?
```

- Saída `0` → toolchain e libs críticas estão OK.
- Saída diferente de `0` → leia as mensagens de erro/aviso, corrija e rode de novo.

---

## 4. Instalando pacotes base com o SPM

Os pacotes e suas receitas estão em `/etc/spm/pkg`.

Alguns comandos importantes do SPM:

- `spm list` – lista pacotes instalados
- `spm search <nome>` – procura receita
- `spm <pacote>` – resolve deps, baixa, compila, instala
- `spm -b <pacote>` – só compila/gera pacote binário e guarda em cache (não instala)
- `spm -i <pacote>` – instala a partir do cache binário
- `spm rebuild <pacote>` – recompila um pacote já instalado
- `spm rebuild-all` – recompila tudo que está instalado

### 4.1. Conjunto mínimo base sugerido

Exemplo de base (ajuste conforme seu gosto):

```bash
# núcleo do sistema
spm glibc
spm linux        # pacote que constrói e instala o kernel
spm systemd
spm dbus
spm util-linux
spm e2fsprogs
spm procps-ng
spm iproute2
spm iputils     # se existir na sua receita

# shell, coreutils e ferramentas usuais
spm bash
spm coreutils
spm sed
spm grep
spm gawk
spm diffutils
spm findutils
spm tar
spm gzip
spm xz
spm bzip2

# rede e ssh
spm curl
spm wget
spm openssh
spm linux-firmware   # firmware para Wi-Fi/placas de rede

# gerenciador de pacotes (já está presente, mas garanta receita ok)
spm spm || true      # se houver receita SPM “meta”
```

Depois de instalar, rode novamente:

```bash
toolchain-sanity-check
```

---

## 5. Gerando o initramfs com /usr/bin/initramfs

O script `initramfs` foi instalado em:

```bash
/usr/bin/initramfs
```

Ele cria uma imagem initramfs baseada no conteúdo de **/lib/modules/<versão>** e nos binários do sistema.

### 5.1. Uso básico

Ainda **dentro do chroot**:

```bash
# Gera initramfs para o kernel detectado
initramfs

# ou especificando a versão do kernel
initramfs --kernel 6.16.1

# escolhendo compressor e nome de arquivo
initramfs -k 6.16.1 -c xz -o /boot/initramfs-6.16.1-xz.img
```

O script:

1. Detecta a versão do kernel via:
   - `/lib/modules/<versão>`, se só houver uma,
   - ou `uname -r`, se estiver debaixo de um kernel real.
2. Copia:
   - `/lib/modules/<versão>` para dentro do initramfs.
   - Binários essenciais (`/usr/bin/bash`, `mount`, `umount`, `blkid`, `modprobe`, `chroot`, etc.) e suas libs.
3. Cria `/init` que:
   - monta `/proc`, `/sys`, `/dev`;
   - lê `root=` e `rootfstype=` do `cmdline` do kernel;
   - resolve `UUID=` ou `LABEL=` com `blkid`;
   - monta o root real em `/new_root`;
   - move `/proc`, `/sys`, `/dev`, `/run` para o root real;
   - roda `chroot /new_root /sbin/init`.

> No seu sistema, `/sbin/init` é symlink para `systemd`, então o initramfs entrega o boot para o `systemd` do root real.

---

## 6. Gerando rootfs base/desktop com mkrootfs

Ainda no chroot:

```bash
mkrootfs --profile base    # gera tarball de rootfs base
mkrootfs --profile desktop # gera tarball de rootfs com desktop completo
```

O `mkrootfs`:

- lê o rootfs atual;
- exclui arquivos temporários (`/tmp`, caches, logs);
- para o perfil base, exclui tudo relacionado a GUI pesada (Xorg, Xfce, temas, etc.);
- grava um tarball em `/rootfs-images/` (ou diretório configurado no script).

Use esse tarball depois para instalar em disco real.

---

## 7. INSTALAÇÃO EM DISCO REAL (resumo)

Esta seção é um resumo; os detalhes estão em `INSTALL-ON-DISK.md`.

### 7.1. Boot com live/rescue, particionar e formatar

No host (fora do chroot, usando live ISO ou outro Linux):

```bash
# Exemplo simples: disco /dev/sda
sudo fdisk /dev/sda

# Crie:
#  - /dev/sda1: EFI (se usar UEFI)
#  - /dev/sda2: root (ext4)
#  - opcional: /dev/sda3: /home, etc.

sudo mkfs.ext4 /dev/sda2
sudo mkfs.vfat -F32 /dev/sda1     # se usar UEFI
```

### 7.2. Montar e restaurar o rootfs

```bash
sudo mount /dev/sda2 /mnt
sudo mkdir -p /mnt/boot
sudo mount /dev/sda1 /mnt/boot   # se UEFI

# descompacte o rootfs gerado pelo mkrootfs (perfil base ou desktop)
cd /mnt
sudo tar --numeric-owner -xpf /caminho/para/rootfs-base.tar.zst
# ou rootfs-desktop.tar.zst, conforme o caso
```

### 7.3. fstab, hostname, rede

No novo sistema montado em /mnt:

```bash
sudo arch-chroot /mnt /bin/bash   # ou chroot equivalente

# fstab (exemplo)
blkid                         # veja UUIDs
nano /etc/fstab               # preencha com seus UUIDs
echo "meu-host" > /etc/hostname
```

Garanta que suas configurações de rede systemd-networkd e systemd-resolved estão adequadas
(veja `SYSTEMD-BASE-SETUP.md`).

### 7.4. Instalar GRUB e apontar para initramfs

Dentro do chroot /mnt:

```bash
grub-install /dev/sda
grub-mkconfig -o /boot/grub/grub.cfg
```

Certifique-se de que, no `grub.cfg`, as entradas de kernel têm:

- `root=UUID=...` apontando para sua partição root,
- `initrd /boot/initramfs-<versão>.img`.

---

## 8. PRIMEIRO BOOT – modo console (sem lightdm, com xinit + WM)

O primeiro boot recomendado é **sem display manager**, apenas console + Xorg manual.

### 8.1. Primeiro login

- Boota pelo GRUB.
- Faça login como `root`.

### 8.2. Ajustes iniciais

```bash
passwd              # defina senha do root

# Crie usuário normal
useradd -m -G wheel,audio,video,storage -s /bin/bash fernando
passwd fernando
```

Verifique se `/etc/sudoers` permite grupo `wheel`:

```bash
visudo
# Descomente a linha:
# %wheel ALL=(ALL:ALL) ALL
```

### 8.3. Teste de rede

```bash
ip link
ip addr
ping -c 3 1.1.1.1
ping -c 3 archlinux.org || ping -c 3 google.com
```

Se estiver usando systemd-networkd, veja:

```bash
systemctl status systemd-networkd
systemctl status systemd-resolved
```

### 8.4. Testar Xorg em modo “crudão” com um WM leve

Logado como usuário normal:

```bash
# Exemplo com twm (ou outro WM já instalado)
echo "exec twm" > ~/.xinitrc

# ou para i3:
# echo "exec i3" > ~/.xinitrc

# ou para bspwm:
# echo "exec bspwm" > ~/.xinitrc

startx
```

Se tudo estiver corretamente instalado (`xorg-server`, drivers, fontes), deve abrir
um ambiente gráfico simples.

---

## 9. MODO GRÁFICO COMPLETO – lightdm + Xfce4 no login

Depois de validar que:

- o sistema boota,
- initramfs funciona,
- rootfs está íntegro,
- Xorg sobe com `startx`,

você pode ativar o modo gráfico com display manager e Xfce.

### 9.1. Instalar stack gráfica (se ainda não instalou)

Dentro do sistema:

```bash
# Xorg + drivers básicos
spm xorg-server
spm xorg-drivers     # se tiver um meta-pacote, senão pacote a pacote
spm mesa
spm xf86-video-fbdev # fallback, se não tiver driver específico

# XFCE4 e seus componentes
spm xfce4
spm lightdm
spm lightdm-gtk-greeter
spm adwaita-gtk-theme
spm adwaita-icon-theme
spm papirus-icon-theme

# demais utilitários (já tratados em outros build.sh do seu projeto)
spm xfce4-appfinder
spm ristretto
spm parole
spm thunar
spm tumbler
```

### 9.2. Ativar lightdm e modo gráfico

```bash
systemctl enable lightdm.service
systemctl set-default graphical.target
```

Opcionalmente, ainda deixe o `.xinitrc` pronto, caso queira `startx` como fallback.

---

## 10. Check final – sanity do sistema

Depois de tudo:

```bash
toolchain-sanity-check
```

E alguns checks extras:

```bash
# systemd
systemctl --failed
systemctl status

# rede
ip addr
ping -c 3 1.1.1.1

# Xorg
journalctl -b | grep -iE 'xorg|lightdm|xfce' | tail -n 50
```

Se estes pontos passarem sem erros graves, você tem:

- toolchain funcional,
- initramfs válido,
- rootfs consistente,
- sistema bootando em console e em modo gráfico Xfce4 com lightdm,
- SPM pronto para gerenciar upgrades, rebuilds e repacks do sistema.

