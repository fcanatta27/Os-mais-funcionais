# toolchain-sanity-check

Este documento descreve o script:

    /usr/bin/toolchain-sanity-check

Ele realiza uma **validação nível 3** do sistema base, toolchain e ambiente de execução.

---

## 1. Objetivo do sanity-check

Garantir que o sistema recém-construído:

- Possui uma toolchain funcional (gcc + binutils + glibc).
- Consegue **compilar, linkar e executar** código real.
- Possui bibliotecas corretamente resolvidas pelo loader dinâmico.
- Tem ambiente mínimo coerente (shell, coreutils, pkg-config).
- Está pronto para:
  - gerar rootfs com `mkrootfs`,
  - rodar serviços systemd,
  - iniciar desktop quando aplicável.

---

## 2. O que significa “nível 3”

Nível 3 significa:

- Não apenas checar presença de arquivos.
- Não apenas checar versões.
- **Executar código real**, validar linkage real e loader real.
- Detectar erros que só aparecem em runtime.

---

## 3. Como o script funciona (passo a passo)

### 3.1 Criação de ambiente temporário

- Usa `mktemp -d /tmp/toolchain-sanity-XXXXXX`.
- Registra `trap` para remover tudo ao final.
- Nunca grava nada permanente no sistema.

---

### 3.2 Checagem de binários essenciais

Verifica se existem no PATH:

- Toolchain:
  - gcc, ld, as, ar, ranlib, nm, strip
- Build:
  - make, pkg-config, m4
- Shell/core:
  - bash, sh, sed, awk, grep, tar
- Gerenciador:
  - spm

Falha aqui = sistema **não confiável** para build.

---

### 3.3 Loader dinâmico e glibc

O script procura o loader dinâmico em locais reais:

- `/lib64/ld-linux-x86-64.so.2`
- `/lib/ld-linux-x86-64.so.2`
- `/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2`

Depois valida:

- `ldconfig -p | grep libc.so.6`

Se isso falhar, o sistema pode até “compilar”, mas **não executará corretamente**.

---

### 3.4 Compilação, link e execução reais

O script cria e compila:

```c
#include <stdio.h>
int main(void) {
  puts("SANITY_OK");
  return 0;
}
```

Testes feitos:

1. gcc compila com `-Wall -Werror`
2. binário é executável
3. saída esperada é recebida

Esse é o **teste mais importante**.

---

### 3.5 pkg-config

Executa:

```bash
pkg-config --list-all
```

Falhas aqui normalmente indicam:

- PKG_CONFIG_PATH mal configurado
- .pc files ausentes
- instalação quebrada de libs

---

### 3.6 ldd em binários críticos

Executa `ldd` em:

- /bin/bash
- /usr/bin/gcc
- /usr/bin/make
- /usr/bin/spm

Isso detecta:

- bibliotecas ausentes
- links quebrados
- loaders inválidos

---

### 3.7 Estrutura base do sistema

Confirma existência de:

- /bin
- /usr/bin
- /lib
- /usr/lib
- /etc
- /var
- /home

Não é fatal, mas ajuda a detectar rootfs mal extraído.

---

### 3.8 systemd

Se `systemctl` existir:

- valida que o systemd responde.

Se não existir:

- emite aviso (ok para sistemas sem systemd).

---

### 3.9 Rede básica

Verifica:

```bash
ip link show
```

Isso garante que:

- iproute2 funciona
- kernel + userspace estão alinhados

---

### 3.10 Xorg (opcional)

Se existir:

```bash
Xorg -version
```

Falha aqui indica problema em libs gráficas.

Ausência não é erro em sistemas sem desktop.

---

## 4. Interpretação do resultado

### 4.1 Sucesso

```text
SANITY-CHECK APROVADO (warnings: N)
```

- Sistema confiável para:
  - gerar rootfs,
  - instalar em disco real,
  - continuar builds pesados (LLVM, Mesa, Firefox).

### 4.2 Falha

```text
SANITY-CHECK FALHOU: X falha(s), Y aviso(s)
```

Ação recomendada:

1. Corrigir **falhas críticas primeiro** (gcc, libc, loader).
2. Reexecutar o script.
3. Só gerar rootfs quando falhas = 0.

---

## 5. Comandos recomendados de validação manual

Além do script, é recomendado rodar:

### Toolchain
```bash
gcc --version
ld --version
ldd /bin/bash
```

### systemd
```bash
systemctl --version
systemctl list-units --type=service | head
```

### Rede
```bash
ip addr
ping -c 3 8.8.8.8
```

### Xorg
```bash
Xorg -version
xdpyinfo | head
```

---

## 6. Quando rodar o toolchain-sanity-check

- Após construir a toolchain base.
- Antes de rodar `mkrootfs`.
- Após restaurar um rootfs em disco real.
- Antes de grandes upgrades de sistema.

---

## 7. Integração com mkrootfs e instalação

Fluxo recomendado:

```text
SPM build/install
        ↓
toolchain-sanity-check
        ↓
mkrootfs (base / desktop)
        ↓
INSTALAÇÃO EM DISCO REAL
        ↓
toolchain-sanity-check (novamente)
```

Esse ciclo garante **confiança real** no sistema final.
