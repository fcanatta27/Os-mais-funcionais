# INSTALAÇÃO EM DISCO REAL – CHECKLIST COMPLETO

Este documento descreve **passo a passo** como instalar seu sistema
a partir de um `rootfs-*.tar.*` gerado pelo `mkrootfs`.

O objetivo é:
- reduzir erros humanos;
- permitir repetibilidade;
- servir como checklist de instalação real.

---

## 0. Pré-requisitos

- Rootfs gerado com `mkrootfs`:
  - `rootfs-base-YYYYmmdd-HHMMSS.tar.zst` **ou**
  - `rootfs-desktop-YYYYmmdd-HHMMSS.tar.zst`
- Sistema live Linux com:
  - `bash`, `tar`, `zstd` ou `xz`,
  - `mount`, `lsblk`, `blkid`,
  - `grub-install`, `grub-mkconfig`,
  - acesso root.

---

## 1. Identificar o disco

Liste os discos disponíveis:

```bash
lsblk -o NAME,SIZE,TYPE,MOUNTPOINT
```

Exemplo de alvo:
- Disco: `/dev/sda`
- EFI: `/dev/sda1`
- Root: `/dev/sda2`

⚠️ **Cuidado:** tudo no disco alvo será apagado.

---

## 2. Particionamento (exemplo UEFI + GPT)

Entre no particionador:

```bash
cfdisk /dev/sda
```

Crie:
- **EFI System Partition**
  - Tamanho: 512M
  - Tipo: EFI System
- **Root**
  - Resto do disco
  - Tipo: Linux filesystem

Salve e saia.

---

## 3. Formatar partições

### EFI

```bash
mkfs.vfat -F32 /dev/sda1
```

### Root

```bash
mkfs.ext4 -L rootfs /dev/sda2
```

---

## 4. Montar o destino

```bash
mount /dev/sda2 /mnt/target
mkdir -p /mnt/target/boot
mount /dev/sda1 /mnt/target/boot
```

Verifique:

```bash
mount | grep /mnt/target
```

---

## 5. Restaurar o rootfs

### Com `.tar.zst`

```bash
cd /mnt/target
zstd -d -c /caminho/rootfs-desktop-YYYYmmdd-HHMMSS.tar.zst | tar -xpf -
```

### Com `.tar.xz`

```bash
xz -d -c /caminho/rootfs-desktop-YYYYmmdd-HHMMSS.tar.xz | tar -xpf -
```

✔️ Use sempre `-p` para preservar permissões.

---

## 6. Preparar chroot

Monte pseudo-filesystems:

```bash
mount --bind /dev  /mnt/target/dev
mount --bind /proc /mnt/target/proc
mount --bind /sys  /mnt/target/sys
mount --bind /run  /mnt/target/run
```

Entre no chroot:

```bash
chroot /mnt/target /usr/bin/env -i \
  HOME=/root TERM=$TERM PS1='(chroot) \u:\w\$ ' \
  PATH=/usr/bin:/usr/sbin:/bin:/sbin \
  /bin/bash --login
```

---

## 7. Configurações essenciais no chroot

### 7.1 Hostname

```bash
echo "meusistema" > /etc/hostname
```

### 7.2 Hosts

```bash
cat > /etc/hosts << EOF
127.0.0.1 localhost
::1       localhost
127.0.1.1 meusistema.localdomain meusistema
EOF
```

### 7.3 Fstab

Descubra UUIDs:

```bash
blkid
```

Edite `/etc/fstab`:

```bash
UUID=XXXX-XXXX  /boot vfat  defaults,noatime  0 2
UUID=YYYY-YYYY  /     ext4  defaults,noatime  0 1
```

---

## 8. Instalar GRUB (UEFI)

```bash
grub-install --target=x86_64-efi \
  --efi-directory=/boot \
  --bootloader-id=GRUB
```

Gerar config:

```bash
grub-mkconfig -o /boot/grub/grub.cfg
```

---

## 9. systemd: target padrão

### Desktop (recomendado)

```bash
systemctl set-default graphical.target
```

### Base / texto

```bash
systemctl set-default multi-user.target
```

---

## 10. Criar usuário normal

```bash
useradd -m -G wheel,audio,video,input -s /bin/bash usuario
passwd usuario
```

Habilitar sudo (se aplicável):

```bash
EDITOR=vi visudo
```

---

## 11. Primeiro sanity-check

Ainda no chroot:

```bash
/usr/bin/sanity-check
```

Corrija qualquer erro antes de rebootar.

---

## 12. Sair e desmontar

```bash
exit
umount -R /mnt/target
```

---

## 13. Primeiro boot

Reinicie:

```bash
reboot
```

Checklist após boot:
- Login funciona
- Rede funciona
- systemd sem erros críticos
- Xorg/Xfce sobe (se desktop)
