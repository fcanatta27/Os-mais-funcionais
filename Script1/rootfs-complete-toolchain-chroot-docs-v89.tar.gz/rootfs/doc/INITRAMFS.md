# INITRAMFS – Guia Completo

Este documento descreve o script `/usr/bin/initramfs` do seu sistema:

- o que ele faz
- como usar
- como ele é montado por dentro
- como depurar problemas de boot relacionados ao initramfs

O objetivo é você entender **de ponta a ponta** o fluxo:

1. Kernel carrega a imagem initramfs (`initrd`).
2. O script `/init` dentro dessa imagem:
   - monta pseudo-filesystems (`/proc`, `/sys`, `/dev`);
   - encontra o dispositivo `root=` passado pelo kernel;
   - monta o root real em `/new_root`;
   - move os mounts para o root real;
   - entrega o controle para `/sbin/init` (systemd) do seu sistema.

---

## 1. Onde está o script

Dentro do chroot/rootfs:

- Script principal: `/usr/bin/initramfs`
- Árvore base que ele monta temporariamente: `/tmp/initramfs-<versão>-XXXXXX`
- Arquivo `/init` (dentro da imagem) é gerado automaticamente.

---

## 2. Uso básico

Execute o script **como root** dentro do chroot do seu sistema:

```bash
# Autodetecta a versão do kernel e grava em /boot/initramfs-<versão>.img
initramfs

# Força a versão do kernel
initramfs --kernel 6.16.1

# Escolhe compressor e nome de arquivo
initramfs -k 6.16.1 -c xz -o /boot/initramfs-6.16.1-xz.img
```

Se você quiser ver o que ele vai gerar sem criar a imagem final:

```bash
initramfs --kernel 6.16.1 --dry-run
```

Ele monta toda a árvore do initramfs em um diretório temporário dentro de `/tmp`,
mas **não** grava o `initramfs-*.img`.

---

## 3. Opções suportadas

- `-k, --kernel <versão>`
  - Força a versão do kernel.
  - Exemplo: `initramfs -k 6.16.1`
  - Se não for informada, o script tenta:
    1. Detectar se existe exatamente um diretório em `/lib/modules`.
    2. Usar `uname -r` como fallback.

- `-o, --output <arquivo>`
  - Caminho da imagem a ser gerada.
  - Default: `/boot/initramfs-<versão>.img`.

- `-c, --compress <tipo>`
  - Tipo de compressor:
    - `gzip`
    - `xz`
    - `zstd`
  - Se não for informado, o script tenta na ordem:
    - `zstd`, depois `xz`, depois `gzip`.

- `--dry-run`
  - Monta a árvore do initramfs em `/tmp/initramfs-<versão>-XXXXXX`
    e **não** gera a imagem final.
  - Útil para inspecionar o conteúdo com `tree` ou `ls`.

- `-h, --help`
  - Mostra ajuda rápida.

---

## 4. O que o script faz (passo a passo)

### 4.1. Checagens iniciais

- Verifica se está rodando como root:
  - Se não estiver, falha com mensagem clara.
- Detecta a versão do kernel-alvo (`KVER`):
  - Se você passou via `--kernel`, usa essa.
  - Caso contrário:
    - Se só existir um diretório em `/lib/modules`, usa ele.
    - Se houver mais de um, tenta `uname -r`.

- Verifica se `/lib/modules/<KVER>` existe:
  - Se não existir, falha com erro.

- Escolhe o compressor (`gzip`, `xz` ou `zstd`):
  - Se você passou `-c`, valida o valor.
  - Se não, tenta detectar automaticamente.

### 4.2. Diretório temporário

O script cria um diretório temporário com `mktemp`:

```bash
WORKDIR=/tmp/initramfs-<versão>-XXXXXX
```

Instala um `trap` para limpar esse diretório no fim:

- Em execução normal: o diretório é removido.
- Em `--dry-run`: o diretório **é preservado** para inspeção.

---

### 4.3. Estrutura criada dentro do WORKDIR

O script cria a seguinte estrutura básica:

```text
bin/
sbin/
usr/bin/
usr/sbin/
lib/
lib64/
etc/
proc/
sys/
dev/
run/
new_root/
```

E copia:

- `/lib/modules/<KVER>` inteiro → `lib/modules/<KVER>`.

---

### 4.4. Binários essenciais e suas bibliotecas

Ele precisa de alguns binários para o `/init`:

- `/usr/bin/bash`
- `/usr/bin/mount`
- `/usr/bin/umount`
- `/usr/bin/blkid`
- `/usr/bin/modprobe`
- `/usr/bin/ls`
- `/usr/bin/cat`
- `/usr/bin/dmesg`
- `/usr/bin/mountpoint`
- `/usr/sbin/chroot`

Para cada um desses, a função `copy_bin_with_deps`:

1. Resolve o caminho real do binário (aceitando layouts `/usr/bin`, `/bin`, `/usr/sbin`, `/sbin`).
2. Copia o binário para dentro do `WORKDIR`.
3. Usa `ldd` para descobrir todas as bibliotecas dinâmicas usadas e as copia também.

Além disso, o script garante que:

```bash
/bin/sh -> ../usr/bin/bash
```

dentro do initramfs, para que sempre exista um shell funcional para debug.

---

### 4.5. /dev mínimo

Mesmo usando devtmpfs, o script cria ao menos:

- `/dev/console`
- `/dev/null`

com `mknod`, como fallback se alguma coisa der errado ao montar `devtmpfs`.

---

## 5. O script /init dentro do initramfs

O `/init` é o **coração** do initramfs. Ele é gerado automaticamente pelo script
e salvo em `${WORKDIR}/init`.

### 5.1. Fluxo de execução do /init

1. Define `PATH` básico:

   ```bash
   export PATH=/usr/bin:/bin:/usr/sbin:/sbin
   ```

2. Monta pseudo-filesystems:

   ```bash
   mount -t proc proc /proc
   mount -t sysfs sys /sys
   ```

3. Tenta montar `devtmpfs` em `/dev`:

   ```bash
   if grep -qw devtmpfs /proc/filesystems; then
       mount -t devtmpfs devtmpfs /dev
   fi
   ```

4. Lê `/proc/cmdline` e extrai:

   - `root=...`
   - `rootfstype=...`

5. Se `root=` vier como `UUID=...` ou `LABEL=...`, resolve o device real com `blkid`:

   ```bash
   blkid -t UUID=<uuid> -o device
   ```

6. Carrega alguns módulos típicos (`virtio_blk`, `virtio_scsi`, `sd_mod`, `ahci`, `nvme`, `ext4`) via `modprobe`, se disponível.

7. Monta o root real em `/new_root`:

   - Se `rootfstype=` foi definido pelo kernel, usa `mount -t TYPE`.
   - Se não, chama `mount` sem `-t` e deixa o mount detectar o tipo.

8. Move os mounts importantes para o root real:

   ```bash
   for dir in proc sys dev run; do
       # se mountpoint existir, usa mountpoint -q
       # senão, cai num fallback checando output de mount
       mount --move "/${dir}" "/new_root/${dir}"
   done
   ```

9. Verifica se `/sbin/init` é executável no root real:

   ```bash
   [[ -x /sbin/init ]] || die "/sbin/init não encontrado ou não executável"
   ```

10. Faz o `chroot` e entrega o controle:

    ```bash
    exec chroot /new_root /sbin/init
    ```

### 5.2. Se algo der errado

A função `die()` no `/init`:

```bash
die() {
  echo "[initramfs] ERRO: $*" >&2
  exec sh
}
```

Em caso de erro, ele cai direto em um shell (`/bin/sh`) do initramfs,
onde você pode:

- rodar `blkid`, `ls /dev`, `mount`, etc;
- montar manualmente o root;
- inspecionar `/proc/cmdline`.

---

## 6. Como integrar com o GRUB

Depois de rodar:

```bash
initramfs -k 6.16.1
```

você terá algo como:

- `/boot/initramfs-6.16.1.img`
- `/boot/vmlinuz-6.16.1` (instalado pelo pacote do kernel)

No `grub.cfg`, a entrada deve parecer com:

```text
menuentry 'SPM Linux 6.16.1' {
    linux   /boot/vmlinuz-6.16.1 root=UUID=<uuid-da-root> ro quiet
    initrd  /boot/initramfs-6.16.1.img
}
```

O `root=UUID=<uuid>` precisa bater com o UUID do seu sistema root
(veja `blkid` dentro do chroot ou de um live).

---

## 7. Debug de problemas comuns

### 7.1. ERRO: Não foi possível resolver UUID=...

- Verifique se:
  - Você passou o UUID correto no `root=` do GRUB.
  - O device realmente existe (`blkid`, `lsblk`).
- Dentro do shell do initramfs:
  - Rode `blkid` sem argumentos e veja quais devices têm aquele UUID.

### 7.2. ERRO: Falha ao montar root (...)

- Verifique se o sistema de arquivos é o correto:
  - Se você formatou como ext4, ext3, xfs, etc.
  - Se o kernel tem módulo para esse FS (e se o módulo foi copiado para o initramfs).
- Experimente passar explicitamente `rootfstype=ext4` (ou outro) no cmdline do kernel.

### 7.3. ERRO: /sbin/init não encontrado

- Verifique, dentro do root real:
  - Se existe `/sbin/init`.
  - No seu projeto, normalmente `/sbin/init` é symlink para `/usr/lib/systemd/systemd`.
- Se o initramfs está montando a partição errada, `/sbin/init` pode realmente não existir
  lá dentro.

---

## 8. Fluxo recomendado (resumo)

1. Construa e instale o kernel com o SPM.
2. Garanta que `/lib/modules/<versão>` e `/boot/vmlinuz-<versão>` existem.
3. Dentro do chroot:

   ```bash
   initramfs -k <versão>
   ```

4. Ajuste a entrada do GRUB para apontar:
   - `linux /boot/vmlinuz-<versão> root=UUID=<uuid> ro`
   - `initrd /boot/initramfs-<versão>.img`
5. Boot e, se ocorrer erro, leia as mensagens `[initramfs]` na tela
   e, se necessário, use o shell de emergência para investigar.

Com isso, você tem um initramfs **simples**, mas **robusto** e fácil de entender/debugar,
totalmente alinhado com o resto do seu sistema customizado.
