# Guia da Construção do Toolchain (`build-toolchain-full.sh`)

Este documento descreve, em alto nível, como funciona a construção do toolchain
usando os scripts em `rootfs/scripts/` e o orquestrador
`build-toolchain-full.sh`.

A ideia é parecida com um fluxo Linux From Scratch moderno: primeiro criamos
um toolchain temporário em `$ROOTFS/tools`, compilado a partir do host, e
depois usamos esse toolchain para continuar a construção do sistema.

## 1. Diretórios e variáveis importantes

- `ROOTFS`  
  Raiz do sistema que você está construindo. Por padrão, os scripts assumem:

  ```bash
  ROOTFS=/tmp/rootfs
  ```

- `TOOLS`  
  Diretório onde o toolchain temporário é instalado:

  ```bash
  TOOLS="$ROOTFS/tools"
  ```

  Dentro do chroot, esse caminho aparece como `/tools`.

- `SRC_DIR`  
  Diretório onde ficam os tarballs de código-fonte:

  ```bash
  SRC_DIR=/tmp/sources
  ```

Você pode sobrescrever essas variáveis antes de rodar qualquer script:

```bash
export ROOTFS=/mnt/lfs
export SRC_DIR=/mnt/lfs-sources
```

## 2. Bundle de scripts

O bundle `rootfs-all-pass1-scripts-*.tar.gz` possui a seguinte estrutura:

```text
rootfs/
  scripts/
    build-binutils-2.45.1-pass1.sh
    build-gcc-15.2.0-pass1.sh
    build-linux-headers-6.16.1.sh
    build-glibc-pass1.sh
    build-m4-1.4.20-pass1.sh
    build-ncurses-6.5-pass1.sh
    build-bash-5.3-pass1.sh
    build-coreutils-9.7-pass1.sh
    build-diffutils-3.12-pass1.sh
    build-file-5.46-pass1.sh
    build-findutils-4.10-pass1.sh
    build-gawk-5.3.2-pass1.sh
    build-grep-3.12-pass1.sh
    build-gzip-1.14-pass1.sh
    build-make-4.4.1-pass1.sh
    build-patch-2.8-pass1.sh
    build-sed-4.9-pass1.sh
    build-tar-1.35-pass1.sh
    build-xz-5.8.1-pass1.sh
    build-binutils-2.45.1-pass2.sh
    build-gcc-15.2.0-pass2.sh
    build-toolchain-full.sh
```

Para usar, extraia em `/`:

```bash
cd /
sudo tar -xvf rootfs-all-pass1-scripts-v13.tar.gz
```

Isso criará `/rootfs/scripts` com todos os scripts.

## 3. Orquestrador: `build-toolchain-full.sh`

O script `build-toolchain-full.sh` coordena todos os passos, na ordem correta,
e possui **retomada automática**.

Caminho após extrair o bundle:

```bash
/rootfs/scripts/build-toolchain-full.sh
```

### 3.1. Arquivo de estado

Ele mantém um arquivo de progresso em:

```bash
$ROOTFS/tools/.toolchain-full.state
```

Cada passo concluído adiciona uma linha com um ID, por exemplo:

```text
01-binutils-pass1
02-gcc-pass1
03-linux-headers
...
```

Se você rodar o script de novo, os passos já presentes nesse arquivo serão
pulados, permitindo **retomar** a construção após um erro ou interrupção.

### 3.2. Ordem dos passos

A sequência é:

1. `01-binutils-pass1` – Binutils 2.45.1 (Pass 1)  
2. `02-gcc-pass1` – GCC 15.2.0 (Pass 1)  
3. `03-linux-headers` – Linux API Headers 6.16.1  
4. `04-glibc-pass1` – Glibc (Pass 1)  
5. `05-m4-pass1` – M4 1.4.20 (Pass 1)  
6. `06-ncurses-pass1` – Ncurses 6.5 (Pass 1)  
7. `07-bash-pass1` – Bash 5.3 (Pass 1)  
8. `08-coreutils-pass1` – Coreutils 9.7 (Pass 1)  
9. `09-diffutils-pass1` – Diffutils 3.12 (Pass 1)  
10. `10-file-pass1` – File 5.46 (Pass 1)  
11. `11-findutils-pass1` – Findutils 4.10 (Pass 1)  
12. `12-gawk-pass1` – Gawk 5.3.2 (Pass 1)  
13. `13-grep-pass1` – Grep 3.12 (Pass 1)  
14. `14-gzip-pass1` – Gzip 1.14 (Pass 1)  
15. `15-make-pass1` – Make 4.4.1 (Pass 1)  
16. `16-patch-pass1` – Patch 2.8 (Pass 1)  
17. `17-sed-pass1` – Sed 4.9 (Pass 1)  
18. `18-tar-pass1` – Tar 1.35 (Pass 1)  
19. `19-xz-pass1` – XZ Utils 5.8.1 (Pass 1)  
20. `20-binutils-pass2` – Binutils 2.45.1 (Pass 2)  
21. `21-gcc-pass2` – GCC 15.2.0 (Pass 2)  

Cada passo chama um script `build-*.sh` correspondente.

### 3.3. Como rodar o orquestrador

Exemplo real, usando `/tmp/rootfs` e `/tmp/sources`:

```bash
# 1) Definir variáveis (opcional, pois estes são os padrões)
export ROOTFS=/tmp/rootfs
export SRC_DIR=/tmp/sources

# 2) Executar o orquestrador
cd /rootfs/scripts
sudo ./build-toolchain-full.sh
```

Se algum passo falhar (por exemplo, falha no download ou problema de rede),
você pode corrigir o problema e simplesmente rodar de novo:

```bash
sudo ./build-toolchain-full.sh
```

Os passos já bem sucedidos serão pulados.

## 4. Variáveis de testes (make check)

Alguns scripts têm variáveis para controlar se os testes são executados ou não:

- `SED_RUN_TESTS` para `build-sed-4.9-pass1.sh`  
- `TAR_RUN_TESTS` para `build-tar-1.35-pass1.sh`  
- `XZ_RUN_TESTS` para `build-xz-5.8.1-pass1.sh`  
- `BINUTILS_PASS2_RUN_TESTS` para `build-binutils-2.45.1-pass2.sh`  
- `GCC_PASS2_RUN_TESTS` para `build-gcc-15.2.0-pass2.sh`  

Por padrão, os testes são **pulados**. Para ativar, defina as variáveis como 1
antes de rodar os scripts (ou o orquestrador):

```bash
export XZ_RUN_TESTS=1
export GCC_PASS2_RUN_TESTS=1
sudo ./build-toolchain-full.sh
```

Isso aumentará bastante o tempo de compilação, especialmente no GCC.

## 5. Controle de paralelismo (`JOBS`)

Vários scripts usam a variável `JOBS` para controlar o `make -j`:

- Se `JOBS` **não** estiver definida, o script tenta usar `nproc` para detectar
  o número de CPUs, com fallback para `1`.
- Se `JOBS` estiver definida, o valor é respeitado.

Exemplo:

```bash
export JOBS=4
sudo ./build-toolchain-full.sh
```

## 6. Caminho (`PATH`) durante o build

Os scripts de build geralmente fazem:

```bash
export PATH="$TOOLS/bin:$PATH"
```

Assim, as ferramentas temporárias (`$TOOLS/bin`) têm prioridade sobre as do host.

Dentro do chroot, isso aparecerá como:

```bash
PATH=/tools/bin:/bin:/usr/bin:/sbin:/usr/sbin
```

garantindo que o toolchain que você acabou de compilar seja usado em vez das
ferramentas do sistema host.

## 7. Fluxo típico até o chroot

1. Extrair o bundle de scripts em `/`
2. Rodar `build-toolchain-full.sh` para construir tudo em `$ROOTFS/tools`
3. Preparar o chroot (montar /dev, /proc, /sys, /run) usando `manage-chroot.sh`
4. Entrar no chroot e continuar a construção do sistema “de dentro” do próprio
   `$ROOTFS`

Veja o documento `chroot-howto.md` para detalhes do chroot.
