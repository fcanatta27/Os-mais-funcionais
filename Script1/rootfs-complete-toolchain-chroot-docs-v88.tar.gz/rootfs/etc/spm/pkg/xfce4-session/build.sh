name=xfce4-session
version=4.20.0

source="\
  xfce4-session-{version}.tar.bz2::https://archive.xfce.org/src/xfce/xfce4-session/4.20/xfce4-session-{version}.tar.bz2 \
"

sha256="\
  <sha256-xfce4-session-{version}.tar.bz2> \
"

# Gerenciador de sessão do Xfce.
deps=(glibc glib2 gtk3 libxfce4ui libxfce4util xfconf)

build() {
  set -euo pipefail

  if [[ -d xfce4-session-${version} ]]; then
    cd xfce4-session-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
