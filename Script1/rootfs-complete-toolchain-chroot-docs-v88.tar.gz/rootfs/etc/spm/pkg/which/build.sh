name=which
version=2.23

source="\
  which-{version}.tar.gz::https://ftp.gnu.org/gnu/which/which-{version}.tar.gz \
"

sha256="\
  <sha256-which-{version}.tar.gz> \
"

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d which-${version} && ! -x ./configure ]]; then
    cd which-${version}
  fi

  ./configure \
    --prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  if command -v which >/dev/null 2>&1; then
    which which || true
  fi
}
