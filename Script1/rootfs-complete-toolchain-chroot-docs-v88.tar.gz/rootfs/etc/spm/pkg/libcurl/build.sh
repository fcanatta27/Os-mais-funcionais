name=libcurl
version=8.15.0

source="\
  curl-{version}.tar.xz::https://curl.se/download/curl-{version}.tar.xz \
"

sha256="\
  <sha256-curl-{version}.tar.xz> \
"

# Biblioteca libcurl compartilhada (HTTP/FTP/etc).
deps=(glibc openssl zlib)

build() {
  set -euo pipefail

  if [[ -d curl-${version} ]]; then
    cd curl-${version}
  fi

  ./configure \
    --prefix=/usr \
    --with-ssl \
    --enable-ipv6 \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
