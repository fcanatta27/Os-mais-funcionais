# Definição de pacote SPM para headers do kernel Linux
# Este pacote instala apenas os headers da API do kernel,
# não compila nem instala o kernel em si.
name=linux-headers
version=6.16.1

# Tarball principal do kernel Linux
source="linux-{version}.tar.xz::https://www.kernel.org/pub/linux/kernel/v6.x/linux-{version}.tar.xz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' enquanto não tiver o hash real.
sha256="-"

deps=()

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  # Diretório da árvore de fontes do kernel (SPM já entrou nele)
  local srcdir="$PWD"

  echo "[spm:linux-headers] Limpando a árvore com 'make mrproper'..."
  make -C "$srcdir" mrproper

  echo "[spm:linux-headers] Gerando headers da API do kernel com 'make headers'..."
  make -C "$srcdir" headers

  # Limpar arquivos indesejados dentro de usr/include
  echo "[spm:linux-headers] Limpando arquivos temporários em usr/include..."
  find "$srcdir/usr/include" -name '.*' -delete
  rm -f "$srcdir/usr/include/Makefile"

  # Instalar headers em /usr/include do DESTDIR
  echo "[spm:linux-headers] Instalando headers em ${DESTDIR}/usr/include..."
  mkdir -p "$DESTDIR/usr"
  # Se já existir /usr/include no DESTDIR, removemos para evitar mistura de versões
  if [[ -d "$DESTDIR/usr/include" ]]; then
    rm -rf "$DESTDIR/usr/include"
  fi
  cp -rv "$srcdir/usr/include" "$DESTDIR/usr"

  echo "[spm:linux-headers] Instalação dos headers do kernel concluída."
}

post_install() {
  # Nada específico para fazer após instalação dos headers.
  :
}
