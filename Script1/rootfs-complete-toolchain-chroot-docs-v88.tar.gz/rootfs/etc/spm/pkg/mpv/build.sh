
name=mpv
version=0.38.0

source="\
  mpv-{version}.tar.gz::https://github.com/mpv-player/mpv/archive/v{version}/mpv-{version}.tar.gz \
"

sha256="\
  <sha256-mpv-{version}.tar.gz> \
"

# mpv - player de vídeo moderno baseado em ffmpeg.
# Configurado para usar backend gráfico X11/Wayland e ALSA, evitando PulseAudio/JACK.
deps=(glibc ffmpeg libX11 libXrandr libXinerama libXext libXrender libxcb alsa-lib libdrm wayland zlib)

build() {
  set -euo pipefail
  : "${DESTDIR:?}"

  # mpv usa Meson atualmente.
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dlibmpv=true \
    -Ddrm=enabled \
    -Dwayland=enabled \
    -Dx11=enabled \
    -Dalsa=enabled \
    -Dpulseaudio=disabled \
    -Djack=disabled \
    -Dlua=disabled

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  :
}
