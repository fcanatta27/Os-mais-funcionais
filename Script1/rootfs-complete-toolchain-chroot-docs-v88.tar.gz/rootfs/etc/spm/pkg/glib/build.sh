name=glib
version=2.84.4

source="  glib-{version}.tar.xz::https://download.gnome.org/sources/glib/2.84/glib-{version}.tar.xz "

sha256="  <sha256-glib-{version}.tar.xz> "

deps=(glibc libffi pcre2 zlib python meson ninja pkgconf)

build() {
  set -euo pipefail
  cd glib-${version}

  rm -rf build
  meson setup build     --prefix=/usr     --libdir=/usr/lib     --buildtype=release     -Dtests=false

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}
