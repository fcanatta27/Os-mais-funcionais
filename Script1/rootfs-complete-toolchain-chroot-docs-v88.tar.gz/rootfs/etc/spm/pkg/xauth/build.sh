name=xauth
version=1.1.3

source="\
  xauth-{version}.tar.xz::https://www.x.org/releases/individual/app/xauth-{version}.tar.xz \
"

sha256="\
  <sha256-xauth-{version}.tar.xz> \
"

# Ferramenta para gerenciar autorização de acesso ao servidor X (cookies MIT-MAGIC-COOKIE-1).
deps=(glibc libX11 libXau libXext xorgproto)

build() {
  set -euo pipefail

  if [[ -d xauth-${version} ]]; then
    cd xauth-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  command -v xauth >/dev/null 2>&1 || true
}
