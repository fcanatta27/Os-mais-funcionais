# Definição de pacote SPM para gperf (Perfect Hash Function Generator)
name=gperf
version=3.3

# Tarball oficial do gperf
source="gperf-{version}.tar.gz::https://ftp.gnu.org/gnu/gperf/gperf-{version}.tar.gz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' enquanto não tiver o hash real.
sha256="-"

deps=(glibc)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:gperf] Configurando gperf-${version}..."
  "$srcdir/configure" \
    --prefix=/usr \
    --disable-static \
    --docdir=/usr/share/doc/gperf-${version}

  echo "[spm:gperf] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  if [[ "${GPERF_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:gperf] Executando 'make check'..."
    make check || echo "[spm:gperf][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:gperf] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  echo "[spm:gperf] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do gperf.
  :
}
