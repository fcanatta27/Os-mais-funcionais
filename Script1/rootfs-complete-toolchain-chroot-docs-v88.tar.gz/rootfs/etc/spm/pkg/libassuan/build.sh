name=libassuan
version=3.0.1

source="\
  libassuan-{version}.tar.bz2::https://www.gnupg.org/ftp/gcrypt/libassuan/libassuan-{version}.tar.bz2 \
"

sha256="\
  <sha256-libassuan-{version}.tar.bz2> \
"

deps=(glibc libgpg-error)

build() {
  set -euo pipefail
  cd libassuan-${version}

  ./configure     --prefix=/usr     --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
