name=wireless-tools
version=29

source="\
 wireless_tools.{version}.tar.gz::https://hewlettpackard.github.io/wireless-tools/wireless_tools.{version}.tar.gz \
"

sha256="\
 <sha256-wireless_tools.{version}.tar.gz> \
"

deps=(glibc)

build() {
 set -euo pipefail
 cd wireless_tools.${version}
 make -j"${JOBS:-1}"
 make PREFIX=/usr install DESTDIR="${DESTDIR}"
}
