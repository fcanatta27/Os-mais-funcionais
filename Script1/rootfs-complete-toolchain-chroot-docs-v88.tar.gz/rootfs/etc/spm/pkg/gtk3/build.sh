name=gtk3
version=3.24.43

source="\
  gtk+-{version}.tar.xz::https://download.gnome.org/sources/gtk+/3.24/gtk+-{version}.tar.xz \
"

sha256="\
  <sha256-gtk+-{version}.tar.xz> \
"

deps=(glib2 pango cairo gdk-pixbuf atk-atspi at-spi2-core at-spi2-atk wayland wayland-protocols xorgproto)

build() {
  set -euo pipefail

  srcdir="gtk+-${version}"
  [ -d "$srcdir" ] && cd "$srcdir"

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dintrospection=disabled \
    -Dman=false \
    -Dtests=false \
    -Dwayland_backend=true \
    -Dx11_backend=true

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  if command -v gtk-query-immodules-3.0 >/dev/null 2>&1; then
    gtk-query-immodules-3.0 --update-cache 2>/dev/null || true
  fi
}
