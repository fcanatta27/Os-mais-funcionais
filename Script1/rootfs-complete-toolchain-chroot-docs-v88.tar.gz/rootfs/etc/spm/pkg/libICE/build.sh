name=libICE
version=1.1.1

source="\
  libICE-{version}.tar.xz::https://www.x.org/releases/individual/lib/libICE-{version}.tar.xz \
"

sha256="\
  <sha256-libICE-{version}.tar.xz> \
"

# Inter-Client Exchange library (ICE), base para SM e outros componentes.
deps=(glibc xorgproto)

build() {
  set -euo pipefail

  if [[ -d libICE-${version} ]]; then
    cd libICE-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libICE*.la' -delete 2>/dev/null || true
}

post_install() {
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --modversion ice 2>/dev/null || true
  fi
}
