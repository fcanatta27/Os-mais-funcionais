name=libxslt
version=1.1.43

source="  libxslt-{version}.tar.xz::https://download.gnome.org/sources/libxslt/1.1/libxslt-{version}.tar.xz "

sha256="  <sha256-libxslt-{version}.tar.xz> "

deps=(glibc libxml2)

build() {
  set -euo pipefail
  cd libxslt-${version}

  ./configure     --prefix=/usr     --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
