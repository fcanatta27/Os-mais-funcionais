
name=xorriso
version=1.5.6

source="xorriso-{version}.tar.gz::https://www.gnu.org/software/xorriso/xorriso-{version}.tar.gz"
sha256="<sha256-xorriso-{version}.tar.gz>"

# xorriso - ferramenta para criar/gravar imagens ISO, usada em fluxos de mídia/boot.
deps=(glibc)

build() {
  set -euo pipefail
  : "${DESTDIR:?}" "${TMP:?}"

  local src="$PWD"
  local b="${TMP}/${name}-${version}-build"
  rm -rf "${b}"
  mkdir -p "${b}"
  cd "${b}"

  "${src}/configure" \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"

  if [[ "${XORRISO_RUN_TESTS:-0}" == 1 ]]; then
    make check || true
  fi

  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
