name=iproute2
version=6.16.0

source="      iproute2-{version}.tar.xz::https://www.kernel.org/pub/linux/utils/net/iproute2/iproute2-{version}.tar.xz     "

sha256="      <sha256-iproute2-{version}.tar.xz>     "

# Dependências de rede básicas; ajuste conforme seu conjunto de pacotes.
deps=(glibc libmnl libcap)

build() {
  set -euo pipefail

  if [[ -d iproute2-${version} && ! -f Makefile ]]; then
    cd iproute2-${version}
  fi

  # Remove ARPD se não for usado (como sugerido em várias distros)
  sed -i '/^arpd/d' Makefile 2>/dev/null || true
  sed -i '/TC_CONFIG_XT/d' tc/Makefile 2>/dev/null || true

  # iproute2 não usa ./configure padrão; é make direto.
  make -j"${JOBS:-1}"

  # Instalação respeitando DESTDIR e PREFIX
  make DESTDIR="$DESTDIR" PREFIX=/usr SBINDIR=/usr/sbin install

  # Arquivos de configuração padrão (se existirem)
  if [[ -d etc ]]; then
    mkdir -p "$DESTDIR/etc"
    cp -rv etc/* "$DESTDIR/etc/" 2>/dev/null || true
  fi
}

post_install() {
  if command -v ip >/dev/null 2>&1; then
    ip -V || true
  fi
}
