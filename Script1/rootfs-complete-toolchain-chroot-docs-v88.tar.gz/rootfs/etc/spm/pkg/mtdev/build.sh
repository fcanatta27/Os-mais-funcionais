name=mtdev
version=1.1.6

source="\
  mtdev-{version}.tar.bz2::https://bitmath.org/code/mtdev/mtdev-{version}.tar.bz2 \
"

sha256="\
  <sha256-mtdev-{version}.tar.bz2> \
"

# Pequena lib para normalizar eventos multitouch de /dev/input/event*.
deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d mtdev-${version} ]]; then
    cd mtdev-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make check -j"${JOBS:-1}" || true
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libmtdev*.la' -delete 2>/dev/null || true
}

post_install() {
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --modversion mtdev 2>/dev/null || true
  fi
}
