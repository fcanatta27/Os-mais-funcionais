name=libadwaita
version=1.6.4

source="\
  libadwaita-{version}.tar.xz::https://download.gnome.org/sources/libadwaita/1.6/libadwaita-{version}.tar.xz \
"

sha256="\
  <sha256-libadwaita-{version}.tar.xz> \
"

# Biblioteca de widgets GNOME baseada em GTK4.
deps=(glibc glib2 gtk4 libepoxy libxkbcommon pango cairo gdk-pixbuf)

build() {
  set -euo pipefail

  if [[ -d libadwaita-${version} ]]; then
    cd libadwaita-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dexamples=false \
    -Dtests=false

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  :
}
