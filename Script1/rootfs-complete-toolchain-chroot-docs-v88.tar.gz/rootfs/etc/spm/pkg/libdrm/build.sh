name=libdrm
version=2.4.125

source="\
  libdrm-{version}.tar.xz::https://dri.freedesktop.org/libdrm/libdrm-{version}.tar.xz \
"

sha256="\
  <sha256-libdrm-{version}.tar.xz> \
"

deps=(glibc libpciaccess libpthread-stubs libX11)

build() {
  set -euo pipefail

  if [[ -d libdrm-${version} ]]; then
    cd libdrm-${version}
  fi

  meson setup build \
    --prefix=/usr \
    --buildtype=release \
    -Dudev=true

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  :
}
