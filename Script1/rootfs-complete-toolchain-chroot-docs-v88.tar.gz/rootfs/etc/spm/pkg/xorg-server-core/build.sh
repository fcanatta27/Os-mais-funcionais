name=xorg-server-core
version=virtual-1

source=""
sha256=""

# Meta-pacote que representa o servidor Xorg principal.
deps=(xorg-server)

build() {
  set -euo pipefail
  echo "xorg-server-core é um meta-pacote; nenhuma build necessária."
}

post_install() {
  :
}
