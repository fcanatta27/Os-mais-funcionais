name=grub
version=2.12

source="      grub-{version}.tar.xz::https://ftp.gnu.org/gnu/grub/grub-{version}.tar.xz     "

sha256="      <sha256-grub-{version}.tar.xz>     "

# Dependências aproximadas: toolchain C, flex, bison, gettext, etc.
# Ajuste conforme os nomes de pacotes que você tiver no seu SPM.
deps=(glibc gettext flex bison)

build() {
  set -euo pipefail

  if [[ -d grub-${version} && ! -x ./configure ]]; then
    cd grub-${version}
  fi

  # Por padrão, vamos preparar um build para BIOS x86_64 (pc).
  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --disable-efiemu \
    --target=x86_64-pc \
    --with-platform=pc \
    --enable-grub-mkfont

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"

  # Não executamos grub-install automaticamente porque isso depende
  # fortemente do ambiente (discos reais, EFI/BIOS, etc.).
  # O usuário deve rodar grub-install manualmente no sistema final.
}

post_install() {
  # Teste leve apenas para confirmar que o binário está funcional.
  if command -v grub-mkconfig >/dev/null 2>&1; then
    grub-mkconfig --version || true
  fi
}
