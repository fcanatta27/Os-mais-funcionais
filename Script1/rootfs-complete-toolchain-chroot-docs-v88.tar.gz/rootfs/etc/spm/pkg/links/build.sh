name=links
version=2.30

source="\
  links-{version}.tar.bz2::http://links.twibright.com/download/links-{version}.tar.bz2 \
"

sha256="\
  <sha256-links-{version}.tar.bz2> \
"

# Dependências: glibc, openssl, zlib, bzip2
deps=(glibc openssl zlib bzip2)

build() {
  set -euo pipefail

  if [[ -d links-${version} && ! -x ./configure ]]; then
    cd links-${version}
  fi

  # Build em modo texto (sem X/graphics por padrão para evitar dependências extras)
  ./configure \
    --prefix=/usr \
    --with-ssl=openssl \
    --enable-graphics=no

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  if command -v links >/dev/null 2>&1; then
    links -version 2>/dev/null || true
  fi
}
