name=libxfce4ui
version=4.20.0

source="\
  libxfce4ui-{version}.tar.bz2::https://archive.xfce.org/src/xfce/libxfce4ui/4.20/libxfce4ui-{version}.tar.bz2 \
"

sha256="\
  <sha256-libxfce4ui-{version}.tar.bz2> \
"

# Widgets comuns do Xfce (UI compartilhada).
deps=(glibc glib2 gtk3 libxfce4util)

build() {
  set -euo pipefail

  if [[ -d libxfce4ui-${version} ]]; then
    cd libxfce4ui-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libxfce4ui*.la' -delete 2>/dev/null || true
}

post_install() {
  :
}
