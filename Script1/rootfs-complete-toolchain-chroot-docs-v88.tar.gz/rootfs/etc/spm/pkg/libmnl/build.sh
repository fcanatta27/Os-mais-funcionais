name=libmnl
version=1.0.5

source="\
  libmnl-{version}.tar.bz2::https://netfilter.org/projects/libmnl/files/libmnl-{version}.tar.bz2 \
"

sha256="\
  <sha256-libmnl-{version}.tar.bz2> \
"

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d libmnl-${version} ]]; then
    cd libmnl-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
