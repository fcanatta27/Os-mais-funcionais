name=papirus-icon-theme
version=20240901

source="\
  papirus-icon-theme-{version}.tar.gz::https://github.com/PapirusDevelopmentTeam/papirus-icon-theme/archive/refs/tags/{version}.tar.gz \
"

sha256="\
  <sha256-papirus-icon-theme-{version}.tar.gz> \
"

# Tema de ícones Papirus.
deps=(glibc hicolor-icon-theme)

build() {
  set -euo pipefail

  if [[ -d papirus-icon-theme-${version} ]]; then
    cd papirus-icon-theme-${version}
  fi

  mkdir -p "${DESTDIR}/usr/share/icons"
  cp -a Papirus Papirus-Dark Papirus-Light "${DESTDIR}/usr/share/icons"/
}

post_install() {
  :
}
