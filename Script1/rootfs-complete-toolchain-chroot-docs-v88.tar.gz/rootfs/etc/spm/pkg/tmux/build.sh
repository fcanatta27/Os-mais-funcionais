name=tmux
version=3.4

source="tmux-{version}.tar.gz::https://github.com/tmux/tmux/releases/download/{version}/tmux-{version}.tar.gz"
sha256="<sha256-tmux-3.4>"

deps=(glibc libevent ncurses)

build() {
  set -euo pipefail
  cd tmux-${version}

  ./configure \
    --prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
