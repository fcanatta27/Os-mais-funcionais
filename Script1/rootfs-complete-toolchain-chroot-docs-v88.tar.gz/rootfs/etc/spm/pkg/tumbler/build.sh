name=tumbler
version=4.20.0

source="\
  tumbler-{version}.tar.bz2::https://archive.xfce.org/src/xfce/tumbler/4.20/tumbler-{version}.tar.bz2 \
"

sha256="\
  <sha256-tumbler-{version}.tar.bz2> \
"

# Thumbnailer do Xfce (imagens, vídeos, etc).
deps=(glibc glib2 gtk3 libxfce4util libjpeg gdk-pixbuf)

build() {
  set -euo pipefail
  cd tumbler-${version}

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make DESTDIR="${DESTDIR}" install
}
