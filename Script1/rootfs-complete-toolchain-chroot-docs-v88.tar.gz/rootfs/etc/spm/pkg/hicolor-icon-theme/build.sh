name=hicolor-icon-theme
version=0.17

source="\
  hicolor-icon-theme-{version}.tar.xz::https://icon-theme.freedesktop.org/releases/hicolor-icon-theme-{version}.tar.xz \
"

sha256="\
  <sha256-hicolor-icon-theme-{version}.tar.xz> \
"

# Tema base hicolor exigido por vários temas de ícones.
deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d hicolor-icon-theme-${version} ]]; then
    cd hicolor-icon-theme-${version}
  fi

  ./configure \
    --prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
