name=jpeg
version=3.0.3

source="\
  libjpeg-turbo-{version}.tar.gz::https://downloads.sourceforge.net/libjpeg-turbo/libjpeg-turbo-{version}.tar.gz \
"

sha256="\
  <sha256-libjpeg-turbo-{version}.tar.gz> \
"

# Implementação rápida de libjpeg (libjpeg-turbo).
deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d libjpeg-turbo-${version} ]]; then
    cd libjpeg-turbo-${version}
  fi

  cmake -S . -B build \
    -DCMAKE_INSTALL_PREFIX=/usr \
    -DCMAKE_BUILD_TYPE=Release \
    -DENABLE_SHARED=ON

  cmake --build build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" cmake --install build
}

post_install() {
  :
}
