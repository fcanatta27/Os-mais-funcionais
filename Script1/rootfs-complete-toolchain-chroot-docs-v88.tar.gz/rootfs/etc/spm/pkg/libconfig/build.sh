name=libconfig
version=1.7.3

source="\
  libconfig-{version}.tar.gz::https://hyperrealm.github.io/libconfig/dist/libconfig-{version}.tar.gz \
"

sha256="\
  <sha256-libconfig-{version}.tar.gz> \
"

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d libconfig-${version} ]]; then
    cd libconfig-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static \
    --enable-cxx

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
