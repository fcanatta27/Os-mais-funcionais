name=xcb-util-keysyms
version=0.4.1

source="\
  xcb-util-keysyms-{version}.tar.xz::https://xcb.freedesktop.org/dist/xcb-util-keysyms-{version}.tar.xz \
"

sha256="\
  <sha256-xcb-util-keysyms-{version}.tar.xz> \
"

# Extensões de keysyms para XCB, usadas por i3/bspwm.
deps=(glibc libxcb)

build() {
  set -euo pipefail

  if [[ -d xcb-util-keysyms-${version} ]]; then
    cd xcb-util-keysyms-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
