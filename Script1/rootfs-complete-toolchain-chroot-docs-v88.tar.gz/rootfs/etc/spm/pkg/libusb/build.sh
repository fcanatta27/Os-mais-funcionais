name=libusb
version=1.0.27

source="\
  libusb-{version}.tar.bz2::https://github.com/libusb/libusb/releases/download/v{version}/libusb-{version}.tar.bz2 \
"

sha256="\
  <sha256-libusb-{version}.tar.bz2> \
"

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d libusb-${version} ]]; then
    cd libusb-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
