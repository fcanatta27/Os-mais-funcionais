name=firefox
version=147.0.1

source="\
  firefox-{version}.source.tar.xz::https://archive.mozilla.org/pub/firefox/releases/{version}/source/firefox-{version}.source.tar.xz \
"

sha256="\
  <sha256-firefox-{version}.source.tar.xz> \
"

# Firefox compilado a partir do código-fonte.
# Este build.sh usa o 'mach' para baixar toolchains necessários e compilar.
# Dependências em tempo de execução: stack gráfico + áudio + fontes.
deps=(glibc gtk3 gtk4 pango cairo dbus gdk-pixbuf alsa-lib pipewire libX11 libXrender libXrandr libXcursor freetype fontconfig libxcb)

build() {
  set -euo pipefail

  if [[ -d firefox-${version} ]]; then
    cd firefox-${version}
  fi

  # A árvore do Firefox vem com o script 'mach'.
  # Prepara ambiente de build isolado.
  export MOZ_NOSPAM=1
  export MOZBUILD_STATE_PATH="${PWD}/.mozbuild"
  export MACH_USE_SYSTEM_PYTHON=1

  # Bootstrapping: baixa toolchains (rust, clang, etc) para dentro da árvore.
  # Evita mexer no sistema.
  ./mach bootstrap --application-choice browser --no-system-changes << EOF || true
EOF

  # Gera configuração padrão (Release, idioma en-US).
  cat > .mozconfig << 'EOF'
ac_add_options --enable-release
ac_add_options --disable-debug
ac_add_options --enable-optimize
ac_add_options --prefix=/usr
ac_add_options --enable-default-toolkit=cairo-gtk3
ac_add_options --enable-official-branding
ac_add_options --enable-alsa
ac_add_options --disable-updater
ac_add_options --disable-crashreporter
ac_add_options --with-system-zlib
ac_add_options --with-system-bz2
ac_add_options --with-system-png
ac_add_options --with-system-libevent
ac_add_options --with-system-libvpx
ac_add_options --enable-system-ffi
mk_add_options MOZ_OBJDIR=./obj-build
EOF

  ./mach build

  # Empacota o resultado em um tar dentro da árvore e depois instala em DESTDIR.
  ./mach package

  mkdir -p "${DESTDIR}/usr/lib/firefox"
  mkdir -p "${DESTDIR}/usr/bin"

  # Procura o pacote gerado
  PKG_TAR=$(find obj-build/dist -maxdepth 1 -type f -name 'firefox-*.tar.*' | head -n1 || true)
  if [[ -n "${PKG_TAR}" ]]; then
    tar -xf "${PKG_TAR}" -C "${DESTDIR}/usr/lib/firefox" --strip-components=1
  else:
    # fallback: copiar binários diretamente do objdir
    cp -a obj-build/dist/bin/* "${DESTDIR}/usr/lib/firefox"/
  fi

  cat > "${DESTDIR}/usr/bin/firefox" << 'EOF'
#!/bin/sh
exec /usr/lib/firefox/firefox "$@"
EOF
  chmod +x "${DESTDIR}/usr/bin/firefox"
}

post_install() {
  :
}
