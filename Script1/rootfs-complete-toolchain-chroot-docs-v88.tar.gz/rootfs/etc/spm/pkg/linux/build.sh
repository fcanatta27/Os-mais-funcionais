name=linux
version=6.16.1

source="\
  linux-{version}.tar.xz::https://cdn.kernel.org/pub/linux/kernel/v6.x/linux-{version}.tar.xz \
"

sha256="\
  <sha256-linux-{version}.tar.xz> \
"

deps=(glibc bc bison flex perl openssl libelf)

build() {
  set -euo pipefail

  if [[ -d linux-${version} ]]; then
    cd linux-${version}
  fi

  # Copia config extra se existir na pasta do pacote
  if [[ -f "$SPM_PKGDIR/config" ]]; then
    cp -v "$SPM_PKGDIR/config" .config
  elif [[ -f "$SPM_PKGDIR/config-${version}" ]]; then
    cp -v "$SPM_PKGDIR/config-${version}" .config
  else
    make defconfig
  fi

  # Garante consistência do config
  yes "" | make oldconfig

  make -j"${JOBS:-1}"

  make modules_install INSTALL_MOD_PATH="$DESTDIR"

  mkdir -p "$DESTDIR/boot"
  cp -v arch/x86/boot/bzImage "$DESTDIR/boot/vmlinuz-${version}"
  cp -v System.map "$DESTDIR/boot/System.map-${version}"
  cp -v .config "$DESTDIR/boot/config-${version}"
}

post_install() {
  echo "[spm] Kernel ${version} instalado em /boot (vmlinuz, System.map, config)"
}
