name=texlive
version=20250308

source="  texlive-{version}.tar.xz::https://mirror.ctan.org/systems/texlive/tlnet/archive/texlive-{version}.tar.xz "

sha256="<sha256-texlive-{version}.tar.xz>"

deps=(glibc perl python)

build() {
  set -euo pipefail
  cd texlive-${version}

  ./install-tl \
    -profile /dev/stdin <<'EOF'
selected_scheme scheme-small
TEXDIR /usr/share/texlive
TEXMFCONFIG ~/.texlive/texmf-config
TEXMFVAR ~/.texlive/texmf-var
binary_x86_64-linux 1
option_doc 0
option_src 0
EOF

  mkdir -p "${DESTDIR}/usr"
  cp -a /usr/share/texlive "${DESTDIR}/usr/share/"
}
