name=lsb-tools
version=0.12

source="  lsb-tools-{version}.tar.gz::https://downloads.sourceforge.net/project/lsb/lsb-tools/{version}/lsb-tools-{version}.tar.gz "

sha256="  <sha256-lsb-tools-{version}.tar.gz> "

deps=(glibc perl python)

build() {
  set -euo pipefail

  if [[ -d lsb-tools-${version} && ! -x ./configure ]]; then
    cd lsb-tools-${version}
  fi

  ./configure \
    --prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  if command -v lsb_release >/dev/null 2>&1; then
    lsb_release -a 2>/dev/null || true
  fi
}
