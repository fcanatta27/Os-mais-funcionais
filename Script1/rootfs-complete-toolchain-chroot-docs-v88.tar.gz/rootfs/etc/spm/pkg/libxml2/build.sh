name=libxml2
version=2.14.5

source="\
  libxml2-{version}.tar.xz::https://download.gnome.org/sources/libxml2/2.14/libxml2-{version}.tar.xz \
"

sha256="\
  <sha256-libxml2-{version}.tar.xz> \
"

deps=(glibc zlib xz)

build() {
  set -euo pipefail
  if [[ -d libxml2-${version} ]]; then
    cd libxml2-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static \
    --with-history \
    --with-python

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
