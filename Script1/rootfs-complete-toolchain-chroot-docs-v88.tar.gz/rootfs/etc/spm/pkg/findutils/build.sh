name=findutils
version=4.10.0

source="\
  findutils-{version}.tar.xz::https://ftp.gnu.org/gnu/findutils/findutils-{version}.tar.xz \
"

sha256="\
  <sha256-findutils-{version}.tar.xz> \
"

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d findutils-${version} && ! -x ./configure ]]; then
    cd findutils-${version}
  fi

  ./configure \
    --prefix=/usr \
    --localstatedir=/var/lib/locate

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"

  # Se /bin existir, criamos link de compatibilidade para xargs e find
  if [[ -d "$DESTDIR/bin" ]]; then
    for prog in find xargs; do
      if [[ -x "$DESTDIR/usr/bin/$prog" && ! -e "$DESTDIR/bin/$prog" ]]; then
        ln -sv "../usr/bin/$prog" "$DESTDIR/bin/$prog"
      fi
    done
  fi
}

post_install() {
  if command -v find >/dev/null 2>&1; then
    find / -maxdepth 1 -print >/dev/null 2>&1 || true
  fi
}
