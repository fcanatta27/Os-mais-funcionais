name=gzip
version=1.14

source="      gzip-{version}.tar.xz::https://ftp.gnu.org/gnu/gzip/gzip-{version}.tar.xz     "

sha256="      <sha256-gzip-{version}.tar.xz>     "

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d gzip-${version} && ! -x ./configure ]]; then
    cd gzip-${version}
  fi

  ./configure \
    --prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"

  # Em sistemas com /bin separado, criamos um link de compatibilidade.
  if [[ -d "$DESTDIR/bin" ]]; then
    if [[ -x "$DESTDIR/usr/bin/gzip" && ! -e "$DESTDIR/bin/gzip" ]]; then
      ln -sv "../usr/bin/gzip" "$DESTDIR/bin/gzip"
    fi
  fi
}

post_install() {
  if command -v gzip >/dev/null 2>&1; then
    echo "spm gzip test" | gzip -c | gzip -d >/dev/null 2>&1 || true
  fi
}
