# Definição de pacote SPM para Python 3 (CPython)
name=python
version=3.13.7

# Tarball oficial do Python
source="Python-{version}.tar.xz::https://www.python.org/ftp/python/{version}/Python-{version}.tar.xz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
sha256="-"

# Dependências em C típicas do Python: libc, compressão, crypto, ffi, ncurses, readline, expat, etc.
deps=(glibc zlib bzip2 xz libffi openssl ncurses readline expat)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/Python-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:python] Configurando Python-${version}..."

  # Garante uso de bibliotecas do sistema onde possível
  export CPPFLAGS="${CPPFLAGS:-} -I/usr/include"
  export LDFLAGS="${LDFLAGS:-} -L/usr/lib"

  "$srcdir/configure" \
    --prefix=/usr \
    --enable-optimizations \
    --with-lto \
    --enable-shared \
    --with-system-ffi \
    --with-openssl=/usr \
    --enable-loadable-sqlite-extensions \
    --with-ensurepip=install

  echo "[spm:python] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  if [[ "${PYTHON_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:python] Executando 'make test' (muito demorado, requer ambiente preparado)..."
    make test || echo "[spm:python][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:python] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  # Links e conveniências
  # Garante que 'python3' exista
  if [[ -x "$DESTDIR/usr/bin/python3" && ! -e "$DESTDIR/usr/bin/python" ]]; then
    ln -sf python3 "$DESTDIR/usr/bin/python"
  fi

  # Remover bytecode redundante de testes se quiser; aqui apenas limpamos alguns lixos padrão
  find "$DESTDIR/usr/lib" -name "test" -type d -path "*python3.*/*" -prune -exec rm -rf '{}' + 2>/dev/null || true

  echo "[spm:python] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do Python.
  :
}
