name=rsync
version=3.4.1

source="\
  rsync-{version}.tar.gz::https://download.samba.org/pub/rsync/rsync-{version}.tar.gz \
"

sha256="\
  <sha256-rsync-{version}.tar.gz> \
"

deps=(glibc zlib openssl)

build() {
  set -euo pipefail
  if [[ -d rsync-${version} ]]; then
    cd rsync-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --disable-static \
    --with-included-zlib=no \
    --with-openssl

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  rsync --version 2>/dev/null || true
}
