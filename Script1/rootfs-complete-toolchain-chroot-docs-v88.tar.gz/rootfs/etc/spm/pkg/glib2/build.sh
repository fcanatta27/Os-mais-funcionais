name=glib2
version=2.80.4

source="\
  glib-{version}.tar.xz::https://download.gnome.org/sources/glib/2.80/glib-{version}.tar.xz \
"

sha256="\
  <sha256-glib-{version}.tar.xz> \
"

# Core GLib, base para Pango, GTK, etc.
deps=(glibc libmount zlib libffi pcre2)

build() {
  set -euo pipefail

  if [[ -d glib-${version} ]]; then
    cd glib-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dgtk_doc=false \
    -Dman=false \
    -Dtests=false

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build

  find "${DESTDIR}/usr/lib" -name 'libglib-2.0*.la' -delete 2>/dev/null || true
}

post_install() {
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --modversion glib-2.0 2>/dev/null || true
  fi
}
