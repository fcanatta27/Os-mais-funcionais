name=libyaml
version=0.2.5

source="  yaml-{version}.tar.gz::https://pyyaml.org/download/libyaml/yaml-{version}.tar.gz "

sha256="  <sha256-yaml-{version}.tar.gz> "

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d yaml-${version} && ! -x ./configure ]]; then
    cd yaml-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libyaml*.la' -delete 2>/dev/null || true
}

post_install() {
  ls /usr/lib/libyaml* 2>/dev/null || true
}
