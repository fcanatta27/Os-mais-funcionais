name=xfdesktop
version=4.20.0

source="\
  xfdesktop-{version}.tar.bz2::https://archive.xfce.org/src/xfce/xfdesktop/4.20/xfdesktop-{version}.tar.bz2 \
"

sha256="\
  <sha256-xfdesktop-{version}.tar.bz2> \
"

# Desktop do Xfce (ícones, menu de contexto, wallpaper).
deps=(glibc glib2 gtk3 libxfce4ui libxfce4util exo garcon xfconf)

build() {
  set -euo pipefail

  if [[ -d xfdesktop-${version} ]]; then
    cd xfdesktop-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
