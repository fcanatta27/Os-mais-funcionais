name=libudev
version=virtual-1

source=""
sha256=""

# Meta-pacote que expõe a biblioteca libudev provida pelo systemd.
deps=(systemd)

build() {
  set -euo pipefail
  echo "libudev é um meta-pacote; nenhuma build necessária."
}

post_install() {
  :
}
