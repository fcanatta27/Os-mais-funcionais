name=lzo
version=2.10

source="  lzo-{version}.tar.gz::https://www.oberhumer.com/opensource/lzo/download/lzo-{version}.tar.gz "

sha256="  <sha256-lzo-{version}.tar.gz> "

deps=(glibc)

build() {
  set -euo pipefail
  cd lzo-${version}

  ./configure     --prefix=/usr     --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
