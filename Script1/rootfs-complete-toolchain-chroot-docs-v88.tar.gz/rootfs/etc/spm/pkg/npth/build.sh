name=npth
version=1.8

source="\
  npth-{version}.tar.bz2::https://www.gnupg.org/ftp/gcrypt/npth/npth-{version}.tar.bz2 \
"

sha256="\
  <sha256-npth-{version}.tar.bz2> \
"

deps=(glibc)

build() {
  set -euo pipefail
  cd npth-${version}

  ./configure     --prefix=/usr     --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
