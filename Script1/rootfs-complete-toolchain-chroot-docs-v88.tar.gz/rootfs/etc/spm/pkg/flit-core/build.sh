# Definição de pacote SPM para flit-core (backend de build para Python)
name=flit-core
version=3.12.0

# Tarball oficial do flit_core no PyPI
source="flit_core-{version}.tar.gz::https://files.pythonhosted.org/packages/source/f/flit_core/flit_core-{version}.tar.gz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
sha256="-"

deps=(glibc python)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"

  echo "[spm:flit-core] Instalando flit-core-{version} via pip no prefix /usr (DESTDIR)..."

  # Usamos pip sem acesso à rede, construindo a partir do tarball já extraído.
  PYTHONUTF8=1 python3 -m pip install . \
    --no-deps \
    --no-build-isolation \
    --prefix=/usr \
    --root="$DESTDIR"

  echo "[spm:flit-core] Instalação em staging concluída."
}

post_install() {
  # Hook opcional após instalação real do flit-core.
  :
}
