name=expect
version=5.45.4

source="expect{version}.tar.gz::https://prdownloads.sourceforge.net/expect/expect{version}.tar.gz"
sha256="-"

deps=(glibc tcl)

build() {
  set -euo pipefail
  : "${DESTDIR:?}" "${TMP:?}"

  local src="$PWD"
  local build="$TMP/${name}-${version}-build"
  rm -rf "$build"
  mkdir -p "$build"
  cd "$build"

  echo "[spm:expect] Configurando..."
  "$src/configure" \
    --prefix=/usr \
    --with-tcl=/usr/lib \
    --with-tclinclude=/usr/include \
    --mandir=/usr/share/man

  make -j"${JOBS:-1}"

  if [[ "${EXPECT_RUN_TESTS:-0}" = 1 ]]; then
    make test || echo "[spm:expect][WARN] testes falharam"
  fi

  make install DESTDIR="$DESTDIR"
}

post_install() { :; }
