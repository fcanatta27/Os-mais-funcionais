name=libpciaccess
version=0.18

source="\
  libpciaccess-{version}.tar.xz::https://www.x.org/releases/individual/lib/libpciaccess-{version}.tar.xz \
"

sha256="\
  <sha256-libpciaccess-{version}.tar.xz> \
"

deps=(glibc zlib)

build() {
  set -euo pipefail

  if [[ -d libpciaccess-${version} ]]; then
    cd libpciaccess-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
