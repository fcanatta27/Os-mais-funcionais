name=x11-lib
version=virtual-1

source=""

sha256=""

# Meta-package agregando as bibliotecas básicas do X11.
deps=(libX11 libXext libXt libXmu libXrender libXrandr)

build() {
  set -euo pipefail
  echo "Pacote virtual x11-lib; nenhuma build necessária."
}

post_install() {
  :
}
