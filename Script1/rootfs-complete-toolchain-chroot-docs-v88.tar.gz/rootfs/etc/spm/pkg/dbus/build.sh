name=dbus
version=1.16.2

source="  dbus-{version}.tar.xz::https://dbus.freedesktop.org/releases/dbus/dbus-{version}.tar.xz "

sha256="  <sha256-dbus-{version}.tar.xz> "

deps=(glibc expat systemd)

build() {
  set -euo pipefail
  cd dbus-${version}

  ./configure     --prefix=/usr     --sysconfdir=/etc     --localstatedir=/var     --runstatedir=/run     --enable-user-session     --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  mkdir -p "${DESTDIR}/etc/dbus-1/system.d"
}
