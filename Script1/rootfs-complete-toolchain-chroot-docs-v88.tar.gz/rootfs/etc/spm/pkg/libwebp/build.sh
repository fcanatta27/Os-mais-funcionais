name=libwebp
version=1.4.0

source="\
  libwebp-{version}.tar.gz::https://github.com/webmproject/libwebp/archive/refs/tags/v{version}.tar.gz \
"

sha256="\
  <sha256-libwebp-{version}.tar.gz> \
"

# Biblioteca para imagens WebP.
deps=(glibc libpng jpeg zlib)

build() {
  set -euo pipefail

  if [[ -d libwebp-${version} ]]; then
    cd libwebp-${version}
  fi

  cmake -S . -B build \
    -DCMAKE_INSTALL_PREFIX=/usr \
    -DCMAKE_BUILD_TYPE=Release \
    -DBUILD_SHARED_LIBS=ON

  cmake --build build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" cmake --install build
}

post_install() {
  :
}
