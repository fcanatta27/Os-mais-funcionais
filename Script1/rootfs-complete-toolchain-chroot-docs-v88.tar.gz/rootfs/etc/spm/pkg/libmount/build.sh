name=libmount
version=virtual-1

source=""

sha256=""

# Meta-package: a biblioteca libmount vem do util-linux.
deps=(util-linux)

build() {
  set -euo pipefail
  echo "libmount é fornecido pelo util-linux; nenhum build necessário."
}

post_install() {
  :
}
