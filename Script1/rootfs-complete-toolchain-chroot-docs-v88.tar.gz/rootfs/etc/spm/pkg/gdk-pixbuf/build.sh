name=gdk-pixbuf
version=2.42.12

source="\
  gdk-pixbuf-{version}.tar.xz::https://download.gnome.org/sources/gdk-pixbuf/2.42/gdk-pixbuf-{version}.tar.xz \
"

sha256="\
  <sha256-gdk-pixbuf-{version}.tar.xz> \
"

# Biblioteca para carregar/transformar imagens.
# Aqui usamos apenas PNG para evitar dependências extras.
deps=(glib2 libpng)

build() {
  set -euo pipefail

  if [[ -d gdk-pixbuf-${version} ]]; then
    cd gdk-pixbuf-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dgtk_doc=false \
    -Dinstalled_tests=false \
    -Dman=false

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build

  if command -v gdk-pixbuf-query-loaders >/dev/null 2>&1; then
    gdk-pixbuf-query-loaders > "${DESTDIR}/usr/lib/gdk-pixbuf-2.0/2.10.0/loaders.cache" 2>/dev/null || true
  fi
}

post_install() {
  if command -v gdk-pixbuf-query-loaders >/dev/null 2>&1; then
    gdk-pixbuf-query-loaders --update-cache 2>/dev/null || true
  fi
}
