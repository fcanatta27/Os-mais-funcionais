name=vte3
version=0.76.0

source="\
  vte-{version}.tar.xz::https://download.gnome.org/sources/vte/0.76/vte-{version}.tar.xz \
"

sha256="\
  <sha256-vte-{version}.tar.xz> \
"

# Biblioteca de terminal usada pelo xfce4-terminal (backend de emulação).
# Essa variante é a baseada em GTK3.
deps=(glibc glib2 gtk3 pcre2)

build() {
  set -euo pipefail

  if [[ -d vte-${version} ]]; then
    cd vte-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dgtk3=true \
    -Dgtk4=false \
    -Dintrospection=disabled \
    -Dgtk_doc=false

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --modversion vte-2.91 2>/dev/null || true
  fi
}
