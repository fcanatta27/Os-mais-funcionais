name=dosfstools
version=4.2

source="\
  dosfstools-{version}.tar.gz::https://github.com/dosfstools/dosfstools/releases/download/v{version}/dosfstools-{version}.tar.gz \
"

sha256="\
  <sha256-dosfstools-{version}.tar.gz> \
"

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d dosfstools-${version} ]]; then
    cd dosfstools-${version}
  fi

  make -j"${JOBS:-1}"

  make PREFIX=/usr install DESTDIR="$DESTDIR"
}

post_install() {
  if command -v mkfs.fat >/dev/null 2>&1; then
    mkfs.fat --version || true
  fi
}
