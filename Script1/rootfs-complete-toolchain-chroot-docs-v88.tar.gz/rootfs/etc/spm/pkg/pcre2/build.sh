name=pcre2
version=10.45

source="  pcre2-{version}.tar.bz2::https://github.com/PCRE2Project/pcre2/releases/download/pcre2-{version}/pcre2-{version}.tar.bz2 "

sha256="  <sha256-pcre2-{version}.tar.bz2> "

deps=(glibc)

build() {
  set -euo pipefail
  cd pcre2-${version}

  ./configure     --prefix=/usr     --enable-unicode     --enable-pcre2-16     --enable-pcre2-32     --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
