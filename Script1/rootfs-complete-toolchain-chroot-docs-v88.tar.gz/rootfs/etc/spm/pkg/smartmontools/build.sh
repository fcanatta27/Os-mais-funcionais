name=smartmontools
version=7.5

source="  smartmontools-{version}.tar.gz::https://downloads.sourceforge.net/smartmontools/smartmontools-{version}.tar.gz "

sha256="  <sha256-smartmontools-{version}.tar.gz> "

deps=(glibc libcap)

build() {
  set -euo pipefail
  cd smartmontools-${version}

  ./configure     --prefix=/usr     --sysconfdir=/etc     --localstatedir=/var

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  # serviço systemd
  mkdir -p "${DESTDIR}/etc/systemd/system"
  if [[ -f smartd.service ]]; then
    install -m644 smartd.service "${DESTDIR}/etc/systemd/system/smartd.service"
  fi
}
