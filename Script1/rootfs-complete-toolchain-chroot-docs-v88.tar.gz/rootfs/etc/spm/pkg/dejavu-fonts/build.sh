name=dejavu-fonts
version=2.37

source="dejavu-fonts-{version}.tar.bz2::https://downloads.sourceforge.net/project/dejavu/dejavu/{version}/dejavu-fonts-{version}.tar.bz2"
sha256="<sha256-dejavu>"

deps=()

build() {
  set -euo pipefail
  cd dejavu-fonts-${version}

  install -d "${DESTDIR}/usr/share/fonts/dejavu"
  install -m644 ttf/*.ttf "${DESTDIR}/usr/share/fonts/dejavu/"
}
