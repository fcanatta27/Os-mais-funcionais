    name=setuptools
    version=80.9.0

    # Fonte principal a partir do PyPI
    source="\
      setuptools-{version}.tar.gz::https://files.pythonhosted.org/packages/source/s/setuptools/setuptools-{version}.tar.gz \
    "

    # Preencha com 'spm checksum setuptools' depois do primeiro download
    sha256="\
      <sha256-setuptools-{version}.tar.gz> \
    "

    # Dependências de build/runtime
    deps=(python)

    build() {
      set -euo pipefail

      # Diretório do código fonte já extraído pelo spm
      # Assumimos que o tarball cria o diretório setuptools-{version}
      cd "setuptools-${version}"

      # Garante que vamos usar o Python do sistema
      PYTHON=${PYTHON:-python3}

      # Instalação via pip, sem deps (o spm cuida das dependências)
      # e sem build isolation (usa o ambiente atual)
      "$PYTHON" -m pip install . \
        --root="$DESTDIR" \
        --prefix=/usr \
        --no-deps \
        --no-build-isolation
    }

    post_install() {
      # Opcional: só confirma que setuptools está visível
      if command -v python3 >/dev/null 2>&1; then
        python3 - << 'EOF' || true
import pkg_resources
try:
    import setuptools
    print("[spm] setuptools", setuptools.__version__, "instalado.")
except Exception as e:
    print("[spm] aviso: não foi possível importar setuptools:", e)
EOF
      fi
    }
