name=xf86-input-libinput
version=1.5.0

source="\
  xf86-input-libinput-{version}.tar.bz2::https://www.x.org/releases/individual/driver/xf86-input-libinput-{version}.tar.bz2 \
"

sha256="\
  <sha256-xf86-input-libinput-{version}.tar.bz2> \
"

deps=(glibc xorg-server xorgproto libinput)

build() {
  set -euo pipefail

  if [[ -d xf86-input-libinput-${version} ]]; then
    cd xf86-input-libinput-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc/X11 \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libxf86-input-libinput*.la' -delete 2>/dev/null || true
}

post_install() {
  ls /usr/lib/xorg/modules/input/libinput_drv.* 2>/dev/null || true
}
