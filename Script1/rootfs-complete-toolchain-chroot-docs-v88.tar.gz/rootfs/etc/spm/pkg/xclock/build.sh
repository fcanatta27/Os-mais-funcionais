name=xclock
version=1.1.1

source="\
  xclock-{version}.tar.xz::https://www.x.org/releases/individual/app/xclock-{version}.tar.xz \
"

sha256="\
  <sha256-xclock-{version}.tar.xz> \
"

# Relógio gráfico simples para X. Ótimo para testar ambiente X.
deps=(glibc xorg-server libX11 libXmu libXt libXrender libXft xbitmaps)

build() {
  set -euo pipefail

  if [[ -d xclock-${version} ]]; then
    cd xclock-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  command -v xclock >/dev/null 2>&1 || true
}
