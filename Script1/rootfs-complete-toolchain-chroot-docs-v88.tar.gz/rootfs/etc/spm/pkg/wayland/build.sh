name=wayland
version=1.23.0

source="\
  wayland-{version}.tar.xz::https://gitlab.freedesktop.org/wayland/wayland/-/releases/{version}/downloads/wayland-{version}.tar.xz \
"

sha256="\
  <sha256-wayland-{version}.tar.xz> \
"

# Implementação core do protocolo Wayland.
deps=(glibc libffi expat libxml2 pkgconf)

build() {
  set -euo pipefail

  if [[ -d wayland-${version} ]]; then
    cd wayland-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Ddocumentation=false \
    -Dtests=false

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build

  find "${DESTDIR}/usr/lib" -name 'libwayland-*.la' -delete 2>/dev/null || true
}

post_install() {
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --modversion wayland-client 2>/dev/null || true
  fi
}
