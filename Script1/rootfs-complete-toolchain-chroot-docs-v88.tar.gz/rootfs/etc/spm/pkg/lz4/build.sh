# Definição de pacote SPM para lz4 (utilitário e biblioteca de compressão LZ4)
name=lz4
version=1.10.0

# Tarball oficial do lz4
source="lz4-{version}.tar.gz::https://github.com/lz4/lz4/archive/refs/tags/v{version}.tar.gz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' enquanto não tiver o hash real.
sha256="-"

deps=(glibc)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:lz4] Construindo lz4-${version}..."
  make -C "$srcdir" -j"${JOBS:-1}"

  echo "[spm:lz4] Instalando em DESTDIR=${DESTDIR} com PREFIX=/usr..."
  make -C "$srcdir" PREFIX=/usr DESTDIR="$DESTDIR" install

  echo "[spm:lz4] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do lz4.
  :
}
