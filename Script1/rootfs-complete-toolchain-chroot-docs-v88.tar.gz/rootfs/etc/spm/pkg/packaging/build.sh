# Definição de pacote SPM para packaging (utilitários de versionamento e requisitos Python)
name=packaging
version=25.0

# Tarball oficial do packaging no PyPI
source="packaging-{version}.tar.gz::https://files.pythonhosted.org/packages/source/p/packaging/packaging-{version}.tar.gz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
sha256="-"

deps=(glibc python)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"

  echo "[spm:packaging] Instalando packaging-{version} via pip no prefix /usr (DESTDIR)..."

  PYTHONUTF8=1 python3 -m pip install . \
    --no-deps \
    --no-build-isolation \
    --prefix=/usr \
    --root="$DESTDIR"

  echo "[spm:packaging] Instalação em staging concluída."
}

post_install() {
  # Hook opcional após instalação real do packaging.
  :
}
