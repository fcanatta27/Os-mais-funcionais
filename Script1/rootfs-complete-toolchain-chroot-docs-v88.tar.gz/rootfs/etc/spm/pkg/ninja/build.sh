name=ninja
version=1.13.1

source="\
  ninja-v{version}.tar.gz::https://github.com/ninja-build/ninja/archive/refs/tags/v{version}.tar.gz \
"

sha256="\
  <sha256-ninja-v{version}.tar.gz> \
"

deps=(python)

build() {
  set -euo pipefail

  cd "ninja-${version}"

  PYTHON=${PYTHON:-python3}

  # Bootstrap do próprio ninja (não depende de ninja já instalado)
  "$PYTHON" configure.py --bootstrap

  install -Dm755 ninja "$DESTDIR/usr/bin/ninja"

  # Instala também o symlink 'ninja-build' por compatibilidade
  ln -sv ninja "$DESTDIR/usr/bin/ninja-build"

  # Documentação básica, se disponível
  if [[ -f doc/manual.asciidoc ]]; then
    mkdir -p "$DESTDIR/usr/share/doc/ninja"
    cp -v doc/manual.asciidoc "$DESTDIR/usr/share/doc/ninja/manual.asciidoc"
  fi
}

post_install() {
  # Teste rápido: verifica se o binário responde
  if command -v ninja >/dev/null 2>&1; then
    ninja --version || true
  fi
}
