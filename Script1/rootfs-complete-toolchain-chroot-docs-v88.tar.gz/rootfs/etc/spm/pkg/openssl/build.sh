# Definição de pacote SPM para OpenSSL (biblioteca e utilitários TLS/cripto)
name=openssl
version=3.5.2

# Tarball oficial do OpenSSL
source="openssl-{version}.tar.gz::https://www.openssl.org/source/openssl-{version}.tar.gz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
sha256="-"

# OpenSSL depende de glibc e zlib (para compressão)
deps=(glibc zlib)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cp -a "$srcdir"/. "$builddir"/
  cd "$builddir"

  echo "[spm:openssl] Configurando OpenSSL-${version}..."

  # Profile padrão para x86_64 Linux; ajuste se for outra arquitetura.
  local config_target="linux-x86_64"

  ./Configure "${config_target}" \
    --prefix=/usr \
    --openssldir=/etc/ssl \
    --libdir=lib \
    shared \
    zlib

  echo "[spm:openssl] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  if [[ "${OPENSSL_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:openssl] Executando 'make test' (pode ser bem demorado)..."
    make test || echo "[spm:openssl][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:openssl] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR" MANDIR=/usr/share/man

  # Certifique-se de que o diretório de certificados exista
  mkdir -p "$DESTDIR/etc/ssl/certs"

  echo "[spm:openssl] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do OpenSSL.
  # Ex.: rodar c_rehash em /etc/ssl/certs.
  :
}
