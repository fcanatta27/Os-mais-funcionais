name=patch
version=2.7.6

source="      patch-{version}.tar.xz::https://ftp.gnu.org/gnu/patch/patch-{version}.tar.xz     "

sha256="      <sha256-patch-{version}.tar.xz>     "

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d patch-${version} && ! -x ./configure ]]; then
    cd patch-${version}
  fi

  ./configure \
    --prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"
}

post_install() {
  if command -v patch >/dev/null 2>&1; then
    patch --version | head -n1 || true
  fi
}
