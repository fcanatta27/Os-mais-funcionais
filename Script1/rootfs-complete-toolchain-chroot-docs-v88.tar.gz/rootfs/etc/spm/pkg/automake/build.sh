# Definição de pacote SPM para automake (parte dos autotools)
name=automake
version=1.18

# Tarball oficial do automake (ajuste se a upstream usar outro nome ou versão)
source="automake-{version}.tar.xz::https://ftp.gnu.org/gnu/automake/automake-{version}.tar.xz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
sha256="-"

# automake depende de autoconf, Perl e m4 (indiretamente)
deps=(glibc autoconf perl m4)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:automake] Configurando automake-${version}..."
  "$srcdir/configure" \
    --prefix=/usr \
    --docdir=/usr/share/doc/automake-${version}

  echo "[spm:automake] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  if [[ "${AUTOMAKE_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:automake] Executando 'make check' (pode ser demorado)..."
    make check || echo "[spm:automake][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:automake] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  echo "[spm:automake] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do automake.
  :
}
