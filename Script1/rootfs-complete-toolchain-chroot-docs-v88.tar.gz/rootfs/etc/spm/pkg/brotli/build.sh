name=brotli
version=1.1.0

source="\
  brotli-{version}.tar.gz::https://github.com/google/brotli/archive/refs/tags/v{version}.tar.gz \
"

sha256="\
  <sha256-brotli-{version}.tar.gz> \
"

deps=(glibc cmake)

build() {
  set -euo pipefail

  srcdir="$(find . -maxdepth 1 -type d -name 'brotli-*' | head -n1)"
  [ -n "$srcdir" ] && cd "$srcdir"

  mkdir -p build
  cd build

  cmake .. \
    -DCMAKE_INSTALL_PREFIX=/usr \
    -DCMAKE_BUILD_TYPE=Release \
    -DBUILD_SHARED_LIBS=ON

  cmake --build . -- -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" cmake --install .
}

post_install() {
  if command -v brotli >/dev/null 2>&1; then
    brotli --version 2>/dev/null || true
  fi
}
