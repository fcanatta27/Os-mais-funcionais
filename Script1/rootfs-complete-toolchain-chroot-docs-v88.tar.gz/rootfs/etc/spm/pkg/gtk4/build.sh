name=gtk4
version=4.14.0

source="\
  gtk-{version}.tar.xz::https://download.gnome.org/sources/gtk/4.14/gtk-{version}.tar.xz \
"

sha256="\
  <sha256-gtk-{version}.tar.xz> \
"

# Toolkit gráfico GTK4 com suporte a X11 e Wayland.
# Dependências baseadas no seu stack atual.
deps=(glibc glib2 pango cairo gdk-pixbuf wayland wayland-protocols libepoxy libxkbcommon libX11 libXext)

build() {
  set -euo pipefail

  if [[ -d gtk-${version} ]]; then
    cd gtk-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dbuild-examples=false \
    -Dbuild-tests=false \
    -Dintrospection=disabled \
    -Ddemos=false \
    -Dman-pages=false \
    -Dwayland-backend=true \
    -Dx11-backend=true

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  if command -v gtk4-demo >/dev/null 2>&1; then
    gtk4-demo --version 2>/dev/null || true
  fi
}
