name=power-profiles-daemon
version=0.30

source="\
  power-profiles-daemon-{version}.tar.gz::https://gitlab.freedesktop.org/upower/power-profiles-daemon/-/archive/{version}/power-profiles-daemon-{version}.tar.gz \
"

sha256="\
  <sha256-power-profiles-daemon-{version}.tar.gz> \
"

# Depende fortemente de: glib, systemd, polkit, dbus
deps=(glibc glib systemd polkit dbus)

build() {
  set -euo pipefail

  if [[ -d power-profiles-daemon-${version} && ! -f power-profiles-daemon-${version}/meson.build ]]; then
    cd power-profiles-daemon-${version}
  elif [[ -d power-profiles-daemon-${version} ]]; then
    cd power-profiles-daemon-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --buildtype=release

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build

  # Diretório de config
  mkdir -p "${DESTDIR}/etc/power-profiles-daemon.d"
}

post_install() {
  if command -v powerprofilesctl >/dev/null 2>&1; then
    powerprofilesctl list 2>/dev/null || true
  fi
}
