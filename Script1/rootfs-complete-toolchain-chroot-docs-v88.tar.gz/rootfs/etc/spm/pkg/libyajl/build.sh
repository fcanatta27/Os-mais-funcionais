name=libyajl
version=2.1.0

source="\
  yajl-{version}.tar.gz::https://github.com/lloyd/yajl/archive/refs/tags/{version}.tar.gz \
"

sha256="\
  <sha256-yajl-{version}.tar.gz> \
"

# YAJL - Yet Another JSON Library, usada por i3status.
deps=(glibc cmake)

build() {
  set -euo pipefail

  if [[ -d yajl-${version} ]]; then
    cd yajl-${version}
  fi

  rm -rf build
  mkdir -p build
  cd build

  cmake \
    -DCMAKE_INSTALL_PREFIX=/usr \
    -DCMAKE_BUILD_TYPE=Release \
    -DBUILD_SHARED_LIBS=ON \
    ..

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
