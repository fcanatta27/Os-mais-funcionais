
name=gst-plugins-good
version=1.24.9

source="\
  gst-plugins-good-{version}.tar.xz::https://gstreamer.freedesktop.org/src/gst-plugins-good/gst-plugins-good-{version}.tar.xz \
"

sha256="\
  <sha256-gst-plugins-good-{version}.tar.xz> \
"

# Coleção "good" de plugins GStreamer (licença aceitável, qualidade boa).
# Focamos em um conjunto estável com exemplos/testes desabilitados.
deps=(glibc gstreamer gst-plugins-base glib2 orc)

build() {
  set -euo pipefail
  : "${DESTDIR:?}"

  # SPM garante que o diretório atual é o source extraído.
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dexamples=disabled \
    -Dtests=disabled

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  :
}
