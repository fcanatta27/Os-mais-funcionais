name=alsa-utils
version=1.2.12

source="\
  alsa-utils-{version}.tar.bz2::https://www.alsa-project.org/files/pub/utils/alsa-utils-{version}.tar.bz2 \
"

sha256="\
  <sha256-alsa-utils-{version}.tar.bz2> \
"

# Ferramentas ALSA (alsamixer, amixer, speaker-test, etc).
deps=(glibc alsa-lib ncurses)

build() {
  set -euo pipefail

  if [[ -d alsa-utils-${version} ]]; then
    cd alsa-utils-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --disable-static \
    --with-udev-rules-dir=/usr/lib/udev/rules.d

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
