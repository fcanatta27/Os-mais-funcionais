name=doxygen
version=1.14.0

source="  doxygen-{version}.tar.gz::https://doxygen.nl/files/doxygen-{version}.src.tar.gz "

sha256="  <sha256-doxygen-{version}.src.tar.gz> "

deps=(glibc cmake flex bison)

build() {
  set -euo pipefail

  if [[ -d doxygen-${version} ]]; then
    cd doxygen-${version}
  fi

  rm -rf build
  mkdir build
  cd build

  cmake .. \
    -DCMAKE_INSTALL_PREFIX=/usr \
    -DCMAKE_BUILD_TYPE=Release \
    -DBUILD_SHARED_LIBS=ON

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  if command -v doxygen >/dev/null 2>&1; then
    doxygen --version || true
  fi
}
