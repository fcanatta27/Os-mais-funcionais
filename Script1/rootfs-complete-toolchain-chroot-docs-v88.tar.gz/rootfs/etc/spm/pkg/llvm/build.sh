name=llvm
version=20.1.8

source="  llvm-project-{version}.tar.xz::https://github.com/llvm/llvm-project/releases/download/llvmorg-{version}/llvm-project-{version}.tar.xz "

sha256="<sha256-llvm-project-{version}.tar.xz>"

deps=(glibc cmake ninja python)

build() {
  set -euo pipefail
  cd llvm-project-${version}
  mkdir -p build && cd build

  cmake -G Ninja \
    -DCMAKE_INSTALL_PREFIX=/usr \
    -DLLVM_ENABLE_PROJECTS="clang;lld" \
    -DLLVM_TARGETS_TO_BUILD="X86" \
    -DCMAKE_BUILD_TYPE=Release \
    ../llvm

  ninja -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" ninja install
}
