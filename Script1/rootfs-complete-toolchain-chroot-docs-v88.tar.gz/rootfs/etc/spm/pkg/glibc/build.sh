    # Definição de pacote SPM para glibc final do sistema
    name=glibc
    version=2.42

    # Tarball principal da glibc
    source="glibc-{version}.tar.xz::https://ftp.gnu.org/gnu/libc/glibc-{version}.tar.xz"

    # SHA256 correspondente ao(s) arquivo(s) em 'source'.
    # Use '-' enquanto não tiver o hash real.
    sha256="-"

    # glibc final precisa de headers do kernel já instalados.
    # NÃO coloque gcc como dependência aqui para evitar ciclo com o pacote gcc.
    deps=(linux-headers)

    build() {
      set -euo pipefail

      : "${DESTDIR:?DESTDIR não definido}"
      : "${TMP:?TMP não definido}"

      # Diretório do código-fonte (SPM já entrou no diretório extraído da glibc)
      local srcdir="$PWD"

      # Diretório de build separado (recomendado pela glibc)
      local builddir="$TMP/${name}-${version}-build"
      rm -rf "$builddir"
      mkdir -p "$builddir"
      cd "$builddir"

      # Diretório de headers do kernel no sistema destino (para --with-headers)
      local KERNEL_HEADERS_DIR="/usr/include"

      # Opções de configuração típicas para glibc em sistemas modernos
      local CONFIG_OPTS=(
        "--prefix=/usr"
        "--sysconfdir=/etc"
        "--enable-kernel=4.19"
        "--enable-stack-protector=strong"
        "--disable-werror"
        "--with-headers=${KERNEL_HEADERS_DIR}"
        "libc_cv_slibdir=/usr/lib"
      )

      echo "[spm:glibc] Configurando glibc-${version}..."
      "$srcdir/configure" "${CONFIG_OPTS[@]}"

      echo "[spm:glibc] Compilando com ${JOBS:-1} jobs..."
      make -j"${JOBS:-1}"

      # Testes opcionais: extremamente pesados, só rode se souber o que está fazendo
      if [[ "${GLIBC_RUN_TESTS:-0}" = "1" ]]; then
        echo "[spm:glibc] Executando 'make -k check' (pode ser MUITO demorado)..."
        make -k check || echo "[spm:glibc][WARN] Alguns testes falharam (veja logs)."
      fi

      echo "[spm:glibc] Instalando em DESTDIR=${DESTDIR}..."
      make install DESTDIR="$DESTDIR"

      # Criar alguns arquivos básicos se ainda não existirem no DESTDIR
      # /etc/ld.so.conf é usado pelo ldconfig e pode ter includes de /etc/ld.so.conf.d
      if [[ ! -f "$DESTDIR/etc/ld.so.conf" ]]; then
        echo "[spm:glibc] Criando /etc/ld.so.conf padrão..."
        mkdir -p "$DESTDIR/etc"
        cat >"$DESTDIR/etc/ld.so.conf" <<'EOF'
/usr/local/lib
/opt/lib

include /etc/ld.so.conf.d/*.conf
EOF
      fi

      # nsswitch.conf padrão mínima (se não existir)
      if [[ ! -f "$DESTDIR/etc/nsswitch.conf" ]]; then
        echo "[spm:glibc] Criando /etc/nsswitch.conf padrão..."
        cat >"$DESTDIR/etc/nsswitch.conf" <<'EOF'
# /etc/nsswitch.conf
passwd:     files
group:      files
shadow:     files

hosts:      files dns
networks:   files

protocols:  files
services:   files
ethers:     files
rpc:        files

netgroup:   files
EOF
      fi

      echo "[spm:glibc] Build e instalação em staging concluídos."
    }

    post_install() {
      # Hook opcional executado após a instalação real no sistema.
      # Aqui poderíamos, por exemplo, rodar ldconfig dentro do sistema alvo.
      # Exemplo (descomentando se apropriado para o seu ambiente):
      #
      #   if command -v ldconfig >/dev/null 2>&1; then
      #     echo "[spm:glibc] Executando ldconfig..."
      #     ldconfig
      #   fi
      #
      :
    }
