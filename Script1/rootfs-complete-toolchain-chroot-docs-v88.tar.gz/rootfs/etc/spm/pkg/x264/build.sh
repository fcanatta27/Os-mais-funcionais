name=x264
version=stable

source="\
  x264.tar.bz2::https://code.videolan.org/videolan/x264/-/archive/stable/x264-stable.tar.bz2 \
"

sha256="\
  <sha256-x264.tar.bz2> \
"

deps=(glibc yasm)

build() {
  set -euo pipefail
  cd x264-stable
  ./configure --prefix=/usr --enable-shared
  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
