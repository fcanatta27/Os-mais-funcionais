# Definição de pacote SPM para intltool (ferramentas de internacionalização)
name=intltool
version=0.51.0

# Tarball oficial do intltool
# Ajuste a URL se o mirror upstream mudar.
source="intltool-{version}.tar.gz::https://launchpad.net/intltool/trunk/0.51.0/+download/intltool-{version}.tar.gz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
sha256="-"

# intltool depende de Perl e do módulo XML::Parser
deps=(glibc perl xml-parser)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:intltool] Configurando intltool-${version}..."
  "$srcdir/configure" \
    --prefix=/usr

  echo "[spm:intltool] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  if [[ "${INTLTOOL_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:intltool] Executando 'make check'..."
    make check || echo "[spm:intltool][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:intltool] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  echo "[spm:intltool] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do intltool.
  :
}
