name=xfconf
version=4.20.0

source="\
  xfconf-{version}.tar.bz2::https://archive.xfce.org/src/xfce/xfconf/4.20/xfconf-{version}.tar.bz2 \
"

sha256="\
  <sha256-xfconf-{version}.tar.bz2> \
"

# Sistema de configuração do Xfce (backend via D-Bus).
deps=(glibc glib2 dbus libxfce4util)

build() {
  set -euo pipefail

  if [[ -d xfconf-${version} ]]; then
    cd xfconf-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libxfconf*.la' -delete 2>/dev/null || true
}

post_install() {
  :
}
