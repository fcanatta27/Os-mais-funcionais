name=libconfuse
version=3.3

source="\
  confuse-{version}.tar.xz::https://github.com/libconfuse/libconfuse/releases/download/v{version}/confuse-{version}.tar.xz \
"

sha256="\
  <sha256-confuse-{version}.tar.xz> \
"

# Biblioteca de parsing de arquivos de configuração, usada por i3status.
deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d confuse-${version} ]]; then
    cd confuse-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
