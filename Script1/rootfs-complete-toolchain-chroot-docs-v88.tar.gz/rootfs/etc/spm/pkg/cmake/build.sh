name=cmake
version=4.1.0

source="cmake-{version}.tar.gz::https://github.com/Kitware/CMake/releases/download/v{version}/cmake-{version}.tar.gz"
sha256="<sha256-cmake-4.1.0>"

deps=(glibc openssl libuv curl zlib)

build() {
  set -euo pipefail
  cd cmake-${version}

  ./bootstrap \
    --prefix=/usr \
    --system-libs \
    --no-qt-gui

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
