name=alsa
version=meta-1

source=""
sha256=""

# Meta-pacote ALSA: puxa biblioteca e ferramentas.
deps=(alsa-lib alsa-utils)

build() {
  set -euo pipefail
  echo "alsa é um meta-pacote; nenhuma build necessária."
}

post_install() {
  :
}
