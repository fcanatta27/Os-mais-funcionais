name=pkgconf
version=2.5.1

source="pkgconf-{version}.tar.xz::https://distfiles.dereferenced.org/pkgconf/pkgconf-{version}.tar.xz"
sha256="-"

deps=(glibc)

build() {
  set -euo pipefail
  : "${DESTDIR:?}" "${TMP:?}"

  local src="$PWD"
  local build="$TMP/${name}-${version}-build"
  rm -rf "$build"
  mkdir -p "$build"
  cd "$build"

  "$src/configure" \
    --prefix=/usr \
    --disable-static \
    --with-pkg-config-dir=/usr/lib/pkgconfig:/usr/share/pkgconfig

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"

  ln -sf pkgconf "$DESTDIR/usr/bin/pkg-config"
}

post_install() { :; }
