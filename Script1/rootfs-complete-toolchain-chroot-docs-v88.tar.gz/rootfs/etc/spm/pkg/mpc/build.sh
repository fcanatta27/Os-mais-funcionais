name=mpc
version=1.3.1
source="mpc-{version}.tar.gz::https://ftp.gnu.org/gnu/mpc/mpc-{version}.tar.gz"
sha256="-"
deps=(glibc gmp mpfr)

build() {
  set -euo pipefail
  : "${DESTDIR:?}" ; : "${TMP:?}"

  local src="$PWD"
  local b="$TMP/mpc-${version}-build"
  rm -rf "$b"; mkdir -p "$b"; cd "$b"

  "$src/configure" --prefix=/usr --disable-static
  make -j"${JOBS:-1}"

  if [[ "${MPC_RUN_TESTS:-0}" = 1 ]]; then
    make check || echo "[mpc] WARN: test failures"
  fi

  make install DESTDIR="$DESTDIR"
}
post_install(){ :; }
