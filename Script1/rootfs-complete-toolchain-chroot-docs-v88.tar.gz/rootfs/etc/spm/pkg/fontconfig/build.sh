name=fontconfig
version=2.15.0

source="\
  fontconfig-{version}.tar.xz::https://www.freedesktop.org/software/fontconfig/release/fontconfig-{version}.tar.xz \
"

sha256="\
  <sha256-fontconfig-{version}.tar.xz> \
"

deps=(glibc freetype expat)

build() {
  set -euo pipefail

  if [[ -d fontconfig-${version} ]]; then
    cd fontconfig-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  fc-cache -f 2>/dev/null || true
}

post_install() {
  fc-cache -f 2>/dev/null || true
}
