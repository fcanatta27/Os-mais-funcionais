    name=markupsafe
    version=3.0.2

    source="\
  MarkupSafe-{version}.tar.gz::https://files.pythonhosted.org/packages/source/M/MarkupSafe/MarkupSafe-{version}.tar.gz \
"


    sha256="\
  <sha256-MarkupSafe-{version}.tar.gz> \
"


    deps=(python)

    build() {
      set -euo pipefail

      # Tarball do PyPI normalmente extrai para MarkupSafe-{version}
      if [[ -d MarkupSafe-${version} && ! -f pyproject.toml && ! -f setup.py ]]; then
        cd MarkupSafe-${version}
      elif [[ -d MarkupSafe-${version} ]]; then
        cd MarkupSafe-${version}
      fi

      PYTHON=${PYTHON:-python3}

      "$PYTHON" -m pip install . \
        --root="$DESTDIR" \
        --prefix=/usr \
        --no-deps \
        --no-build-isolation
    }

    post_install() {
      if command -v python3 >/dev/null 2>&1; then
        python3 - << 'EOF' || true
try:
    import markupsafe
    print("[spm] MarkupSafe", markupsafe.__version__, "instalado.")
except Exception as e:
    print("[spm] aviso: não foi possível importar MarkupSafe:", e)
EOF
      fi
    }
