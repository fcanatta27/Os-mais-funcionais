name=polkit
version=126

source="  polkit-{version}.tar.xz::https://gitlab.freedesktop.org/polkit/polkit/-/archive/{version}/polkit-{version}.tar.xz "

sha256="  <sha256-polik-{version}.tar.xz> "

# Dependências principais (aproximadas): glibc, glib, Linux-PAM, systemd, expat
deps=(glibc glib linux-pam systemd expat)

build() {
  set -euo pipefail

  if [[ -d polkit-${version} && ! -f polkit-${version}/meson.build ]]; then
    cd polkit-${version}
  elif [[ -d polkit-${version} ]]; then
    cd polkit-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --buildtype=release \
    -Dsession_tracking=systemd \
    -Dauthfw=pam \
    -Dman=true

  meson compile -C build -j"${JOBS:-1}"

  DESTDIR="${DESTDIR}" meson install -C build

  # Garante diretório de regras
  mkdir -p "${DESTDIR}/etc/polkit-1/rules.d"
}

post_install() {
  # polkitd é ativado via D-Bus em geral; apenas verificamos se o binário existe.
  if command -v pkaction >/dev/null 2>&1; then
    pkaction --version 2>/dev/null || true
  fi
}
