name=fuse3
version=3.17.4

source="  fuse-{version}.tar.xz::https://github.com/libfuse/libfuse/releases/download/fuse-{version}/fuse-{version}.tar.xz "

sha256="  <sha256-fuse-{version}.tar.xz> "

deps=(glibc util-linux meson ninja)

build() {
  set -euo pipefail
  cd fuse-${version}

  meson setup build     --prefix=/usr     --buildtype=release     -Duseroot=false

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build

  # Configuração padrão
  mkdir -p "${DESTDIR}/etc"
  if [[ ! -f "${DESTDIR}/etc/fuse.conf" ]]; then
    echo "user_allow_other" > "${DESTDIR}/etc/fuse.conf"
  fi
}
