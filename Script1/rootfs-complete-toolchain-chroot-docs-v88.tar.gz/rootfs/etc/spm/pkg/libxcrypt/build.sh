# Definição de pacote SPM para libxcrypt (implementação moderna de crypt(3))
name=libxcrypt
version=4.5.2

# Tarball oficial do libxcrypt
source="libxcrypt-{version}.tar.xz::https://github.com/besser82/libxcrypt/releases/download/v{version}/libxcrypt-{version}.tar.xz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' enquanto não tiver o hash real.
sha256="-"

deps=(glibc)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:libxcrypt] Configurando libxcrypt-${version}..."
  "$srcdir/configure" \
    --prefix=/usr \
    --disable-static \
    --enable-hashes=strong,glibc \
    --enable-obsolete-api=glibc

  echo "[spm:libxcrypt] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  # Testes opcionais
  if [[ "${LIBXCRYPT_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:libxcrypt] Executando 'make check'..."
    make check || echo "[spm:libxcrypt][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:libxcrypt] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  echo "[spm:libxcrypt] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do libxcrypt.
  :
}
