name=gdb
version=16.3

source="  gdb-{version}.tar.xz::https://ftp.gnu.org/gnu/gdb/gdb-{version}.tar.xz "

sha256="  <sha256-gdb-{version}.tar.xz> "

deps=(glibc expat ncurses python)

build() {
  set -euo pipefail
  cd gdb-${version}

  ./configure     --prefix=/usr     --with-python=/usr/bin/python3     --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
