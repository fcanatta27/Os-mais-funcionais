
name=qemu
version=9.0.2

source="qemu-{version}.tar.xz::https://download.qemu.org/qemu-{version}.tar.xz"
sha256="<sha256-qemu-{version}.tar.xz>"

# QEMU - emulador/virtualizador.
# Configurado para alvo principal x86_64-softmmu com KVM e saída em modo texto/VNC,
# evitando dependências gráficas pesadas (SDL/GTK/OpenGL).
deps=(glibc zlib pixman alsa-lib)

build() {
  set -euo pipefail
  : "${DESTDIR:?}" "${TMP:?}"

  local src="$PWD"
  local b="${TMP}/${name}-${version}-build"
  rm -rf "${b}"
  mkdir -p "${b}"
  cd "${b}"

  "${src}/configure" \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --libexecdir=/usr/lib/qemu \
    --target-list=x86_64-softmmu \
    --enable-kvm \
    --enable-virtfs \
    --audio-drv-list=alsa \
    --enable-vnc \
    --disable-sdl \
    --disable-gtk \
    --disable-opengl \
    --disable-debug-info \
    --disable-werror

  make -j"${JOBS:-1}"

  if [[ "${QEMU_RUN_TESTS:-0}" == 1 ]]; then
    # Testes podem ser bem pesados; deixe opcional.
    make check || true
  fi

  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
