name=vim
version=9.1.1629

source="\
  vim-{version}.tar.gz::https://github.com/vim/vim/archive/refs/tags/v{version}.tar.gz \
"


sha256="\
  <sha256-vim-{version}.tar.gz> \
"


# Dependências básicas: glibc, ncurses. Python3 é opcional, mas aqui ativamos suporte.
deps=(glibc ncurses python)

build() {
  set -euo pipefail

  # O tarball do GitHub normalmente extrai para vim-${version}
  if [[ -d vim-${version} && ! -x ./configure ]]; then
    cd vim-${version}
  fi

  # Garante que o diretório runtime exista
  mkdir -p "$DESTDIR/usr/share/vim"

  ./configure \
    --prefix=/usr \
    --with-features=huge \
    --enable-multibyte \
    --enable-terminal \
    --enable-python3interp=yes \
    --with-tlib=ncursesw \
    --enable-gui=no \
    --without-x

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"

  # Instala documentação em um diretório versionado
  if [[ -d runtime/doc ]]; then
    mkdir -p "$DESTDIR/usr/share/doc/vim-${version}"
    cp -v runtime/doc/* "$DESTDIR/usr/share/doc/vim-${version}" 2>/dev/null || true
  fi

  # Symlink padrão 'vi' apontando para 'vim'
  if [[ -x "$DESTDIR/usr/bin/vim" && ! -e "$DESTDIR/usr/bin/vi" ]]; then
    ln -sv vim "$DESTDIR/usr/bin/vi"
  fi
}

post_install() {
  if command -v vim >/dev/null 2>&1; then
    vim --version | head -n1 || true
  fi
}
