name=libXcomposite
version=0.4.6

source="\
  libXcomposite-{version}.tar.xz::https://www.x.org/releases/individual/lib/libXcomposite-{version}.tar.xz \
"

sha256="\
  <sha256-libXcomposite-{version}.tar.xz> \
"

deps=(glibc libX11 xorgproto)

build() {
  set -euo pipefail

  if [[ -d libXcomposite-${version} ]]; then
    cd libXcomposite-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
