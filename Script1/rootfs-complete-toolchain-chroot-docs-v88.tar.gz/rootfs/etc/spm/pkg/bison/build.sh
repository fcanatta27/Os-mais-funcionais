# Definição de pacote SPM para bison (parser generator)
name=bison
version=3.8.2

# Tarball oficial do bison
source="bison-{version}.tar.xz::https://ftp.gnu.org/gnu/bison/bison-{version}.tar.xz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' enquanto não tiver o hash real.
sha256="-"

# bison depende de m4 para macro expansion e de glibc
deps=(glibc m4)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:bison] Configurando bison-${version}..."
  "$srcdir/configure" \
    --prefix=/usr \
    --sysconfdir=/etc \
    --disable-static \
    --docdir=/usr/share/doc/bison-${version}

  echo "[spm:bison] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  if [[ "${BISON_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:bison] Executando 'make check' (pode ser demorado)..."
    make check || echo "[spm:bison][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:bison] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  echo "[spm:bison] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do bison.
  :
}
