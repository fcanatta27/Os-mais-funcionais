name=libpng
version=1.6.44

source="\
  libpng-{version}.tar.xz::https://download.sourceforge.net/libpng/libpng-{version}.tar.xz \
"

sha256="\
  <sha256-libpng-{version}.tar.xz> \
"

deps=(glibc zlib)

build() {
  set -euo pipefail

  if [[ -d libpng-${version} ]]; then
    cd libpng-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libpng*.la' -delete 2>/dev/null || true
}

post_install() {
  :
}
