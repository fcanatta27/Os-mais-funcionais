name=xcb-util
version=0.4.1

source="\
  xcb-util-{version}.tar.xz::https://xcb.freedesktop.org/dist/xcb-util-{version}.tar.xz \
"

sha256="\
  <sha256-xcb-util-{version}.tar.xz> \
"

deps=(glibc libxcb)

build() {
  set -euo pipefail

  if [[ -d xcb-util-${version} && ! -x ./configure ]]; then
    cd xcb-util-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  # Remover .la se existirem
  find "${DESTDIR}/usr/lib" -name 'libxcb-util*.la' -delete 2>/dev/null || true
}

post_install() {
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --modversion xcb-util 2>/dev/null || true
  fi
}
