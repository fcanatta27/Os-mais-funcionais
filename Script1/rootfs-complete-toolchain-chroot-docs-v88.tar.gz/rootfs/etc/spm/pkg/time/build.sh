name=time
version=1.9

source="  time-{version}.tar.gz::https://ftp.gnu.org/gnu/time/time-{version}.tar.gz "

sha256="  <sha256-time-{version}.tar.gz> "

deps=(glibc)

build() {
  set -euo pipefail

  if [[ -d time-${version} && ! -x ./configure ]]; then
    cd time-${version}
  fi

  ./configure \
    --prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  if command -v time >/dev/null 2>&1; then
    time --version || true
  fi
}
