name=mesa
version=25.3.1

source="\
  mesa-{version}.tar.xz::https://archive.mesa3d.org/mesa-{version}.tar.xz \
"

sha256="\
  <sha256-mesa-{version}.tar.xz> \
"

# Dependências principais (ajuste conforme for empacotando mais libs):
#  - llvm: suporte a drivers Gallium otimizados
#  - zlib, expat: libs básicas já empacotadas
#  - libdrm: interface DRM com kernel (crie build.sh separado)
#  - xorgproto, libX11, libxcb, libXext, libXdamage, libXfixes, etc.
deps=(glibc llvm zlib expat libdrm xorgproto libX11 libxcb libXdamage libXfixes)

build() {
  set -euo pipefail

  if [[ -d mesa-${version} ]]; then
    cd mesa-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dplatforms=x11 \
    -Dglx=dri \
    -Ddri-drivers=i965 \
    -Dgallium-drivers=r300,r600,svga,nouveau,virgl,iris,zink \
    -Dvulkan-drivers= \
    -Dshared-glapi=true \
    -Dllvm=true \
    -Dgbm=true \
    -Degl=true \
    -Dgles1=false \
    -Dgles2=true \
    -Dopengl=true \
    -Dosmesa=true \
    -Dvalgrind=false

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build

  # Remove .la se houver
  find "${DESTDIR}/usr/lib" -name 'libGL*.la' -delete 2>/dev/null || true
}

post_install() {
  # Verifica que libGL.so foi instalada
  ls /usr/lib/libGL.* 2>/dev/null || true
}
