name=autofs
version=5.1.9

source="  autofs-{version}.tar.xz::https://www.kernel.org/pub/linux/daemons/autofs/v5/autofs-{version}.tar.xz "

sha256="  <sha256-autofs-{version}.tar.xz> "

deps=(glibc systemd libxml2)

build() {
  set -euo pipefail
  cd autofs-${version}
  ./configure --prefix=/usr --sysconfdir=/etc
  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
