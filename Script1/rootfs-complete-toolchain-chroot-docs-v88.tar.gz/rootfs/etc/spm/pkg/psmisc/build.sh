# Definição de pacote SPM para psmisc (conjunto de utilitários para processos)
name=psmisc
version=23.7

# Tarball oficial do psmisc
source="psmisc-{version}.tar.xz::https://sourceforge.net/projects/psmisc/files/psmisc/{version}/psmisc-{version}.tar.xz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' enquanto não tiver o hash real.
sha256="-"

deps=(glibc)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:psmisc] Configurando psmisc-${version}..."
  "$srcdir/configure" \
    --prefix=/usr \
    --sysconfdir=/etc \
    --disable-static

  echo "[spm:psmisc] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  if [[ "${PSMISC_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:psmisc] Executando 'make check'..."
    make check || echo "[spm:psmisc][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:psmisc] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  echo "[spm:psmisc] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do psmisc.
  :
}
