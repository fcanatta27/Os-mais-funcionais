name=meson
version=1.8.3

source="\
  meson-{version}.tar.gz::https://github.com/mesonbuild/meson/archive/refs/tags/{version}.tar.gz \
"

sha256="\
  <sha256-meson-{version}.tar.gz> \
"

deps=(python ninja)

build() {
  set -euo pipefail

  cd "meson-${version}"

  PYTHON=${PYTHON:-python3}

  # Instalação via pip no prefixo /usr, sem deps (spm cuida) e sem build isolation
  "$PYTHON" -m pip install . \
    --root="$DESTDIR" \
    --prefix=/usr \
    --no-deps \
    --no-build-isolation

  # Garante que o script meson esteja em /usr/bin (pip já deve cuidar disso,
  # mas em algumas situações pode cair em /usr/local/bin dentro do DESTDIR)
  if [[ -d "$DESTDIR/usr/local/bin" ]]; then
    mkdir -p "$DESTDIR/usr/bin"
    for f in "$DESTDIR/usr/local/bin/"*; do
      [[ -f "$f" && -x "$f" ]] || continue
      mv "$f" "$DESTDIR/usr/bin/"
    done
    rmdir "$DESTDIR/usr/local/bin" 2>/dev/null || true
    rmdir "$DESTDIR/usr/local" 2>/dev/null || true
  fi
}

post_install() {
  if command -v meson >/dev/null 2>&1; then
    meson --version || true
  fi
}
