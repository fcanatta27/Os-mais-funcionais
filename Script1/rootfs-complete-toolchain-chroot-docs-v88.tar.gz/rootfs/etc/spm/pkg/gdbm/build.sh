name=gdbm
version=1.26
source="gdbm-{version}.tar.gz::https://ftp.gnu.org/gnu/gdbm/gdbm-{version}.tar.gz"
sha256="-"
deps=(glibc readline)

build() {
  set -euo pipefail
  : "${DESTDIR:?}" "${TMP:?}"
  local src="$PWD"
  local b="$TMP/${name}-${version}-build"
  rm -rf "$b"; mkdir -p "$b"; cd "$b"

  "$src/configure" \
    --prefix=/usr \
    --disable-static \
    --enable-libgdbm-compat

  make -j"${JOBS:-1}"
  [[ "${GDBM_RUN_TESTS:-0}" == 1 ]] && make check || true
  make install DESTDIR="$DESTDIR"
}
