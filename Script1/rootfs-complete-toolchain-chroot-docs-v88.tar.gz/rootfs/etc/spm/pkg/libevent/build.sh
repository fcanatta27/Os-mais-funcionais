name=libevent
version=2.1.12

source="\
  libevent-{version}-stable.tar.gz::https://github.com/libevent/libevent/releases/download/release-{version}-stable/libevent-{version}-stable.tar.gz \
"

sha256="\
  <sha256-libevent-{version}-stable.tar.gz> \
"

deps=(glibc)

build() {
  set -euo pipefail

  srcdir="libevent-${version}-stable"
  [ -d "$srcdir" ] && cd "$srcdir"

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
