name=libXrender
version=0.9.11

source="\
  libXrender-{version}.tar.xz::https://www.x.org/releases/individual/lib/libXrender-{version}.tar.xz \
"

sha256="\
  <sha256-libXrender-{version}.tar.xz> \
"

deps=(glibc libX11 xorgproto)

build() {
  set -euo pipefail

  if [[ -d libXrender-${version} ]]; then
    cd libXrender-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
