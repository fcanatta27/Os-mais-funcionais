name=xfwm4
version=4.20.0

source="\
  xfwm4-{version}.tar.bz2::https://archive.xfce.org/src/xfce/xfwm4/4.20/xfwm4-{version}.tar.bz2 \
"

sha256="\
  <sha256-xfwm4-{version}.tar.bz2> \
"

# Window manager do Xfce (compositor).
deps=(glibc glib2 gtk3 libxfce4ui libxfce4util libX11 libXinerama libXcomposite libXdamage libXrandr)

build() {
  set -euo pipefail

  if [[ -d xfwm4-${version} ]]; then
    cd xfwm4-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static \
    --enable-compositor

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
