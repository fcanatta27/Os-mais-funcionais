name=xrdb
version=1.2.2

source="\
  xrdb-{version}.tar.xz::https://www.x.org/releases/individual/app/xrdb-{version}.tar.xz \
"

sha256="\
  <sha256-xrdb-{version}.tar.xz> \
"

deps=(glibc libX11 xorgproto)

build() {
  set -euo pipefail

  if [[ -d xrdb-${version} ]]; then
    cd xrdb-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  command -v xrdb >/dev/null 2>&1 || true
}
