name=usbutils
version=018

source="usbutils-{version}.tar.xz::https://www.kernel.org/pub/linux/utils/usb/usbutils/usbutils-{version}.tar.xz"
sha256="<sha256-usbutils-018>"

deps=(glibc libusb hwdata)

build() {
  set -euo pipefail
  cd usbutils-${version}

  ./configure \
    --prefix=/usr \
    --datadir=/usr/share \
    --with-usbids-dir=/usr/share/hwdata

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
