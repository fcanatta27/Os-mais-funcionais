# Definição de pacote SPM para less (pager de texto)
name=less
version=679

# Tarball oficial do less
source="less-{version}.tar.gz::https://www.greenwoodsoftware.com/less/less-{version}.tar.gz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
sha256="-"

# less depende de glibc e de ncurses para manipulação de terminal
deps=(glibc ncurses)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:less] Configurando less-${version}..."
  "$srcdir/configure" \
    --prefix=/usr \
    --sysconfdir=/etc

  echo "[spm:less] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  if [[ "${LESS_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:less] (Não há uma suíte de testes extensa padrão; pulando.)"
  fi

  echo "[spm:less] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  echo "[spm:less] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do less.
  :
}
