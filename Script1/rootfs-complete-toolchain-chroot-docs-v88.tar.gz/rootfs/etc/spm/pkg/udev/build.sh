name=udev
version=virtual-1

source=""

sha256=""

# Meta-package: o udev é fornecido pelo systemd.
deps=(systemd)

build() {
  set -euo pipefail
  echo "udev é parte do systemd; nenhum build necessário."
}

post_install() {
  :
}
