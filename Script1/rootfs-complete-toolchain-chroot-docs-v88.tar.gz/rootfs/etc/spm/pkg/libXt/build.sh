name=libXt
version=1.3.0

source="\
  libXt-{version}.tar.xz::https://www.x.org/releases/individual/lib/libXt-{version}.tar.xz \
"

sha256="\
  <sha256-libXt-{version}.tar.xz> \
"

# Toolkit X11: base para toolkits mais antigos e libs como Xmu.
deps=(glibc libX11 xorgproto libSM libICE)

build() {
  set -euo pipefail

  if [[ -d libXt-${version} ]]; then
    cd libXt-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libXt*.la' -delete 2>/dev/null || true
}

post_install() {
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --modversion xt 2>/dev/null || true
  fi
}
