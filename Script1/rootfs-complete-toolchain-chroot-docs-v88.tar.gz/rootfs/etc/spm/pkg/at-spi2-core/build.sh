name=at-spi2-core
version=2.52.0

source="\
  at-spi2-core-{version}.tar.xz::https://download.gnome.org/sources/at-spi2-core/2.52/at-spi2-core-{version}.tar.xz \
"

sha256="\
  <sha256-at-spi2-core-{version}.tar.xz> \
"

# Infraestrutura de acessibilidade de baixo nível (bus de eventos AT-SPI).
deps=(glib2 dbus glibc)

build() {
  set -euo pipefail

  if [[ -d at-spi2-core-${version} ]]; then
    cd at-spi2-core-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dintrospection=disabled \
    -Ddocs=false \
    -Dtests=false

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  :
}
