name=xfce4-indicator-plugin
version=2.4.3

source="\
  xfce4-indicator-plugin-{version}.tar.bz2::https://archive.xfce.org/src/panel-plugins/xfce4-indicator-plugin/2.4/xfce4-indicator-plugin-{version}.tar.bz2 \
"

sha256="\
  <sha256-xfce4-indicator-plugin-{version}.tar.bz2> \
"

# Plugin de indicadores (systray avançado) para o xfce4-panel.
# Compilado de forma a depender apenas do painel e do stack Gtk3.
deps=(glibc glib2 gtk3 xfce4-panel libxfce4ui libxfce4util)

build() {
  set -euo pipefail

  if [[ -d xfce4-indicator-plugin-${version} ]]; then
    cd xfce4-indicator-plugin-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
