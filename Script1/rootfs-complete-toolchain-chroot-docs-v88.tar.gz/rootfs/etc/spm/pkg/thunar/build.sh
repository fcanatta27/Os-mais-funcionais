name=thunar
version=4.20.0

source="\
  thunar-{version}.tar.bz2::https://archive.xfce.org/src/xfce/thunar/4.20/thunar-{version}.tar.bz2 \
"

sha256="\
  <sha256-thunar-{version}.tar.bz2> \
"

# Gerenciador de arquivos do Xfce.
deps=(glibc glib2 gtk3 exo libxfce4ui libxfce4util)

build() {
  set -euo pipefail

  if [[ -d thunar-${version} ]]; then
    cd thunar-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
