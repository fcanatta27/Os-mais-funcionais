name=i3blocks
version=1.5

source="\
  i3blocks-{version}.tar.gz::https://github.com/vivien/i3blocks/archive/refs/tags/{version}.tar.gz \
"

sha256="\
  <sha256-i3blocks-{version}.tar.gz> \
"

# Status bar altamente configurável para i3.
deps=(glibc pkgconf pango cairo)

build() {
  set -euo pipefail

  if [[ -d i3blocks-${version} ]]; then
    cd i3blocks-${version}
  fi

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}" PREFIX=/usr
}

post_install() {
  :
}
