name=i3status
version=2.15

source="\
  i3status-{version}.tar.xz::https://i3wm.org/i3status/i3status-{version}.tar.xz \
"

sha256="\
  <sha256-i3status-{version}.tar.xz> \
"

# Barra de status para i3wm.
deps=(glibc libconfuse alsa-lib libyajl)

build() {
  set -euo pipefail

  if [[ -d i3status-${version} ]]; then
    cd i3status-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
