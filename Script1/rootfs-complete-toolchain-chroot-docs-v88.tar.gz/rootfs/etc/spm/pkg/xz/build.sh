# Definição de pacote SPM para xz (utilitários e biblioteca liblzma)
name=xz
version=5.8.1

# Tarball oficial do xz
source="xz-{version}.tar.xz::https://tukaani.org/xz/xz-{version}.tar.xz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Use '-' enquanto não tiver o hash real.
sha256="-"

# xz depende de glibc e toolchain básico
deps=(glibc)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  echo "[spm:xz] Configurando xz-${version}..."
  "$srcdir/configure" \
    --prefix=/usr \
    --sysconfdir=/etc \
    --disable-static \
    --docdir=/usr/share/doc/xz-${version}

  echo "[spm:xz] Compilando com ${JOBS:-1} jobs..."
  make -j"${JOBS:-1}"

  # Testes opcionais
  if [[ "${XZ_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:xz] Executando 'make check' (pode ser demorado)..."
    make check || echo "[spm:xz][WARN] Alguns testes falharam (veja logs)."
  fi

  echo "[spm:xz] Instalando em DESTDIR=${DESTDIR}..."
  make install DESTDIR="$DESTDIR"

  echo "[spm:xz] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional após instalação real do xz.
  :
}
