name=vala
version=0.56.18

source="  vala-{version}.tar.xz::https://download.gnome.org/sources/vala/0.56/vala-{version}.tar.xz "

sha256="  <sha256-vala-{version}.tar.xz> "

# Depende fortemente de glib e flex/bison
deps=(glibc glib flex bison)

build() {
  set -euo pipefail

  if [[ -d vala-${version} && ! -x ./configure ]]; then
    cd vala-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  if command -v valac >/dev/null 2>&1; then
    valac --version || true
  fi
}
