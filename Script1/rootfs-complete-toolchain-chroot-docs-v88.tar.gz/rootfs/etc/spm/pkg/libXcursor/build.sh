name=libXcursor
version=1.2.3

source="\
  libXcursor-{version}.tar.xz::https://www.x.org/releases/individual/lib/libXcursor-{version}.tar.xz \
"

sha256="\
  <sha256-libXcursor-{version}.tar.xz> \
"

deps=(glibc libX11 libXfixes xorgproto)

build() {
  set -euo pipefail

  if [[ -d libXcursor-${version} ]]; then
    cd libXcursor-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
