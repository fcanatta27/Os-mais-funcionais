name=libpsl
version=0.21.5

source="\
  libpsl-{version}.tar.gz::https://github.com/rockdaboot/libpsl/releases/download/{version}/libpsl-{version}.tar.gz \
"

sha256="\
  <sha256-libpsl-{version}.tar.gz> \
"

# Biblioteca de Public Suffix List usada por libsoup/curl.
deps=(glibc libidn2)

build() {
  set -euo pipefail

  if [[ -d libpsl-${version} ]]; then
    cd libpsl-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
