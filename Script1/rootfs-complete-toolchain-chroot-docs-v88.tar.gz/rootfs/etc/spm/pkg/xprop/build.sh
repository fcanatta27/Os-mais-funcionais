name=xprop
version=1.2.7

source="\
  xprop-{version}.tar.xz::https://www.x.org/releases/individual/app/xprop-{version}.tar.xz \
"

sha256="\
  <sha256-xprop-{version}.tar.xz> \
"

deps=(glibc libX11 xorgproto)

build() {
  set -euo pipefail

  if [[ -d xprop-${version} ]]; then
    cd xprop-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  command -v xprop >/dev/null 2>&1 || true
}
