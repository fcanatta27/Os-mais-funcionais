name=libjpeg
version=3.0.3

source="\
  libjpeg-turbo-{version}.tar.gz::https://downloads.sourceforge.net/libjpeg-turbo/libjpeg-turbo-{version}.tar.gz \
"

sha256="\
  <sha256-libjpeg-turbo-{version}.tar.gz> \
"

# Implementação rápida de JPEG (libjpeg-turbo) que fornece libjpeg.so
# para bibliotecas como tumbler e outras que usam JPEG.
deps=(glibc cmake)

build() {
  set -euo pipefail

  if [[ -d libjpeg-turbo-${version} ]]; then
    cd libjpeg-turbo-${version}
  fi

  rm -rf build
  mkdir -p build
  cd build

  cmake \
    -DCMAKE_INSTALL_PREFIX=/usr \
    -DCMAKE_BUILD_TYPE=Release \
    -DENABLE_SHARED=ON \
    -DENABLE_STATIC=OFF \
    -DWITH_JPEG8=ON \
    ..

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  if command -v jpegtran >/dev/null 2>&1; then
    jpegtran -version 2>/dev/null || true
  fi
}
