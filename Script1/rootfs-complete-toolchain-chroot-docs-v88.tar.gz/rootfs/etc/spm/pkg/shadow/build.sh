    # Definição de pacote SPM para shadow (ferramentas de contas de usuário)
    name=shadow
    version=4.18

    # Tarball oficial do shadow
    source="shadow-{version}.tar.xz::https://github.com/shadow-maint/shadow/releases/download/v{version}/shadow-{version}.tar.xz"

    # SHA256 correspondente ao(s) arquivo(s) em 'source'.
    # Use '-' enquanto não tiver o hash real.
    sha256="-"

    # shadow depende de glibc, libxcrypt e opcionalmente libacl/libattr/libcap.
    # Aqui declaramos as dependências principais.
    deps=(glibc libxcrypt acl libcap)

    build() {
      set -euo pipefail

      : "${DESTDIR:?DESTDIR não definido}"
      : "${TMP:?TMP não definido}"

      local srcdir="$PWD"
      local builddir="$TMP/${name}-${version}-build"
      rm -rf "$builddir"
      mkdir -p "$builddir"
      cd "$builddir"

      echo "[spm:shadow] Configurando shadow-${version}..."

      # Desabilitamos PAM para manter a configuração simples, baseada em /etc/shadow.
      # Ajuste se futuramente você adicionar um pacote PAM.
      "$srcdir/configure" \
        --prefix=/usr \
        --sysconfdir=/etc \
        --with-{acl,attr,libcrack=no} \
        --without-libpam \
        --with-libxcrypt-prefix=/usr

      echo "[spm:shadow] Compilando com ${JOBS:-1} jobs..."
      make -j"${JOBS:-1}"

      echo "[spm:shadow] Instalando em DESTDIR=${DESTDIR}..."
      make install DESTDIR="$DESTDIR"

      # Criar arquivos básicos de configuração se ainda não existirem em DESTDIR
      mkdir -p "$DESTDIR/etc"

      if [[ ! -f "$DESTDIR/etc/login.defs" ]]; then
        echo "[spm:shadow] Criando /etc/login.defs padrão..."
        cat >"$DESTDIR/etc/login.defs" <<'EOF'
# /etc/login.defs - configuração base para utilitários shadow

MAIL_DIR        /var/mail
PASS_MAX_DAYS   99999
PASS_MIN_DAYS   0
PASS_WARN_AGE   7

UID_MIN         1000
UID_MAX         60000
GID_MIN         1000
GID_MAX         60000

CREATE_HOME     yes
UMASK           077
ENCRYPT_METHOD  SHA512
SHA_CRYPT_MIN_ROUNDS 5000
SHA_CRYPT_MAX_ROUNDS 5000
EOF
      fi

      if [[ ! -f "$DESTDIR/etc/default/useradd" ]]; then
        echo "[spm:shadow] Criando /etc/default/useradd padrão..."
        mkdir -p "$DESTDIR/etc/default"
        cat >"$DESTDIR/etc/default/useradd" <<'EOF'
GROUP=100
HOME=/home
INACTIVE=-1
EXPIRE=
SHELL=/bin/bash
SKEL=/etc/skel
CREATE_MAIL_SPOOL=yes
EOF
      fi

      # Diretório /etc/skel padrão
      if [[ ! -d "$DESTDIR/etc/skel" ]]; then
        mkdir -p "$DESTDIR/etc/skel"
        touch "$DESTDIR/etc/skel/.bash_profile"               "$DESTDIR/etc/skel/.bashrc"               "$DESTDIR/etc/skel/.bash_logout"
      fi

      echo "[spm:shadow] Build e instalação em staging concluídos."
    }

    post_install() {
      # Hook opcional após instalação real do shadow.
      # Aqui, em um sistema real, você poderia ajustar permissões de /etc/{passwd,shadow,group,gshadow}
      # ou criar usuários iniciais.
      :
    }
