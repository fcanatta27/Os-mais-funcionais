name=xset
version=1.2.5

source="\
  xset-{version}.tar.xz::https://www.x.org/releases/individual/app/xset-{version}.tar.xz \
"

sha256="\
  <sha256-xset-{version}.tar.xz> \
"

deps=(glibc libX11 xorgproto)

build() {
  set -euo pipefail

  if [[ -d xset-${version} ]]; then
    cd xset-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  command -v xset >/dev/null 2>&1 || true
}
