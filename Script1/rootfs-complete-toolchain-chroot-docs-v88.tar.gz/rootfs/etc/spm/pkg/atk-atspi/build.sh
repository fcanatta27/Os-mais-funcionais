name=atk-atspi
version=virtual-1

source=""
sha256=""

# Meta-package: satisfaz dependências que referem 'atk-atspi'.
# Implementado via at-spi2-core + at-spi2-atk.
deps=(at-spi2-core at-spi2-atk)

build() {
  set -euo pipefail
  echo "atk-atspi é um pacote virtual; nenhum build necessário."
}

post_install() {
  :
}
