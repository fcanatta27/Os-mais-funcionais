name=libX11
version=1.8.10

source="\
  libX11-{version}.tar.xz::https://www.x.org/releases/individual/lib/libX11-{version}.tar.xz \
"

sha256="\
  <sha256-libX11-{version}.tar.xz> \
"

deps=(glibc xorgproto)

build() {
  set -euo pipefail

  if [[ -d libX11-${version} ]]; then
    cd libX11-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"

  find "${DESTDIR}/usr/lib" -name 'libX11*.la' -delete 2>/dev/null || true
}

post_install() {
  :
}
