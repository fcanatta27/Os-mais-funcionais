name=i3
version=4.23

source="\
  i3-{version}.tar.xz::https://i3wm.org/downloads/i3-{version}.tar.xz \
"

sha256="\
  <sha256-i3-{version}.tar.xz> \
"

# Window manager em mosaico i3.
deps=(glibc libxcb xcb-util xcb-util-wm xcb-util-keysyms pango cairo libxkbcommon libX11 libXinerama libXrandr)

build() {
  set -euo pipefail

  if [[ -d i3-${version} ]]; then
    cd i3-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --buildtype=release

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  :
}
