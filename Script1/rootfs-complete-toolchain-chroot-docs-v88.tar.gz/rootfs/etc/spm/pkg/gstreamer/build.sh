name=gstreamer
version=1.24.9

source="\
  gstreamer-{version}.tar.xz::https://gstreamer.freedesktop.org/src/gstreamer/gstreamer-{version}.tar.xz \
"

sha256="\
  <sha256-gstreamer-{version}.tar.xz> \
"

# Núcleo do GStreamer (pipeline multimídia).
deps=(glibc glib2)

build() {
  set -euo pipefail

  if [[ -d gstreamer-${version} ]]; then
    cd gstreamer-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dorc=disabled \
    -Dtests=disabled \
    -Dexamples=disabled \
    -Dtools=enabled

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  :
}
