name=picom
version=11.2

source="\
  picom-{version}.tar.gz::https://github.com/yshui/picom/archive/refs/tags/v{version}.tar.gz \
"

sha256="\
  <sha256-picom-{version}.tar.gz> \
"

# Compositor X11 leve, upstream.
deps=(glibc pixman libX11 libXcomposite libXdamage libXext libXrender libXrandr libconfig libxcb xcb-util xorgproto)

build() {
  set -euo pipefail

  # Detecta diretório extraído de forma robusta
  if [[ -d picom-${version} ]]; then
    cd picom-${version}
  else
    srcdir="$(find . -maxdepth 1 -type d -name 'picom-*' | head -n1)"
    [ -n "$srcdir" ] && cd "$srcdir"
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --buildtype=release \
    -Dwith_docs=false \
    -Dwith_xrender=true \
    -Dwith_xext=true

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  command -v picom >/dev/null 2>&1 || true
}
