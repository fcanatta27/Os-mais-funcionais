name=libssh2
version=1.11.0

source="\
  libssh2-{version}.tar.gz::https://www.libssh2.org/download/libssh2-{version}.tar.gz \
"

sha256="\
  <sha256-libssh2-{version}.tar.gz> \
"

deps=(glibc openssl zlib)

build() {
  set -euo pipefail

  if [[ -d libssh2-${version} ]]; then
    cd libssh2-${version}
  fi

  ./configure \
    --prefix=/usr \
    --disable-static \
    --with-openssl

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
