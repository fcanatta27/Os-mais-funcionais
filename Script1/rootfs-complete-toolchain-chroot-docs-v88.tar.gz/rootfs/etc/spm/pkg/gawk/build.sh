name=gawk
version=5.3.2

source="\
  gawk-{version}.tar.xz::https://ftp.gnu.org/gnu/gawk/gawk-{version}.tar.xz \
"

sha256="\
  <sha256-gawk-{version}.tar.xz> \
"

# gawk pode usar mpfr/gmp para operações de ponto flutuante avançadas
deps=(glibc gmp mpfr)

build() {
  set -euo pipefail

  if [[ -d gawk-${version} && ! -x ./configure ]]; then
    cd gawk-${version}
  fi

  ./configure \
    --prefix=/usr

  make -j"${JOBS:-1}"
  make install DESTDIR="$DESTDIR"

  # Instala documentação extra, se existir
  if [[ -d doc ]]; then
    mkdir -p "$DESTDIR/usr/share/doc/gawk-${version}"
    cp -v doc/*.txt doc/*.html 2>/dev/null || true
    cp -v doc/*.pdf "$DESTDIR/usr/share/doc/gawk-${version}" 2>/dev/null || true
  fi
}

post_install() {
  if command -v gawk >/dev/null 2>&1; then
    echo 'BEGIN { print "[spm] gawk OK" }' | gawk || true
  fi
}
