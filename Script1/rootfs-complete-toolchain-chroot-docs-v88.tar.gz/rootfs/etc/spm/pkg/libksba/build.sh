name=libksba
version=1.6.7

source="\
  libksba-{version}.tar.bz2::https://www.gnupg.org/ftp/gcrypt/libksba/libksba-{version}.tar.bz2 \
"

sha256="\
  <sha256-libksba-{version}.tar.bz2> \
"

deps=(glibc libgpg-error)

build() {
  set -euo pipefail
  cd libksba-${version}

  ./configure     --prefix=/usr     --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}
