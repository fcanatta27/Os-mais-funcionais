
name=gst-plugins-ugly
version=1.24.9

source="\
  gst-plugins-ugly-{version}.tar.xz::https://gstreamer.freedesktop.org/src/gst-plugins-ugly/gst-plugins-ugly-{version}.tar.xz \
"

sha256="\
  <sha256-gst-plugins-ugly-{version}.tar.xz> \
"

# Coleção "ugly" de plugins GStreamer (questões de patentes/licenças, mas tecnicamente úteis).
# Integramos principalmente com x264/x265/ffmpeg, que já existem no sistema.
deps=(glibc gstreamer gst-plugins-base glib2 orc x264 x265 ffmpeg)

build() {
  set -euo pipefail
  : "${DESTDIR:?}"

  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dexamples=disabled \
    -Dtests=disabled

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  :
}
