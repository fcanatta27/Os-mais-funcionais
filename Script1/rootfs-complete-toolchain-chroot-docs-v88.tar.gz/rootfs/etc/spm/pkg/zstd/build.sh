# Definição de pacote SPM para zstd (compressão Zstandard)
name=zstd
version=1.5.7

# Tarball oficial do zstd
source="zstd-{version}.tar.gz::https://github.com/facebook/zstd/releases/download/v{version}/zstd-{version}.tar.gz"

# SHA256 correspondente ao(s) arquivo(s) em 'source'.
# Preencha com o valor real quando desejar validação forte.
sha256="-"

# zstd requer libc e toolchain funcional
deps=(glibc)

build() {
  set -euo pipefail

  : "${DESTDIR:?DESTDIR não definido}"
  : "${TMP:?TMP não definido}"

  local srcdir="$PWD"
  local builddir="$TMP/${name}-${version}-build"
  rm -rf "$builddir"
  mkdir -p "$builddir"
  cd "$builddir"

  # O projeto zstd usa makefiles próprios; não usa autotools por padrão
  echo "[spm:zstd] Construindo biblioteca e utilitários zstd-${version}..."
  make -C "$srcdir" -j"${JOBS:-1}"

  # Testes opcionais
  if [[ "${ZSTD_RUN_TESTS:-0}" = "1" ]]; then
    echo "[spm:zstd] Executando 'make check'..."
    make -C "$srcdir" check || echo "[spm:zstd][WARN] Alguns testes falharam."
  fi

  echo "[spm:zstd] Instalando em DESTDIR=${DESTDIR} com PREFIX=/usr..."
  make -C "$srcdir" PREFIX=/usr DESTDIR="$DESTDIR" install

  echo "[spm:zstd] Build e instalação em staging concluídos."
}

post_install() {
  # Hook opcional (ex.: rodar ldconfig)
  :
}
