name=xfce4-terminal
version=1.1.3

source="\
  xfce4-terminal-{version}.tar.bz2::https://archive.xfce.org/src/apps/xfce4-terminal/1.1/xfce4-terminal-{version}.tar.bz2 \
"

sha256="\
  <sha256-xfce4-terminal-{version}.tar.bz2> \
"

# Terminal do Xfce.
deps=(glibc glib2 gtk3 vte3 libxfce4ui libxfce4util)

build() {
  set -euo pipefail

  if [[ -d xfce4-terminal-${version} ]]; then
    cd xfce4-terminal-${version}
  fi

  ./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

  make -j"${JOBS:-1}"
  make install DESTDIR="${DESTDIR}"
}

post_install() {
  :
}
