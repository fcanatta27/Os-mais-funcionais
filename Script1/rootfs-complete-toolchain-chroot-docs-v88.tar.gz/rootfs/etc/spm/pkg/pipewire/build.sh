name=pipewire
version=1.2.0

source="\
  pipewire-{version}.tar.bz2::https://gitlab.freedesktop.org/pipewire/pipewire/-/archive/{version}/pipewire-{version}.tar.bz2 \
"

sha256="\
  <sha256-pipewire-{version}.tar.bz2> \
"

# Servidor multimídia moderno (áudio/vídeo) substituindo PulseAudio/JACK.
# Aqui configurado de forma mínima, integrando com systemd e ALSA.
deps=(glibc glib2 systemd alsa-lib dbus libudev)

build() {
  set -euo pipefail

  if [[ -d pipewire-${version} ]]; then
    cd pipewire-${version}
  fi

  rm -rf build
  meson setup build \
    --prefix=/usr \
    --libdir=/usr/lib \
    --buildtype=release \
    -Dsession-managers= \
    -Dsystemd=enabled \
    -Ddbus=enabled \
    -Djack=disabled \
    -Dpipewire-jack=disabled \
    -Dlibpulse=disabled \
    -Dalsa=enabled

  meson compile -C build -j"${JOBS:-1}"
  DESTDIR="${DESTDIR}" meson install -C build
}

post_install() {
  :
}
