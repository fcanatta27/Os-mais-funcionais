# /etc/profile.d/fzf.sh - integra fzf se estiver instalado

if command -v fzf >/dev/null 2>&1; then
    # Histórico com Ctrl-R
    if [ -n "$BASH_VERSION" ]; then
        __fzf_history__() {
            local output
            output=$(builtin fc -ln 1 | fzf +s --tac --reverse --prompt='history> ' --bind='ctrl-r:toggle-sort') || return
            READLINE_LINE="$output"
            READLINE_POINT=${#READLINE_LINE}
        }
        bind -x '"\C-r": __fzf_history__'
    fi

    # Ctrl-T para escolher arquivo
    __fzf_file__() {
        local file
        file=$(fzf --height=40% --reverse --prompt='file> ') || return
        READLINE_LINE="$READLINE_LINE$file"
        READLINE_POINT=${#READLINE_LINE}
    }
    bind -x '"\C-t": __fzf_file__'

    # Alt-C para cd em diretório
    __fzf_cd__() {
        local dir
        dir=$(find . -mindepth 1 -type d 2>/dev/null | fzf --height=40% --reverse --prompt='cd> ') || return
        cd "$dir" || return
        ls
    }
    bind -x '"\ec": __fzf_cd__'
fi
