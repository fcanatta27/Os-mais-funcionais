# /etc/profile.d/git.sh - pequenas opções padrão para git

if command -v git >/dev/null 2>&1; then
    export GIT_PAGER=less
    export GIT_CONFIG_GLOBAL=/etc/gitconfig
fi
