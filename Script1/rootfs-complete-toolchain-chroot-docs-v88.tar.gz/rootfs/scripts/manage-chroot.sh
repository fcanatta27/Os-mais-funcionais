#!/usr/bin/env bash
    # manage-chroot.sh
    # Script para gerenciar o chroot do ROOTFS de forma segura e limpa.
    #
    # Funcionalidades:
    #   - Montar /dev, /dev/pts, /proc, /sys e /run dentro do ROOTFS
    #   - Entrar em um shell interativo dentro do chroot
    #   - Executar um comando único dentro do chroot e voltar
    #   - Desmontar tudo de forma limpa, com verificações adicionais
    #
    # Uso básico:
    #   ROOTFS=/tmp/rootfs ./manage-chroot.sh enter
    #   ROOTFS=/tmp/rootfs ./manage-chroot.sh run "ls -l /"
    #   ROOTFS=/tmp/rootfs ./manage-chroot.sh mount
    #   ROOTFS=/tmp/rootfs ./manage-chroot.sh umount

    set -euo pipefail
    trap 'echo "[chroot] ERRO na linha ${LINENO}" >&2' ERR

    ROOTFS=${ROOTFS:-/tmp/rootfs}
    ACTION=${1:-enter}

    ###############################################################################
    # Utilitários
    ###############################################################################

    log_info()  { printf '[chroot] %s
' "$*" >&2; }
    log_error() { printf '[chroot][ERRO] %s
' "$*" >&2; }

    usage() {
      cat >&2 <<EOF
Uso: ROOTFS=/caminho/para/rootfs $0 <acao> [comando...]

Ações:
  mount          Monta /dev, /dev/pts, /proc, /sys e /run dentro do ROOTFS
  umount         Desmonta /dev/pts, /dev, /proc, /sys e /run dentro do ROOTFS
  enter          Monta, entra em shell interativo no chroot e desmonta ao sair
  run CMD...     Monta, executa um comando único CMD dentro do chroot e desmonta

Exemplos:
  ROOTFS=/tmp/rootfs $0 enter
  ROOTFS=/tmp/rootfs $0 run "ls -l /"
  ROOTFS=/tmp/rootfs $0 mount
  ROOTFS=/tmp/rootfs $0 umount
EOF
    }

    require_root() {
      if [[ "$(id -u)" -ne 0 ]]; then
        log_error "Este script precisa ser executado como root."
        exit 1
      fi
    }

    # Para montar, exigimos que ROOTFS pareça um rootfs válido.
    require_rootfs_for_mount() {
      if [[ ! -d "$ROOTFS" ]]; then
        log_error "ROOTFS não existe: $ROOTFS"
        exit 1
      fi

      if [[ ! -d "$ROOTFS/tools" && ! -d "$ROOTFS/bin" && ! -d "$ROOTFS/usr" ]]; then
        log_error "ROOTFS não parece conter um sistema (faltando /tools, /bin ou /usr): $ROOTFS"
        exit 1
      fi
    }

    # Para desmontar, aceitamos apenas que o diretório exista; não exigimos estrutura.
    require_rootfs_for_umount() {
      if [[ ! -d "$ROOTFS" ]]; then
        log_info "ROOTFS não existe mais: $ROOTFS (nada para desmontar)."
        return 1
      fi
      return 0
    }

    # Verifica se um destino está montado, olhando a segunda coluna de /proc/mounts
    is_mounted() {
      local target="$1"
      awk -v t="$target" '$2 == t {exit 0} END {exit 1}' /proc/mounts
    }

    mount_chroot_fs() {
      require_root
      require_rootfs_for_mount

      log_info "Montando sistemas de arquivos no chroot: $ROOTFS"

      mkdir -p "$ROOTFS/dev" "$ROOTFS/dev/pts" "$ROOTFS/proc" "$ROOTFS/sys" "$ROOTFS/run"

      if ! is_mounted "$ROOTFS/dev"; then
        mount --bind /dev "$ROOTFS/dev"
      fi

      if ! is_mounted "$ROOTFS/dev/pts"; then
        mount --bind /dev/pts "$ROOTFS/dev/pts"
      fi

      if ! is_mounted "$ROOTFS/proc"; then
        mount -t proc proc "$ROOTFS/proc"
      fi

      if ! is_mounted "$ROOTFS/sys"; then
        mount -t sysfs sysfs "$ROOTFS/sys"
      fi

      if [[ -d /run ]]; then
        if ! is_mounted "$ROOTFS/run"; then
          mount --bind /run "$ROOTFS/run"
        fi
      else
        log_info "/run não existe no host; pulando bind mount de /run."
      fi

      log_info "Montagem concluída."
    }

    umount_one() {
      local target="$1"
      if is_mounted "$target"; then
        # Tenta desmontar; se falhar, avisa mas não mata o script
        if ! umount "$target" 2>/dev/null; then
          log_error "Falha ao desmontar $target (pode estar em uso)."
        else
          log_info "Desmontado: $target"
        fi
      fi
    }

    umount_chroot_fs() {
      require_root

      if ! require_rootfs_for_umount; then
        # ROOTFS não existe mais; nada para fazer.
        return 0
      fi

      log_info "Desmontando sistemas de arquivos do chroot: $ROOTFS"

      # Ordem reversa para evitar problemas de dependência
      umount_one "$ROOTFS/dev/pts"
      umount_one "$ROOTFS/dev"
      umount_one "$ROOTFS/proc"
      umount_one "$ROOTFS/sys"
      umount_one "$ROOTFS/run"

      log_info "Desmontagem concluída (ou tão completa quanto possível)."
    }

    enter_chroot() {
      require_root
      require_rootfs_for_mount

      mount_chroot_fs

      log_info "Entrando no chroot interativo em $ROOTFS..."

      chroot "$ROOTFS" /usr/bin/env -i         HOME=/root         TERM="${TERM:-xterm}"         PS1="(chroot) \u@\h:\w\$ "         PATH=/tools/bin:/bin:/usr/bin:/sbin:/usr/sbin         /bin/bash --login

      local status=$?
      log_info "Shell do chroot finalizado com status $status"

      umount_chroot_fs

      return "$status"
    }

    run_in_chroot() {
      require_root
      require_rootfs_for_mount

      shift  # Remove a ação "run"
      if [[ "$#" -eq 0 ]]; then
        log_error "Nenhum comando informado para 'run'."
        usage
        exit 1
      fi

      local cmd="$*"

      mount_chroot_fs

      log_info "Executando comando no chroot: $cmd"

      chroot "$ROOTFS" /usr/bin/env -i         HOME=/root         TERM="${TERM:-xterm}"         PS1="(chroot) \u@\h:\w\$ "         PATH=/tools/bin:/bin:/usr/bin:/sbin:/usr/sbin         /bin/bash -lc "$cmd"

      local status=$?
      log_info "Comando no chroot finalizado com status $status"

      umount_chroot_fs

      return "$status"
    }

    ###############################################################################
    # Dispatch
    ###############################################################################

    case "$ACTION" in
      mount)
        mount_chroot_fs
        ;;
      umount|unmount)
        umount_chroot_fs
        ;;
      enter)
        enter_chroot
        ;;
      run)
        run_in_chroot "$@"
        ;;
      -h|--help|help)
        usage
        ;;
      *)
        log_error "Ação desconhecida: $ACTION"
        usage
        exit 1
        ;;
    esac
