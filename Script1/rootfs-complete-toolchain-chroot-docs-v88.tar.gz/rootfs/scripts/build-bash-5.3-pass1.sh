#!/usr/bin/env bash
# build-bash-5.3-pass1.sh
# Constrói o GNU Bash 5.3 como ferramenta temporária em $ROOTFS/tools (pass1).
#
# Este Bash é usado APENAS no host durante a construção do sistema
# e não faz parte do sistema final.

set -euo pipefail
trap 'echo "[bash] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-bash-5.3-pass1}
SRC_DIR=${SRC_DIR:-/tmp/sources}

BASH_VERSION=${BASH_VERSION:-5.3}
BASH_PKG=${BASH_PKG:-bash-"$BASH_VERSION"}
BASH_ARCHIVE=${BASH_ARCHIVE:-"$SRC_DIR/$BASH_PKG.tar.gz"}
BASH_URL=${BASH_URL:-"https://ftp.gnu.org/gnu/bash/$BASH_PKG.tar.gz"}

JOBS=${JOBS:-"$(nproc)"}

export ROOTFS TOOLS TMP SRC_DIR BASH_VERSION BASH_PKG BASH_ARCHIVE

###############################################################################
# Preparação de diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"

for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  if [[ ! -w "$d" ]]; then
    echo "[bash] ERRO: diretório '$d' não é gravável" >&2
    exit 1
  fi
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar make gcc; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[bash] ERRO: comando obrigatório não encontrado: $cmd" >&2
    exit 1
  fi
done

# Garantir que ferramentas temporárias tenham prioridade
export PATH="$TOOLS/bin:$PATH"

###############################################################################
# Obtenção do código-fonte
###############################################################################

if [[ ! -f "$BASH_ARCHIVE" ]]; then
  echo "[bash] Baixando $BASH_PKG de $BASH_URL..."
  wget -O "$BASH_ARCHIVE" "$BASH_URL"
fi

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$BASH_PKG" build-bash
tar -xf "$BASH_ARCHIVE"

if [[ ! -d "$BASH_PKG" ]]; then
  echo "[bash] ERRO: diretório de código-fonte $BASH_PKG não encontrado após extração." >&2
  exit 1
fi

mkdir -p build-bash
cd build-bash

###############################################################################
# Configuração
###############################################################################

echo "[bash] Configurando (pass1)..."

# Determinar triplet de build (bash é ferramenta do host)
if [[ -z "${BUILD_TRIPLET:-}" ]]; then
  if [[ -x "../$BASH_PKG/support/config.guess" ]]; then
    BUILD_TRIPLET="$(../"$BASH_PKG"/support/config.guess)"
  else
    BUILD_TRIPLET="$(../"$BASH_PKG"/config.guess 2>/dev/null || true)"
  fi
fi

CONFIG_OPTS=(
  "--prefix=$TOOLS"
  "--without-bash-malloc"
  "--disable-nls"
)

if [[ -n "${BUILD_TRIPLET:-}" ]]; then
  CONFIG_OPTS+=("--build=$BUILD_TRIPLET")
fi

../"$BASH_PKG"/configure "${CONFIG_OPTS[@]}"

###############################################################################
# Compilação
###############################################################################

echo "[bash] Compilando (pass1) com $JOBS jobs..."
make -j"$JOBS"

###############################################################################
# Testes opcionais
###############################################################################

if [[ "${BASH_RUN_TESTS:-0}" = "1" ]]; then
  echo "[bash] Executando 'make tests' (opcional)..."
  make tests
else
  echo "[bash] Pulando testes (defina BASH_RUN_TESTS=1 para executar)."
fi

###############################################################################
# Instalação
###############################################################################

echo "[bash] Instalando em $TOOLS..."
make install

echo "[bash] Concluído com sucesso."
