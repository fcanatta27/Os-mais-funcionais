#!/usr/bin/env bash
    # build-perl-5.42.0.sh
    # Constrói o Perl 5.42.0 dentro do sistema (fase chroot / ferramentas adicionais)

    set -euo pipefail
    trap 'echo "[perl] ERRO na linha ${LINENO}" >&2' ERR

    ###############################################################################
    # Configuração básica
    ###############################################################################

    ROOTFS=${ROOTFS:-/}
    DESTDIR=${DESTDIR:-"$ROOTFS"}
    SRC_DIR=${SRC_DIR:-/tmp/sources}
    TMP=${TMP:-/tmp/build-perl-5.42.0}

    PERL_VERSION=${PERL_VERSION:-5.42.0}
    PERL_PKG=${PERL_PKG:-perl-"$PERL_VERSION"}
    PERL_ARCHIVE=${PERL_ARCHIVE:-"$SRC_DIR/$PERL_PKG.tar.gz"}
    PERL_URL=${PERL_URL:-"https://www.cpan.org/src/5.0/$PERL_PKG.tar.gz"}

    export ROOTFS DESTDIR SRC_DIR TMP PERL_VERSION PERL_PKG PERL_ARCHIVE

    ###############################################################################
    # Diretórios e verificações
    ###############################################################################

    mkdir -p "$DESTDIR" "$SRC_DIR" "$TMP"

    for d in "$DESTDIR" "$SRC_DIR" "$TMP"; do
      if [[ ! -d "$d" ]]; then
        echo "[perl] ERRO: diretório não encontrado: $d" >&2
        exit 1
      fi
      if [[ ! -w "$d" ]]; then
        echo "[perl] ERRO: diretório não é gravável: $d" >&2
        exit 1
      fi
    done

    ###############################################################################
    # Dependências mínimas
    ###############################################################################

    for cmd in wget tar make sh gcc; do
      if ! command -v "$cmd" >/dev/null 2>&1; then
        echo "[perl] ERRO: comando obrigatório não encontrado: $cmd" >&2
        exit 1
      fi
    done

    if [[ -z "${JOBS:-}" ]]; then
      if command -v nproc >/dev/null 2>&1; then
        JOBS="$(nproc)"
      else
        JOBS=1
      fi
    fi

    ###############################################################################
    # Obtenção do código-fonte
    ###############################################################################

    if [[ ! -f "$PERL_ARCHIVE" ]]; then
      echo "[perl] Baixando $PERL_PKG de $PERL_URL..."
      mkdir -p "$SRC_DIR"
      wget -O "$PERL_ARCHIVE" "$PERL_URL"
    fi

    ###############################################################################
    # Extração
    ###############################################################################

    cd "$TMP"
    rm -rf "$PERL_PKG"
    tar -xf "$PERL_ARCHIVE"

    if [[ ! -d "$PERL_PKG" ]]; then
      echo "[perl] ERRO: diretório de código-fonte $PERL_PKG não encontrado após extração." >&2
      exit 1
    fi

    cd "$PERL_PKG"

    ###############################################################################
    # Configuração
    ###############################################################################

    echo "[perl] Configurando Perl $PERL_VERSION para prefix=/usr (DESTDIR=$DESTDIR)..."

    # Diretórios de biblioteca seguindo um esquema parecido com LFS,
    # usando a versão principal+secundária (ex.: 5.42)
    PERL_SHORT_VERSION="$(printf '%s
' "$PERL_VERSION" | awk -F. '{printf "%s.%s", $1, $2}')"

    sh Configure -des       -Dprefix=/usr       -Dvendorprefix=/usr       -Dprivlib=/usr/lib/perl5/"$PERL_SHORT_VERSION"/core_perl       -Darchlib=/usr/lib/perl5/"$PERL_SHORT_VERSION"/core_perl       -Dsitelib=/usr/lib/perl5/"$PERL_SHORT_VERSION"/site_perl       -Dsitearch=/usr/lib/perl5/"$PERL_SHORT_VERSION"/site_perl       -Dvendorlib=/usr/lib/perl5/"$PERL_SHORT_VERSION"/vendor_perl       -Dvendorarch=/usr/lib/perl5/"$PERL_SHORT_VERSION"/vendor_perl       -Dman1dir=/usr/share/man/man1       -Dman3dir=/usr/share/man/man3       -Dusethreads

    ###############################################################################
    # Compilação
    ###############################################################################

    echo "[perl] Compilando com $JOBS jobs..."
    make -j"$JOBS"

    ###############################################################################
    # Testes (opcionais)
    ###############################################################################

    if [[ "${PERL_RUN_TESTS:-0}" = "1" ]]; then
      echo "[perl] Executando 'make test' (pode ser demorado)..."
      make test
    else
      echo "[perl] Pulando 'make test' (defina PERL_RUN_TESTS=1 para executar testes)."
    fi

    ###############################################################################
    # Instalação
    ###############################################################################

    echo "[perl] Instalando em $DESTDIR..."
    make install DESTDIR="$DESTDIR"

    echo "[perl] Concluído com sucesso."
