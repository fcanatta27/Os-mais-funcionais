#!/usr/bin/env bash
# build-sed-4.9-pass1.sh
# Constrói o GNU sed 4.9 como ferramenta temporária em $ROOTFS/tools (pass1)
#
# Este sed é uma ferramenta do host, usada por vários scripts de build.

set -euo pipefail
trap 'echo "[sed] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-sed-4.9-pass1}
SRC_DIR=${SRC_DIR:-/tmp/sources}

SED_VERSION=${SED_VERSION:-4.9}
SED_PKG=${SED_PKG:-sed-"$SED_VERSION"}
SED_ARCHIVE=${SED_ARCHIVE:-"$SRC_DIR/$SED_PKG.tar.xz"}
SED_URL=${SED_URL:-"https://ftp.gnu.org/gnu/sed/$SED_PKG.tar.xz"}

export ROOTFS TOOLS TMP SRC_DIR SED_VERSION SED_PKG SED_ARCHIVE

###############################################################################
# Preparação de diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"

for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  if [[ ! -w "$d" ]]; then
    echo "[sed] ERRO: diretório '$d' não é gravável" >&2
    exit 1
  fi
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar gcc make; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[sed] ERRO: comando obrigatório não encontrado: $cmd" >&2
    exit 1
  fi
done

# Determina número de jobs de forma segura
if [[ -z "${JOBS:-}" ]]; then
  if command -v nproc >/dev/null 2>&1; then
    JOBS="$(nproc)"
  else
    JOBS=1
  fi
fi

###############################################################################
# Ambiente de build
###############################################################################

# Muitos pacotes GNU reclamam se forem configurados como root sem isto
export FORCE_UNSAFE_CONFIGURE=1

# Usa o prefixo das ferramentas temporárias na frente do PATH
export PATH="$TOOLS/bin:$PATH"

# Flags padrão razoáveis; podem ser sobrescritas pelo ambiente
: "${CFLAGS:=-O2}"
: "${CXXFLAGS:=-O2}"
export CFLAGS CXXFLAGS

###############################################################################
# Obtenção do código-fonte
###############################################################################

if [[ ! -f "$SED_ARCHIVE" ]]; then
  echo "[sed] Baixando $SED_PKG de $SED_URL..."
  wget -O "$SED_ARCHIVE" "$SED_URL"
fi

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$SED_PKG" build-sed
tar -xf "$SED_ARCHIVE"

if [[ ! -d "$SED_PKG" ]]; then
  echo "[sed] ERRO: diretório de código-fonte $SED_PKG não encontrado após extração." >&2
  exit 1
fi

mkdir -p build-sed
cd build-sed

###############################################################################
# Configuração
###############################################################################

echo "[sed] Configurando (pass1) para instalação em $TOOLS..."

# Triplet de build (host == build)
if [[ -z "${BUILD_TRIPLET:-}" ]]; then
  if [[ -x "../$SED_PKG/build-aux/config.guess" ]]; then
    BUILD_TRIPLET="$(../"$SED_PKG"/build-aux/config.guess)"
  else
    BUILD_TRIPLET="$(../"$SED_PKG"/config.guess 2>/dev/null || true)"
  fi
fi

CONFIG_OPTS=(
  "--prefix=$TOOLS"
  "--disable-nls"
)

if [[ -n "${BUILD_TRIPLET:-}" ]]; then
  CONFIG_OPTS+=("--build=$BUILD_TRIPLET")
fi

../"$SED_PKG"/configure "${CONFIG_OPTS[@]}"

###############################################################################
# Compilação
###############################################################################

echo "[sed] Compilando (pass1) com $JOBS jobs..."
make -j"$JOBS"

###############################################################################
# Testes opcionais
###############################################################################

if [[ "${SED_RUN_TESTS:-0}" = "1" ]]; then
  echo "[sed] Executando 'make check' (pode ser demorado)..."
  make check
else
  echo "[sed] Pulando 'make check' (defina SED_RUN_TESTS=1 para executar testes)."
fi

###############################################################################
# Instalação
###############################################################################

echo "[sed] Instalando em $TOOLS..."
make install

echo "[sed] Concluído com sucesso."
