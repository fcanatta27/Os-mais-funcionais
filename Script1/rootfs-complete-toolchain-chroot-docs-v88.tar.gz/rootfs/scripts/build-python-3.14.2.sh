#!/usr/bin/env bash
# build-python-3.14.2.sh
# Constrói o Python 3.14.2 dentro do sistema (fase chroot / ferramentas adicionais)
#
# Suporta instalação tanto rodando de dentro do chroot (ROOTFS=/),
# quanto rodando do host com ROOTFS=/caminho/do/rootfs usando DESTDIR.

set -euo pipefail
trap 'echo "[python] ERRO na linha ${LINENO}" >&2' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/}
DESTDIR=${DESTDIR:-"$ROOTFS"}
SRC_DIR=${SRC_DIR:-/tmp/sources}
TMP=${TMP:-/tmp/build-python-3.14.2}

PYTHON_VERSION=${PYTHON_VERSION:-3.14.2}
PYTHON_PKG=${PYTHON_PKG:-Python-"$PYTHON_VERSION"}
PYTHON_ARCHIVE=${PYTHON_ARCHIVE:-"$SRC_DIR/$PYTHON_PKG.tgz"}
PYTHON_URL=${PYTHON_URL:-"https://www.python.org/ftp/python/$PYTHON_VERSION/$PYTHON_PKG.tgz"}

export ROOTFS DESTDIR SRC_DIR TMP PYTHON_VERSION PYTHON_PKG PYTHON_ARCHIVE

###############################################################################
# Diretórios e verificações
###############################################################################

mkdir -p "$DESTDIR" "$SRC_DIR" "$TMP"

for d in "$DESTDIR" "$SRC_DIR" "$TMP"; do
  if [[ ! -d "$d" ]]; then
    echo "[python] ERRO: diretório não encontrado: $d" >&2
    exit 1
  fi
  if [[ ! -w "$d" ]]; then
    echo "[python] ERRO: diretório não é gravável: $d" >&2
    exit 1
  fi
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar gcc make sed; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[python] ERRO: comando obrigatório não encontrado: $cmd" >&2
    exit 1
  fi
done

# Determina número de jobs de forma segura
if [[ -z "${JOBS:-}" ]]; then
  if command -v nproc >/dev/null 2>&1; then
    JOBS="$(nproc)"
  else
    JOBS=1
  fi
fi

###############################################################################
# Ambiente
###############################################################################

: "${CFLAGS:=-O2}"
: "${CXXFLAGS:=-O2}"
export CFLAGS CXXFLAGS

###############################################################################
# Obtenção do código-fonte
###############################################################################

if [[ ! -f "$PYTHON_ARCHIVE" ]]; then
  echo "[python] Baixando $PYTHON_PKG de $PYTHON_URL..."
  mkdir -p "$SRC_DIR"
  wget -O "$PYTHON_ARCHIVE" "$PYTHON_URL"
fi

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$PYTHON_PKG"
tar -xf "$PYTHON_ARCHIVE"

if [[ ! -d "$PYTHON_PKG" ]]; then
  echo "[python] ERRO: diretório de código-fonte $PYTHON_PKG não encontrado após extração." >&2
  exit 1
fi

cd "$PYTHON_PKG"

###############################################################################
# Configuração
###############################################################################

echo "[python] Configurando Python $PYTHON_VERSION para prefix=/usr (DESTDIR=$DESTDIR)..."

./configure       --prefix=/usr       --enable-shared       --with-system-expat       --with-system-ffi       --enable-optimizations       --with-ensurepip=no

###############################################################################
# Compilação
###############################################################################

echo "[python] Compilando com $JOBS jobs..."
make -j"$JOBS"

###############################################################################
# Testes (opcionais)
###############################################################################

if [[ "${PYTHON_RUN_TESTS:-0}" = "1" ]]; then
  echo "[python] Executando suíte de testes (pode ser muito demorado)..."
  # A suíte completa é bem pesada; é recomendável executá-la apenas em máquinas estáveis.
  make test
else
  echo "[python] Pulando 'make test' (defina PYTHON_RUN_TESTS=1 para executar testes)."
fi

###############################################################################
# Instalação
###############################################################################

echo "[python] Instalando em $DESTDIR..."
make install DESTDIR="$DESTDIR"

# Garante que o linker encontre a libpython compartilhada, se necessário
if command -v ldconfig >/dev/null 2>&1 && [[ "$DESTDIR" == "/" ]]; then
  echo "[python] Atualizando cache de bibliotecas com ldconfig..."
  ldconfig
fi

echo "[python] Concluído com sucesso."
