#!/usr/bin/env bash
# build-gettext-0.26.sh
# Constrói o Gettext 0.26 dentro do sistema (fase chroot / ferramentas adicionais)
#
# Suporta instalação tanto rodando de dentro do chroot (ROOTFS=/),
# quanto rodando do host com ROOTFS=/caminho/do/rootfs usando DESTDIR.

set -euo pipefail
trap 'echo "[gettext] ERRO na linha ${LINENO}" >&2' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/}
DESTDIR=${DESTDIR:-"$ROOTFS"}
SRC_DIR=${SRC_DIR:-/tmp/sources}
TMP=${TMP:-/tmp/build-gettext-0.26}

GETTEXT_VERSION=${GETTEXT_VERSION:-0.26}
GETTEXT_PKG=${GETTEXT_PKG:-gettext-"$GETTEXT_VERSION"}
GETTEXT_ARCHIVE=${GETTEXT_ARCHIVE:-"$SRC_DIR/$GETTEXT_PKG.tar.xz"}
GETTEXT_URL=${GETTEXT_URL:-"https://ftp.gnu.org/gnu/gettext/$GETTEXT_PKG.tar.xz"}

export ROOTFS DESTDIR SRC_DIR TMP GETTEXT_VERSION GETTEXT_PKG GETTEXT_ARCHIVE

###############################################################################
# Diretórios e verificações
###############################################################################

mkdir -p "$DESTDIR" "$SRC_DIR" "$TMP"

for d in "$DESTDIR" "$SRC_DIR" "$TMP"; do
  if [[ ! -d "$d" ]]; then
    echo "[gettext] ERRO: diretório não encontrado: $d" >&2
    exit 1
  fi
  if [[ ! -w "$d" ]]; then
    echo "[gettext] ERRO: diretório não é gravável: $d" >&2
    exit 1
  fi
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar gcc make; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[gettext] ERRO: comando obrigatório não encontrado: $cmd" >&2
    exit 1
  fi
done

# Determina número de jobs de forma segura
if [[ -z "${JOBS:-}" ]]; then
  if command -v nproc >/dev/null 2>&1; then
    JOBS="$(nproc)"
  else
    JOBS=1
  fi
fi

###############################################################################
# Ambiente
###############################################################################

# Muitos pacotes GNU reclamam se forem configurados como root sem isto
export FORCE_UNSAFE_CONFIGURE=1

: "${CFLAGS:=-O2}"
: "${CXXFLAGS:=-O2}"
export CFLAGS CXXFLAGS

###############################################################################
# Obtenção do código-fonte
###############################################################################

if [[ ! -f "$GETTEXT_ARCHIVE" ]]; then
  echo "[gettext] Baixando $GETTEXT_PKG de $GETTEXT_URL..."
  mkdir -p "$SRC_DIR"
  wget -O "$GETTEXT_ARCHIVE" "$GETTEXT_URL"
fi

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$GETTEXT_PKG" build-gettext
tar -xf "$GETTEXT_ARCHIVE"

if [[ ! -d "$GETTEXT_PKG" ]]; then
  echo "[gettext] ERRO: diretório de código-fonte $GETTEXT_PKG não encontrado após extração." >&2
  exit 1
fi

mkdir -p build-gettext
cd build-gettext

###############################################################################
# Configuração
###############################################################################

echo "[gettext] Configurando para prefix=/usr (DESTDIR=$DESTDIR)..."

../"$GETTEXT_PKG"/configure       --prefix=/usr       --disable-static       --docdir=/usr/share/doc/"$GETTEXT_PKG"

###############################################################################
# Compilação
###############################################################################

echo "[gettext] Compilando com $JOBS jobs..."
make -j"$JOBS"

###############################################################################
# Testes (opcionais)
###############################################################################

if [[ "${GETTEXT_RUN_TESTS:-0}" = "1" ]]; then
  echo "[gettext] Executando 'make check' (pode ser demorado)..."
  make check
else
  echo "[gettext] Pulando 'make check' (defina GETTEXT_RUN_TESTS=1 para executar testes)."
fi

###############################################################################
# Instalação
###############################################################################

echo "[gettext] Instalando em $DESTDIR..."
make install DESTDIR="$DESTDIR"

echo "[gettext] Concluído com sucesso."
