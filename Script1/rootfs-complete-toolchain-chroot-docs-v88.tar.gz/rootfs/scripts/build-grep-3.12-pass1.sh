#!/usr/bin/env bash
# build-grep-3.12-pass1.sh
# Constrói o GNU grep 3.12 como ferramenta temporária em $ROOTFS/tools (pass1)

set -euo pipefail
trap 'echo "[grep] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-grep-3.12-pass1}
SRC_DIR=${SRC_DIR:-/tmp/sources}

GREP_VERSION=${GREP_VERSION:-3.12}
GREP_PKG="grep-${GREP_VERSION}"
GREP_ARCHIVE="$SRC_DIR/$GREP_PKG.tar.xz"
GREP_URL="https://ftp.gnu.org/gnu/grep/$GREP_PKG.tar.xz"

JOBS=${JOBS:-"$(nproc)"}

export ROOTFS TOOLS TMP SRC_DIR GREP_VERSION GREP_PKG GREP_ARCHIVE

###############################################################################
# Diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"
for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  [[ -w "$d" ]] || { echo "[grep] ERRO: $d não gravável"; exit 1; }
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar make gcc; do
  command -v "$cmd" >/dev/null 2>&1 || {
    echo "[grep] ERRO: comando ausente: $cmd"; exit 1; }
done

export FORCE_UNSAFE_CONFIGURE=1
export PATH="$TOOLS/bin:$PATH"
: "${CFLAGS:=-O2}"
export CFLAGS

###############################################################################
# Fonte
###############################################################################

[[ -f "$GREP_ARCHIVE" ]] || wget -O "$GREP_ARCHIVE" "$GREP_URL"

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$GREP_PKG" build-grep
tar -xf "$GREP_ARCHIVE"
cd build-grep || { mkdir build-grep && cd build-grep; }

###############################################################################
# Configuração
###############################################################################

BUILD_TRIPLET=${BUILD_TRIPLET:-"$(../$GREP_PKG/build-aux/config.guess 2>/dev/null || ../$GREP_PKG/config.guess)"}

../"$GREP_PKG"/configure   --prefix="$TOOLS"   --disable-nls   --build="$BUILD_TRIPLET"

###############################################################################
# Build / install
###############################################################################

make -j"$JOBS"
make install
