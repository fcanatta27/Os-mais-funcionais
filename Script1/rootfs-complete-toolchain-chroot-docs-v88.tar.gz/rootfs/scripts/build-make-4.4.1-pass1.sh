#!/usr/bin/env bash
# build-make-4.4.1-pass1.sh
# Constrói o GNU make 4.4.1 como ferramenta temporária em $ROOTFS/tools (pass1)

set -euo pipefail
trap 'echo "[make] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-make-4.4.1-pass1}
SRC_DIR=${SRC_DIR:-/tmp/sources}

MAKE_VERSION=${MAKE_VERSION:-4.4.1}
MAKE_PKG=${MAKE_PKG:-make-"$MAKE_VERSION"}
MAKE_ARCHIVE=${MAKE_ARCHIVE:-"$SRC_DIR/$MAKE_PKG.tar.gz"}
MAKE_URL=${MAKE_URL:-"https://ftp.gnu.org/gnu/make/$MAKE_PKG.tar.gz"}

export ROOTFS TOOLS TMP SRC_DIR MAKE_VERSION MAKE_PKG MAKE_ARCHIVE

###############################################################################
# Diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"
for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  [[ -w "$d" ]] || { echo "[make] ERRO: $d não é gravável"; exit 1; }
done

###############################################################################
# Dependências
###############################################################################

for cmd in wget tar gcc make; do
  command -v "$cmd" >/dev/null 2>&1 || {
    echo "[make] ERRO: comando obrigatório não encontrado: $cmd"
    exit 1
  }
done

# JOBS seguro
if [[ -z "${JOBS:-}" ]]; then
  if command -v nproc >/dev/null 2>&1; then
    JOBS="$(nproc)"
  else
    JOBS=1
  fi
fi

###############################################################################
# Ambiente
###############################################################################

export FORCE_UNSAFE_CONFIGURE=1
export PATH="$TOOLS/bin:$PATH"

: "${CFLAGS:=-O2}"
: "${CXXFLAGS:=-O2}"
export CFLAGS CXXFLAGS

###############################################################################
# Fonte
###############################################################################

if [[ ! -f "$MAKE_ARCHIVE" ]]; then
  wget -O "$MAKE_ARCHIVE" "$MAKE_URL"
fi

###############################################################################
# Build
###############################################################################

cd "$TMP"
rm -rf "$MAKE_PKG" build-make
tar -xf "$MAKE_ARCHIVE"
[[ -d "$MAKE_PKG" ]] || { echo "[make] ERRO: fonte não encontrada"; exit 1; }

mkdir build-make
cd build-make

# Triplet
if [[ -z "${BUILD_TRIPLET:-}" ]]; then
  if [[ -x ../$MAKE_PKG/build-aux/config.guess ]]; then
    BUILD_TRIPLET="$(../$MAKE_PKG/build-aux/config.guess)"
  else
    BUILD_TRIPLET="$(../$MAKE_PKG/config.guess 2>/dev/null || true)"
  fi
fi

CONFIG_OPTS=(
  "--prefix=$TOOLS"
  "--disable-nls"
)

[[ -n "$BUILD_TRIPLET" ]] && CONFIG_OPTS+=("--build=$BUILD_TRIPLET")

../"$MAKE_PKG"/configure "${CONFIG_OPTS[@]}"

make -j"$JOBS"

if [[ "${MAKE_RUN_TESTS:-0}" == "1" ]]; then
  make check
fi

make install

echo "[make] OK"
