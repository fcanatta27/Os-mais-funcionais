#!/usr/bin/env bash
# build-binutils-2.45.1-pass1.sh
# Primeiro estágio do binutils para toolchain em $ROOTFS/tools (padrão: /tmp/rootfs/tools)

set -euo pipefail

# Mostra a linha em caso de erro, para facilitar debug
trap 'echo "[binutils] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
TMP=${TMP:-/tmp/build-binutils-2.45.1-pass1}
SRC_DIR=${SRC_DIR:-/tmp/sources}

TARGET=${TARGET:-x86_64-pc-linux-gnu}
BINUTILS_VERSION=${BINUTILS_VERSION:-2.45.1}
PKG_NAME=${PKG_NAME:-binutils-"$BINUTILS_VERSION"}
ARCHIVE=${ARCHIVE:-"$SRC_DIR/$PKG_NAME.tar.xz"}
BINUTILS_URL=${BINUTILS_URL:-"https://ftp.gnu.org/gnu/binutils/$PKG_NAME.tar.xz"}
JOBS=${JOBS:-"$(nproc)"}

export ROOTFS TOOLS TMP SRC_DIR TARGET BINUTILS_VERSION PKG_NAME ARCHIVE

###############################################################################
# Preparação de diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"

# Verificação rápida de permissão de escrita
for d in "$ROOTFS" "$TOOLS" "$TMP" "$SRC_DIR"; do
  if [[ ! -w "$d" ]]; then
    echo "[binutils] ERRO: diretório '$d' não é gravável" >&2
    exit 1
  fi
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar make gcc; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[binutils] ERRO: comando obrigatório não encontrado: $cmd" >&2
    exit 1
  fi
done

###############################################################################
# Obtenção do código-fonte
###############################################################################

if [[ ! -f "$ARCHIVE" ]]; then
  echo "[binutils] Baixando $PKG_NAME de $BINUTILS_URL..."
  wget -O "$ARCHIVE" "$BINUTILS_URL"
fi

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$PKG_NAME" build-binutils
tar -xf "$ARCHIVE"
mkdir -p build-binutils
cd build-binutils

###############################################################################
# Configuração
###############################################################################

echo "[binutils] Configurando (pass1)..."

# Garante que futuros passos usem ferramentas em $TOOLS/bin primeiro
export PATH="$TOOLS/bin:$PATH"

../"$PKG_NAME"/configure       --prefix="$TOOLS"       --with-sysroot="$ROOTFS"       --target="$TARGET"       --disable-nls       --disable-werror       --enable-gold       --enable-plugins

###############################################################################
# Compilação
###############################################################################

echo "[binutils] Compilando (pass1) com $JOBS jobs..."
make -j"$JOBS"

###############################################################################
# Instalação
###############################################################################

echo "[binutils] Instalando em $TOOLS..."
make install

echo "[binutils] Concluído com sucesso."
