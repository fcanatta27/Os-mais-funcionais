#!/usr/bin/env bash
# build-linux-headers-6.16.1.sh
# Instala os Linux API headers do kernel 6.16.1 em $ROOTFS/usr/include
#
# Inspirado no procedimento do Linux From Scratch, com robustez extra
# (checagem de erros, diretórios graváveis, dependências, etc.).

set -euo pipefail
trap 'echo "[linux-headers] ERRO na linha ${LINENO}"; exit 1' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/tmp/rootfs}
TMP=${TMP:-/tmp/build-linux-6.16.1-headers}
SRC_DIR=${SRC_DIR:-/tmp/sources}

LINUX_VERSION=${LINUX_VERSION:-6.16.1}
LINUX_PKG=${LINUX_PKG:-linux-"$LINUX_VERSION"}
LINUX_ARCHIVE=${LINUX_ARCHIVE:-"$SRC_DIR/$LINUX_PKG.tar.xz"}
LINUX_URL=${LINUX_URL:-"https://cdn.kernel.org/pub/linux/kernel/v6.x/$LINUX_PKG.tar.xz"}

# Arquitetura alvo dos headers (por padrão x86_64, mas pode ser sobrescrita)
ARCH=${ARCH:-x86_64}

# Número de jobs de compilação
JOBS=${JOBS:-"$(nproc)"}

export ROOTFS TMP SRC_DIR LINUX_VERSION LINUX_PKG LINUX_ARCHIVE ARCH

###############################################################################
# Preparação de diretórios
###############################################################################

mkdir -p "$ROOTFS" "$TMP" "$SRC_DIR" "$ROOTFS/usr"

for d in "$ROOTFS" "$TMP" "$SRC_DIR" "$ROOTFS/usr"; do
  if [[ ! -w "$d" ]]; then
    echo "[linux-headers] ERRO: diretório '$d' não é gravável" >&2
    exit 1
  fi
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar make; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[linux-headers] ERRO: comando obrigatório não encontrado: $cmd" >&2
    exit 1
  fi
done

###############################################################################
# Obtenção do código-fonte do kernel
###############################################################################

if [[ ! -f "$LINUX_ARCHIVE" ]]; then
  echo "[linux-headers] Baixando $LINUX_PKG de $LINUX_URL..."
  wget -O "$LINUX_ARCHIVE" "$LINUX_URL"
fi

###############################################################################
# Extração e preparação dos headers
###############################################################################

cd "$TMP"
rm -rf "$LINUX_PKG"
tar -xf "$LINUX_ARCHIVE"
cd "$LINUX_PKG"

echo "[linux-headers] Limpando árvore (mrproper)..."
# mrproper não precisa ser paralelo; mantemos em job único para maior robustez
make ARCH="$ARCH" mrproper

echo "[linux-headers] Gerando headers (make headers)..."
make -j"$JOBS" ARCH="$ARCH" headers

echo "[linux-headers] Limpando arquivos desnecessários..."
find usr/include -name '.*' -delete
rm -f usr/include/Makefile

###############################################################################
# Instalação em $ROOTFS/usr/include
###############################################################################

echo "[linux-headers] Instalando em $ROOTFS/usr/include..."
install -d "$ROOTFS/usr"
cp -rv usr/include "$ROOTFS/usr"

echo "[linux-headers] Concluído com sucesso."
