#!/usr/bin/env bash
# build-bison-3.8.2.sh
# Constrói o Bison 3.8.2 dentro do sistema (fase chroot / ferramentas adicionais)

set -euo pipefail
trap 'echo "[bison] ERRO na linha ${LINENO}" >&2' ERR

###############################################################################
# Configuração básica
###############################################################################

ROOTFS=${ROOTFS:-/}
DESTDIR=${DESTDIR:-"$ROOTFS"}
SRC_DIR=${SRC_DIR:-/tmp/sources}
TMP=${TMP:-/tmp/build-bison-3.8.2}

BISON_VERSION=${BISON_VERSION:-3.8.2}
BISON_PKG=${BISON_PKG:-bison-"$BISON_VERSION"}
BISON_ARCHIVE=${BISON_ARCHIVE:-"$SRC_DIR/$BISON_PKG.tar.xz"}
BISON_URL=${BISON_URL:-"https://ftp.gnu.org/gnu/bison/$BISON_PKG.tar.xz"}

export ROOTFS DESTDIR SRC_DIR TMP BISON_VERSION BISON_PKG BISON_ARCHIVE

###############################################################################
# Diretórios e verificações
###############################################################################

mkdir -p "$DESTDIR" "$SRC_DIR" "$TMP"

for d in "$DESTDIR" "$SRC_DIR" "$TMP"; do
  if [[ ! -d "$d" ]]; then
    echo "[bison] ERRO: diretório não encontrado: $d" >&2
    exit 1
  fi
  if [[ ! -w "$d" ]]; then
    echo "[bison] ERRO: diretório não é gravável: $d" >&2
    exit 1
  fi
done

###############################################################################
# Dependências mínimas
###############################################################################

for cmd in wget tar gcc make; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[bison] ERRO: comando obrigatório não encontrado: $cmd" >&2
    exit 1
  fi
done

if [[ -z "${JOBS:-}" ]]; then
  if command -v nproc >/dev/null 2>&1; then
    JOBS="$(nproc)"
  else
    JOBS=1
  fi
fi

###############################################################################
# Ambiente
###############################################################################

export FORCE_UNSAFE_CONFIGURE=1

: "${CFLAGS:=-O2}"
: "${CXXFLAGS:=-O2}"
export CFLAGS CXXFLAGS

###############################################################################
# Obtenção do código-fonte
###############################################################################

if [[ ! -f "$BISON_ARCHIVE" ]]; then
  echo "[bison] Baixando $BISON_PKG de $BISON_URL..."
  mkdir -p "$SRC_DIR"
  wget -O "$BISON_ARCHIVE" "$BISON_URL"
fi

###############################################################################
# Extração
###############################################################################

cd "$TMP"
rm -rf "$BISON_PKG" build-bison
tar -xf "$BISON_ARCHIVE"

if [[ ! -d "$BISON_PKG" ]]; then
  echo "[bison] ERRO: diretório de código-fonte $BISON_PKG não encontrado após extração." >&2
  exit 1
fi

mkdir -p build-bison
cd build-bison

###############################################################################
# Configuração
###############################################################################

echo "[bison] Configurando para prefix=/usr (DESTDIR=$DESTDIR)..."

../"$BISON_PKG"/configure       --prefix=/usr       --docdir=/usr/share/doc/"$BISON_PKG"

###############################################################################
# Compilação
###############################################################################

echo "[bison] Compilando com $JOBS jobs..."
make -j"$JOBS"

###############################################################################
# Testes (opcionais)
###############################################################################

if [[ "${BISON_RUN_TESTS:-0}" = "1" ]]; then
  echo "[bison] Executando 'make check' (pode ser demorado)..."
  make check
else
  echo "[bison] Pulando 'make check' (defina BISON_RUN_TESTS=1 para executar testes)."
fi

###############################################################################
# Instalação
###############################################################################

echo "[bison] Instalando em $DESTDIR..."
make install DESTDIR="$DESTDIR"

echo "[bison] Concluído com sucesso."
