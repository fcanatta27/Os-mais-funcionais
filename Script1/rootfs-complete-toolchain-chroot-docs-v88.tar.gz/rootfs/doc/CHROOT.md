# Documentação – Uso de chroot

## O que é chroot

`chroot` muda o diretório raiz aparente de um processo.

Dentro do chroot:

- `/` aponta para `$ROOTFS`
- o sistema host fica isolado

## Montagens necessárias

Para funcionamento correto, o chroot precisa:

```bash
mount --bind /dev  $ROOTFS/dev
mount -t proc proc $ROOTFS/proc
mount -t sysfs sysfs $ROOTFS/sys
mount -t devpts devpts $ROOTFS/dev/pts
```

## Entrar manualmente

```bash
chroot $ROOTFS /bin/bash
```

## Script enter-chroot.sh

O script:

- monta automaticamente os pseudo-filesystems
- entra no chroot ou executa comandos
- desmonta tudo ao sair

### Exemplos

Entrar interativo:

```bash
sudo ./enter-chroot.sh
```

Executar comando e sair:

```bash
sudo ./enter-chroot.sh --exec "ls -l /"
sudo ./enter-chroot.sh --exec "gcc --version"
```

## Segurança

- O ambiente é limpo (`env -i`)
- PATH mínimo é definido
- desmontagem forçada evita vazamentos

## Boas práticas

- Nunca monte partições do host dentro do chroot sem necessidade
- Use chroot apenas após toolchain completo
- Sempre saia desmontando corretamente (ou use o script)
