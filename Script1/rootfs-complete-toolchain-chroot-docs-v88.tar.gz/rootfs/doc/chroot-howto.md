# Guia Completo de Chroot para o ROOTFS

Este documento explica, em detalhes, como usar o chroot de forma segura e
limpa com o script `manage-chroot.sh`, além de contextualizar o papel do
chroot na construção do seu sistema Linux.

## 1. O que é chroot?

`chroot` (change root) é uma chamada de sistema e uma ferramenta que permite
executar comandos como se uma determinada pasta fosse a raiz (`/`) do sistema.

No contexto deste projeto:

- `ROOTFS` é o diretório onde o novo sistema está sendo construído;
- Ao fazer `chroot $ROOTFS`, o sistema passa a “enxergar” `$ROOTFS` como `/`;
- Isso permite continuar a construção **de dentro** do próprio sistema alvo,
  isolando-se parcialmente do host.

## 2. Por que chroot é importante aqui?

Após você construir o toolchain em `$ROOTFS/tools` (binutils, gcc, glibc,
etc.), ainda está usando o kernel e boa parte do ambiente do host. Ao entrar
no chroot:

- O `PATH` passa a priorizar `/tools/bin` (se configurado assim);
- As bibliotecas e includes dentro de `$ROOTFS` são usados como se fossem
  do sistema “real”;
- Você testa e continua a construção num ambiente bem próximo do sistema que
  será instalado.

## 3. Script `manage-chroot.sh`

O script `rootfs/scripts/manage-chroot.sh` foi criado para facilitar o uso do
chroot de forma segura e repetível.

Caminho após extrair os arquivos:

```bash
/rootfs/scripts/manage-chroot.sh
```

Ele suporta as seguintes ações:

- `mount` – monta `/dev`, `/dev/pts`, `/proc`, `/sys` e `/run` dentro do ROOTFS
- `umount` – desmonta essas entradas
- `enter` – monta, entra em um shell interativo no chroot e desmonta ao sair
- `run CMD...` – monta, executa um comando único `CMD` dentro do chroot e desmonta

## 4. Variáveis e pré-requisitos

- `ROOTFS`  
  Diretório raiz do sistema que você está construindo. Padrão:

  ```bash
  ROOTFS=/tmp/rootfs
  ```

- Você **precisa** ser root para rodar o script (montar/desmontar).
- O `ROOTFS` deve conter pelo menos um dos diretórios:
  - `$ROOTFS/tools` ou
  - `$ROOTFS/bin` ou
  - `$ROOTFS/usr`

  Caso contrário, o script assume que o `ROOTFS` não é válido e aborta.

## 5. Montando o ambiente de chroot

Internamente, a ação `mount` faz aproximadamente:

```bash
mkdir -p "$ROOTFS/dev" "$ROOTFS/dev/pts" "$ROOTFS/proc" "$ROOTFS/sys" "$ROOTFS/run"

mount --bind /dev     "$ROOTFS/dev"
mount --bind /dev/pts "$ROOTFS/dev/pts"
mount -t proc  proc   "$ROOTFS/proc"
mount -t sysfs sysfs  "$ROOTFS/sys"
mount --bind /run     "$ROOTFS/run"
```

O script verifica se cada um desses alvo já está montado (usando `/proc/mounts`).
Se já estiver, não tenta montar de novo, evitando montagens duplicadas.

### Exemplo real

```bash
export ROOTFS=/tmp/rootfs
cd /rootfs/scripts

sudo ./manage-chroot.sh mount
```

Após isso, o `$ROOTFS` está pronto para receber o chroot.

## 6. Entrando no chroot de forma interativa

A ação `enter`:

1. Garante que você é root;
2. Verifica se `ROOTFS` existe e parece válido;
3. Chama `mount_chroot_fs` (equivalente à ação `mount`);
4. Faz `chroot` com um ambiente controlado;
5. Ao sair do shell, desmonta os sistemas de arquivos (`umount_chroot_fs`).

Internamente, o comando principal é algo como:

```bash
chroot "$ROOTFS" /usr/bin/env -i \
  HOME=/root \
  TERM="${TERM:-xterm}" \
  PS1="(chroot) \u@\h:\w\$ " \
  PATH=/tools/bin:/bin:/usr/bin:/sbin:/usr/sbin \
  /bin/bash --login
```

- `env -i` limpa o ambiente e só define variáveis explícitas:
  - `HOME=/root`
  - `TERM` herdado (ou `xterm` se não definido)
  - `PS1` customizado para indicar que você está no chroot
  - `PATH` priorizando `/tools/bin`

### Exemplo real

```bash
export ROOTFS=/tmp/rootfs
cd /rootfs/scripts

sudo ./manage-chroot.sh enter
```

Você verá um prompt parecido com:

```text
(chroot) root@<host>:/#
```

A partir daí, tudo que você fizer (instalar pacotes, compilar programas,
editar arquivos em `/etc`, etc.) será aplicado dentro de `$ROOTFS`.

Ao digitar `exit` ou `Ctrl+D`, o shell do chroot termina, o script registra o
status de saída e chama automaticamente a desmontagem (ação equivalente a
`umount`).

## 7. Executando um único comando no chroot (`run`)

Às vezes você não quer entrar interativamente, apenas rodar um comando único.
A ação `run` serve para isso.

Internamente, ela:

1. Monta os sistemas de arquivos (como `mount`);
2. Executa um comando via `/bin/bash -lc "COMANDO"` dentro do chroot;
3. Desmonta tudo ao final.

Exemplo simples:

```bash
export ROOTFS=/tmp/rootfs
cd /rootfs/scripts

sudo ./manage-chroot.sh run "ls -l /"
```

Exemplo rodando `gcc --version` dentro do chroot:

```bash
sudo ./manage-chroot.sh run "which gcc && gcc --version"
```

Isso é útil para scripts automatizados, onde você quer orquestrar passos sem
ficar em um shell interativo.

## 8. Desmontando manualmente (`umount`)

Se você preferir ter controle manual, pode chamar diretamente a ação `umount`:

```bash
export ROOTFS=/tmp/rootfs
cd /rootfs/scripts

sudo ./manage-chroot.sh umount
```

A função correspondente desmonta, na ordem reversa:

1. `$ROOTFS/dev/pts`
2. `$ROOTFS/dev`
3. `$ROOTFS/proc`
4. `$ROOTFS/sys`
5. `$ROOTFS/run`

Se alguma desmontagem falhar (por exemplo, se ainda houver processos dentro
do chroot segurando o filesystem), o script **não aborta** — ele apenas emite
uma mensagem de erro para esse alvo específico.

## 9. Relação entre o chroot e o toolchain

Depois de rodar o `build-toolchain-full.sh`, você terá um conjunto completo
de ferramentas em:

```bash
$ROOTFS/tools
```

Dentro do chroot, esse diretório aparece como `/tools`. O script de chroot
ajusta o `PATH` para colocar `/tools/bin` na frente, ou seja:

```bash
PATH=/tools/bin:/bin:/usr/bin:/sbin:/usr/sbin
```

Assim, quando você rodar:

```bash
(chroot) root:/# gcc --version
```

deverá ver o `gcc` que você acabou de construir (GCC 15.2.0), e não o `gcc`
do host.

## 10. Fluxo completo típico (exemplo real)

1. **Extrair os scripts e construir o toolchain:**

   ```bash
   cd /
   sudo tar -xvf rootfs-all-pass1-scripts-v13.tar.gz

   export ROOTFS=/tmp/rootfs
   export SRC_DIR=/tmp/sources

   cd /rootfs/scripts
   sudo ./build-toolchain-full.sh
   ```

2. **Preparar e entrar no chroot:**

   ```bash
   cd /rootfs/scripts
   export ROOTFS=/tmp/rootfs

   sudo ./manage-chroot.sh enter
   ```

3. **Dentro do chroot**, continuar a construção do sistema final (por exemplo,
   instalar pacotes em `/usr`, configurar `/etc`, etc.).

4. **Sair do chroot** com `exit` ou `Ctrl+D`.

5. **Garantir desmontagem completa** (se necessário):

   ```bash
   cd /rootfs/scripts
   export ROOTFS=/tmp/rootfs
   sudo ./manage-chroot.sh umount
   ```

## 11. Boas práticas e cuidados

- Sempre execute o script como **root**;
- Evite deixar o chroot montado sem necessidade (use `enter` ou `run`, que já
  montam e desmontam automaticamente);
- Se for usar `mount` manualmente, lembre-se de chamar `umount` ao terminar;
- Verifique sempre o valor de `ROOTFS` antes de rodar os scripts, para não
  montar/desmontar caminhos errados;
- Dentro do chroot, tenha em mente que **você ainda está usando o kernel do
  host**, então não é um container completo, mas já é suficiente para
  construir e testar o userland do novo sistema.
