# SPM – Simple Package Manager (v3)

Este documento explica **tudo** sobre o `spm` do seu sistema:

- Conceitos básicos
- Layout de diretórios
- Ciclo de vida de um pacote
- Todos os comandos suportados
- Um exemplo **real** de `build.sh` explicado passo a passo

A ideia é que qualquer pessoa, mesmo leiga, consiga entender o que está acontecendo.

---

## 1. Visão geral

O `spm` é um gerenciador de pacotes **simples e transparente**, pensado para o seu Linux
“from scratch”. Ele não faz mágica: tudo é baseado em:

- scripts `build.sh` em `/etc/spm/pkg/<nome>/build.sh`;
- cache de fontes e pacotes em `/var/cache/spm`;
- manifestos de arquivos em `/var/lib/spm/manifests`;
- comandos pequenos que combinam **resolver dependências + build + instalar**.

Ele sempre constrói pacotes em um diretório temporário, instala primeiro em um `DESTDIR`
de staging e só depois gera um pacote `.spm.tar.zst` que pode ser instalado em `/`.

---

## 2. Layout de diretórios

Estes são os caminhos padrão quando você está dentro do chroot (`SPM_ROOT=/`):

- **Definições de pacotes**
  - `/etc/spm/pkg/<pacote>/build.sh`
  - `/etc/spm/pkg/<pacote>/` pode conter:
    - patches (`.patch`)
    - arquivos auxiliares
    - outros sources locais

- **Cache de fontes (tarballs, patches etc.)**
  - `/var/cache/spm/src/<pacote>/arquivo.tar.xz`

- **Cache de pacotes binários**
  - `/var/cache/spm/pkg/<nome>-<versao>.spm.tar.zst`

- **Banco de dados de pacotes**
  - Manifestos de arquivos:
    - `/var/lib/spm/manifests/<nome>-<versao>.manifest.cache`
  - Status (instalado ou não):
    - `/var/lib/spm/status/<nome>`

- **Diretórios de build / staging**
  - Diretório temporário raiz:
    - `SPM_BUILD_ROOT` (por padrão, `/tmp/spm-build`)
  - Diretório de build de um pacote:
    - `$SPM_BUILD_ROOT/<nome>-build`
  - Diretório de staging (DESTDIR):
    - `$SPM_BUILD_ROOT/<nome>-stage`

---

## 3. Variáveis de ambiente importantes

O `spm` garante as seguintes variáveis quando roda um `build.sh`:

- `TMP`  
  Diretório temporário base. Por padrão, `/tmp`.

- `SPM_BUILD_ROOT`  
  Raiz dos builds. Por padrão, `$TMP/spm-build`.

- `DESTDIR`  
  Diretório onde o pacote será **instalado em staging** durante o build.  
  O seu `build.sh` deve usar sempre:

  ```bash
  make install DESTDIR="$DESTDIR"
  ```

  ou equivalente, nunca instalar diretamente em `/`.

- `JOBS`  
  Número de *threads* para compilação paralela.

Além disso:

- O `PWD` dentro do `build()` normalmente é o **diretório do source** depois da extração
  (o `spm` entra automaticamente na pasta criada pelo tarball quando existe apenas uma).

---

## 4. Fluxo completo de um pacote

O ciclo de vida de um pacote é:

1. Você cria `/etc/spm/pkg/<pacote>/build.sh`.
2. Dentro desse arquivo, você define:
   - `name` – nome do pacote
   - `version` – versão
   - `source` – lista de fontes
   - `sha256` – lista de checksums
   - `deps` – array de dependências
   - função `build()` – como construir/instalar no `DESTDIR`
   - opcional `post_install()` – hook após instalação real em `/`.
3. Você roda:

   ```bash
   spm <pacote>
   ```

   ou:

   ```bash
   spm -b <pacote>   # só build (gera pacote)
   spm -i <pacote>   # instala a partir do cache
   ```

4. O `spm`:
   - resolve dependências;
   - baixa fontes e confere `sha256`;
   - cria diretórios de build/stage limpos;
   - roda `build()`;
   - gera o pacote `.spm.tar.zst`;
   - instala em `/` (exceto no modo só build).

---

## 5. Campos de um build.sh

Um `build.sh` típico tem esta forma:

```bash
name=gettext
version=0.26

source="\
  gettext-{version}.tar.xz::https://ftp.gnu.org/gnu/gettext/gettext-{version}.tar.xz \
  gettext-0213.patch \
"

sha256="\
  <sha256-do-tarball> \
  <sha256-do-patch>   \
"

deps=(glibc gcc)

build() {
  set -euo pipefail

  ./configure \
    --prefix=/usr

  make -j"$JOBS"
  make install DESTDIR="$DESTDIR"
}

post_install() {
  # Opcional: roda depois da instalação real em /
  # Exemplo: atualizar cache de locale, registrar algo, etc.
  :
}
```

### 5.1. `name` e `version`

- `name` → nome lógico do pacote (`gettext`, `python`, `openssl`).
- `version` → versão exata (`0.26`, `3.13.7`, etc.).

O `spm` combina isso em `PKG_FULLNAME="${name}-${version}"`.

### 5.2. `source`

O campo `source` suporta:

- **URL com nome de arquivo explícito**:

  ```bash
  source="arquivo.tar.xz::https://servidor/path/arquivo.tar.xz"
  ```

  O lado esquerdo (`arquivo.tar.xz`) é o nome usado no cache.

- **Arquivos locais** (na pasta do pacote em `/etc/spm/pkg/<name>/`):

  ```bash
  source="patches/fix-bug.patch"
  ```

- **Múltiplas entradas**, separadas por espaços ou quebras de linha.

O `spm` faz também a expansão de `{name}` e `{version}` em cada item:

```bash
source="\
  {name}-{version}.tar.xz::https://exemplo.org/{name}-{version}.tar.xz \
  {name}-{version}-extra.patch \
"
```

### 5.3. `sha256`

O campo `sha256` deve ter **exatamente o mesmo número de entradas** que `source`,
na mesma ordem. Exemplo:

```bash
source="\
  foo-1.0.tar.xz::https://.../foo-1.0.tar.xz \
  foo-fix.patch \
"

sha256="\
  1111...aaa \
  2222...bbb \
"
```

Para gerar esses hashes de forma correta e prática, o `spm` agora tem
o comando `spm checksum` (veja mais abaixo).

### 5.4. `deps`

Array com as dependências de **build e runtime** do pacote:

```bash
deps=(glibc zlib openssl)
```

O `spm` resolve dependências de forma recursiva e detecta ciclos.

### 5.5. `build()`

A função central. Aqui você:

- configura;
- compila;
- instala em `DESTDIR`.

Regras importantes:

- Sempre use `DESTDIR="$DESTDIR"` na instalação.
- Use `JOBS` para paralelismo.
- Pode assumir que:
  - os sources já estão no diretório de trabalho (`PWD`);
  - patches listados em `source` também estão ali.

### 5.6. `post_install()`

Hook opcional. É executado **depois que o pacote foi instalado em `/`**.

Exemplo:

```bash
post_install() {
  echo "Pacote $name $version instalado com sucesso!"
}
```

Se você não precisar de nada extra, pode simplesmente deixar:

```bash
post_install() { :; }
```

---

## 6. Comandos do spm

A sintaxe geral é:

```bash
spm [comando] <pacote>
```

Quando você chama apenas `spm <pacote>`, o comando padrão é:
“resolver dependências, buildar e instalar”.

### 6.1. `spm <pacote>`

Exemplo:

```bash
spm python
```

Faz:

- resolve dependências (`deps python`);
- para cada pacote, se ainda não houver pacote em cache:
  - baixa sources;
  - confere `sha256`;
  - roda `build()`;
  - gera `.spm.tar.zst`;
- instala todos os pacotes na ordem correta em `/`;
- roda `post_install` se existir.

---

### 6.2. `spm -b <pacote>` / `spm build <pacote>`

Exemplos:

```bash
spm -b python
spm -b --with-deps python
```

Modos:

- `spm -b <pacote>`  
  Faz **somente** o build daquele pacote:
  - baixa fontes (se necessário);
  - gera o pacote binário `.spm.tar.zst` em:

    ```text
    /var/cache/spm/pkg/<nome>-<versao>.spm.tar.zst
    ```

  - gera o manifesto cache em
    `/var/lib/spm/manifests/<nome>-<versao>.manifest.cache`;
  - **não** resolve dependências;
  - **não** instala nada em `/` e não roda `post_install`.

- `spm -b --with-deps <pacote>`  
  Resolve a ordem de dependências com `deps <pacote>` e, para **cada**
  pacote na ordem, executa `build_pkg`:
  - gera binários `.spm.tar.zst` para as dependências e para o pacote alvo;
  - **continua não instalando nada em `/`**.

Esse comando é ideal para:

- pré-build em ambientes de CI;
- preparar um repositório de binários;
- compilar tudo antes de instalar com `spm -i` ou `spm <pacote>`.

---

### 6.3. `spm -i <pacote>` / `spm install <pacote>`

Exemplo:

```bash
spm -i python
```

Faz:

- resolve dependências;
- para cada dependência + pacote:
  - se existir `.spm.tar.zst` no cache, usa;
  - se não existir, constrói (como em `spm -b`).
- instala o pacote em `/` usando o tarball;
- atualiza o manifesto e o status;
- executa `post_install` se existir.
Além disso, existe um modo especial para **reinstalar usando apenas binários
já gerados**, sem rebuild:

```bash
spm -i --bin /caminho/para/binarios python
spm install --bin /caminho/para/binarios python
```

Nesse modo:

- o `spm` procura o arquivo:
  - `/caminho/para/binarios/python-<versao>.spm.tar.zst`
- se encontrar, instala **somente a partir dele**, sem compilar nada;
- se **não** encontrar, o comportamento é:
  - erro fatal: “pacote binário não encontrado em DIR…”
  - ou seja, **não** cai para build – é pensado para reinstalar um sistema
    inteiro usando apenas os binários previamente criados.

Use isso, por exemplo, quando você tiver um backup de todos os pacotes
`.spm.tar.zst` em um diretório separado e quiser reconstruir o sistema sem
rodar compilações novamente.


---

### 6.4. `spm remove <pacote>` / `spm -r <pacote>`

Exemplo:

```bash
spm remove python
```

Usa o manifesto armazenado em:

```text
/var/lib/spm/manifests/<nome>-<versao>.manifest.cache
```

E:

- remove todos os arquivos listados (na ordem inversa);
- remove a entrada de status de `/var/lib/spm/status/<nome>`.

> Observação: dependências **não são removidas automaticamente**.

---

### 6.5. `spm deps <pacote>`

Exemplo:

```bash
spm deps python
```

Imprime a **ordem linear de dependências**, respeitando:

- dependências diretas;
- dependências transitivas;
- detecção de ciclos (erro claro se houver loop).

---

### 6.6. `spm list`

Lista todos os pacotes conhecidos (ou seja, os que têm diretório
em `/etc/spm/pkg/<nome>`), indicando se estão instalados e sua versão.

Exemplo de saída:

```text
attr                     [installed]   2.5.2
bash                     [installed]   5.3
expat                    [installed]   2.7.1
intltool                 [not-installed] 0.51.0
python                   [installed]   3.13.7
```

---

### 6.7. `spm search <padrão>`

Busca por substring no nome do pacote (case-insensitive).

Exemplo:

```bash
spm search py
```

Saída típica:

```text
python                   [installed]   3.13.7
packaging                [installed]   25.0
```

Útil para descobrir o nome exato do pacote antes de rodar `spm <pacote>`.

---

### 6.8. `spm checksum <pacote>`

Este comando ajuda a preencher o campo `sha256` no `build.sh`.

Ele:

- carrega o `build.sh` do pacote (`/etc/spm/pkg/<pacote>/build.sh`);
- lê o campo `source`;
- baixa os arquivos (se necessário) para o cache;
- calcula os `sha256sum` para cada arquivo;
- imprime uma lista de checksums e uma sugestão de linha `sha256="..."`.

Exemplo:

```bash
spm checksum gettext
```

Saída típica:

```text
1111aaa...ccc  gettext-0.26.tar.xz
2222bbb...ddd  gettext-0213.patch

# Linha sugerida para o campo sha256 do build.sh:
# sha256="\
#   1111aaa...ccc \
#   2222bbb...ddd \
#"
```

Você pode simplesmente copiar/colar isso para dentro do `build.sh`.

> Dica: use esse comando toda vez que atualizar a versão de um pacote
> ou trocar algum arquivo em `source`.

### 6.9. `spm check` / `spm check <pacote>`

Faz um *sanity-check* dos arquivos instalados a partir do manifesto.

- `spm check`  
  Checa **todos os pacotes instalados**:
  - lê o arquivo de status em `/var/lib/spm/status/<nome>`;
  - descobre a versão instalada;
  - lê o manifesto correspondente em
    `/var/lib/spm/manifests/<nome>-<versao>.manifest`;
  - para cada caminho listado, verifica se o arquivo/diretório ainda existe
    em `DESTDIR` (normalmente `/`).

- `spm check <pacote>`  
  Faz a mesma verificação, mas apenas para o pacote indicado.

Exemplo:

```bash
spm check
spm check python
```

Saída típica:

```text
[spm:check] python@3.13.7: OK
[spm:check] bash@5.3: MISSING: /usr/bin/bash
```

Esse comando é útil para:

- detectar arquivos apagados manualmente;
- validar a integridade lógica de uma instalação depois de algum problema.

---

### 6.10. `spm upgrade` / `spm upgrade <pacote>`

O comando `upgrade` usa o conteúdo do `build.sh` como “verdade atual” sobre
qual deveria ser a versão do pacote.

- `spm upgrade`  
  Para **cada pacote instalado**:
  - lê a versão atualmente instalada (arquivo de status);
  - lê a versão declarada em `/etc/spm/pkg/<nome>/build.sh`;
  - se forem diferentes, considera que há um upgrade (ou downgrade) a fazer;
  - roda `deps <nome>` e chama `install_pkg` para cada pacote da ordem.

- `spm upgrade <pacote>`  
  Faz o mesmo processo, mas somente para o pacote indicado (e suas deps).

Exemplo:

```bash
# Atualizar tudo o que tiver nova versão declarada em build.sh
spm upgrade

# Atualizar apenas o Python
spm upgrade python
```

Observações:

- Se não houver entrada em `/etc/spm/pkg/<nome>`, o pacote é ignorado.
- Se a versão instalada não puder ser detectada (status antigo), o `spm`
  considera como “versão desconhecida -> versão do build.sh” e recompila.
---

### 6.11. `spm rebuild` / `spm rebuild <pacote>`

O comando `rebuild` é focado em **reconstruir** pacotes já existentes,
mesmo que a versão no `build.sh` não tenha mudado.

- `spm rebuild <pacote>`  
  Faz:

  - roda `build_pkg <pacote>` → gera um novo `.spm.tar.zst` e manifesto cache;
  - em seguida chama `install_pkg <pacote>` → reinstala o pacote usando o
    binário recém-gerado.

  Se o pacote não estiver instalado, o comportamento prático é:
  “build + install daquele pacote”.

- `spm rebuild` (sem argumentos)  
  Percorre todos os pacotes com status em `/var/lib/spm/status/<nome>` e, para
  cada um, faz o rebuild + reinstall como acima.

Exemplos:

```bash
# Rebuild completo apenas do Python
spm rebuild python

# Rebuild de todos os pacotes instalados
spm rebuild
```

Usos típicos:

- reconstruir tudo após mudar `CFLAGS`, `LDFLAGS` ou alguma opção global de build;
- garantir que todos os binários foram gerados com a toolchain atual;
- testar se os `build.sh` ainda funcionam para todos os pacotes instalados.
### 6.10. `spm upgrade` / `spm upgrade <pacote>`

O comando `upgrade` usa o conteúdo do `build.sh` como “verdade atual” sobre
qual deveria ser a versão do pacote.

- `spm upgrade`  
  Para **cada pacote instalado**:
  - lê a versão atualmente instalada (arquivo de status);
  - lê a versão declarada em `/etc/spm/pkg/<nome>/build.sh`;
  - se forem diferentes, considera que há um upgrade (ou downgrade) a fazer;
  - roda `deps <nome>` e chama `install_pkg` para cada pacote da ordem.

- `spm upgrade <pacote>`  
  Faz o mesmo processo, mas somente para o pacote indicado (e suas deps).

Exemplo:

```bash
# Atualizar tudo o que tiver nova versão declarada em build.sh
spm upgrade

# Atualizar apenas o Python
spm upgrade python
```

Observações:

- Se não houver entrada em `/etc/spm/pkg/<nome>`, o pacote é ignorado.
- Se a versão instalada não puder ser detectada (status antigo), o `spm`
  considera como “versão desconhecida -> versão do build.sh” e recompila.
---

### 6.11. `spm rebuild` / `spm rebuild <pacote>`

O comando `rebuild` é focado em **reconstruir** pacotes já existentes,
mesmo que a versão no `build.sh` não tenha mudado.

- `spm rebuild <pacote>`  
  Faz:

  - roda `build_pkg <pacote>` → gera um novo `.spm.tar.zst` e manifesto cache;
  - em seguida chama `install_pkg <pacote>` → reinstala o pacote usando o
    binário recém-gerado.

  Se o pacote não estiver instalado, o comportamento prático é:
  “build + install daquele pacote”.

- `spm rebuild` (sem argumentos)  
  Percorre todos os pacotes com status em `/var/lib/spm/status/<nome>` e, para
  cada um, faz o rebuild + reinstall como acima.

Exemplos:

```bash
# Rebuild completo apenas do Python
spm rebuild python

# Rebuild de todos os pacotes instalados
spm rebuild
```

Usos típicos:

- reconstruir tudo após mudar `CFLAGS`, `LDFLAGS` ou alguma opção global de build;
- garantir que todos os binários foram gerados com a toolchain atual;
- testar se os `build.sh` ainda funcionam para todos os pacotes instalados.

---

## 7. Exemplo real de build.sh comentado (Python)

A seguir, um exemplo simplificado de `build.sh` para o Python:

```bash
name=python
version=3.13.7

source="\
  Python-{version}.tar.xz::https://www.python.org/ftp/python/{version}/Python-{version}.tar.xz \
"

sha256="\
  <sha256-do-tarball> \
"

deps=(glibc zlib bzip2 xz libffi openssl ncurses readline expat)

build() {
  set -euo pipefail

  # Ajusta flags para preferir bibliotecas do sistema
  export CPPFLAGS="${CPPFLAGS:-} -I/usr/include"
  export LDFLAGS="${LDFLAGS:-} -L/usr/lib"

  ./configure \
    --prefix=/usr \
    --enable-optimizations \
    --with-lto \
    --enable-shared \
    --with-system-ffi \
    --with-openssl=/usr \
    --enable-loadable-sqlite-extensions \
    --with-ensurepip=install

  make -j"$JOBS"
  make install DESTDIR="$DESTDIR"

  # Conveniência: garante que 'python' exista apontando para 'python3'
  if [[ -x "$DESTDIR/usr/bin/python3" && ! -e "$DESTDIR/usr/bin/python" ]]; then
    ln -sf python3 "$DESTDIR/usr/bin/python"
  fi
}

post_install() {
  # Aqui você poderia, por exemplo, rodar um sanity-check rápido:
  if command -v python3 >/dev/null 2>&1; then
    echo "[spm] Python 3 está disponível após a instalação."
  fi
}
```

Comentários importantes:

- O `source` usa `{version}` para evitar repetir a versão.
- O `sha256` é gerado com `spm checksum python`.
- As dependências (`deps`) garantem que todas as libs C necessárias
  estão instaladas antes de compilar.
- O uso de `DESTDIR="$DESTDIR"` garante que o build não polui o sistema
  durante a compilação.

---

## 8. Dicas finais

- Sempre use `set -euo pipefail` no início de `build()`.
- Nunca instale direto em `/` dentro de `build()`.
- Use `spm deps <pacote>` para entender a árvore de dependências.
- Use `spm -b <pacote>` para pré-compilar tudo antes de instalar.
- Use `spm checksum <pacote>` sempre que mexer em `source`.

Com isso, o `spm` vira não só um gerenciador de pacotes, mas também
uma **ferramenta de estudo** de como funciona a construção de um
Linux inteiro, pacote por pacote.

---
## 9. Comandos avançados

### spm check <pacote>

Verifica se todos os arquivos listados no manifesto ainda existem no sistema.

Útil para detectar:
- arquivos apagados acidentalmente
- corrupção do sistema

### spm -i --bin <diretório>

Reinstala o sistema usando **somente pacotes binários `.spm.tar.zst`** já construídos.

Exemplo:

```bash
spm -i --bin /backup/spm-binarios
```

Ideal para:
- reinstalar o sistema inteiro offline
- disaster recovery
- clonagem de sistemas

### spm upgrade

Verifica todos os pacotes instalados e:
- compara versão instalada vs versão em `build.sh`
- recompila e reinstala apenas os pacotes que mudaram

Semântica:
- idempotente
- seguro
- baseado em manifesto e cache

---
## 9. Build avançado e rebuild

### 9.1 `spm -b --with-deps <pacote>`

Constrói **o pacote e todas as dependências**, mas **não instala nada**.

Exemplo:

```bash
spm -b --with-deps python
```

Resultado:
- todos os pacotes da árvore de dependências são compilados
- todos os `.spm.tar.zst` ficam disponíveis em `/var/cache/spm/pkg`
- nenhum pacote é instalado em `/`

Uso típico:
- geração de repositório binário completo
- bootstrap controlado
- build em CI

---

### 9.2 `spm rebuild <pacote>`

Força **rebuild + reinstall** de um pacote e todas as suas dependências.

```bash
spm rebuild python
```

Equivale conceitualmente a:

```bash
for p in $(spm deps python); do
  spm -b "$p"
  spm -i "$p"
done
```

---

### 9.3 `spm rebuild --all`

Reconstrói **todos os pacotes instalados**, na ordem correta.

```bash
spm rebuild --all
```

Útil para:
- rebuild completo do sistema após mudança de flags globais
- migração de toolchain
- auditoria de build reproduzível
