# mkrootfs, imagens de rootfs e fluxo de instalação

Este documento descreve, em detalhes, como usar o script `mkrootfs` para:

- Gerar imagens de **rootfs base** (apenas texto, login funcional).
- Gerar imagens de **rootfs desktop** (Xorg, Xfce, áudio/vídeo, browser, etc.).
- Restaurar um rootfs a partir de um tarball.
- Integrar isso com o `manage-chroot.sh` para ter um sistema pronto para ser:
  - reconstruído,
  - testado em chroot,
  - e finalmente empacotado como rootfs pronto para instalar.

---

## 1. O que o `/usr/bin/mkrootfs` faz

O script:

- Lê uma árvore de rootfs (por padrão, `/`).
- Exclui:
  - pseudo-filesystems (`/proc`, `/sys`, `/dev`, `/run`, `/tmp/*`);
  - logs, caches e spools (`/var/log/*`, `/var/cache/*`, `/var/tmp/*`, `/var/spool/*`);
  - caches de usuário (`/home/*/.cache/*`).
- Para o perfil `base`, também exclui:
  - bibliotecas/arquivos claramente ligados a Xfce/Xorg/GUI pesada;
  - ícones, temas e fundos;
  - Firefox (binário, libs e `.desktop`).

Ele **não altera** nada dentro do rootfs. Só lê e grava o tarball.

### 1.1 Perfis

- **`base`**
  - Target: sistema mínimo para servidores, chroot, containers ou debug.
  - Inclui: init (`systemd`), login em console, rede básica, SPM, ferramenta de chroot.
  - Exclui:
    - pasta de temas e ícones;
    - arquivos de sessão gráfica;
    - binários de Xorg e Firefox.

- **`desktop`**
  - Target: seu sistema completo com Xfce, Xorg, áudio/vídeo, browsers, etc.
  - Apenas remove lixo (logs, caches, tmp) e pseudo-fs.

---

## 2. Uso básico do `mkrootfs`

### 2.1 Sintaxe

```bash
mkrootfs [opções]

Opções principais:
  -p, --profile {base|desktop}
  -r, --root DIR
  -o, --output-dir DIR
  -c, --compression {zst|xz|gz}
      --force
      --dry-run
```

### 2.2 Exemplo: dentro do chroot

Assumindo que você já entrou no seu chroot (via `manage-chroot.sh`) e lá **`/`** é o topo do seu sistema customizado:

#### Rootfs base

```bash
mkrootfs --profile base
```

Resultado:

- Gera um arquivo no diretório atual:
  - `rootfs-base-YYYYmmdd-HHMMSS.tar.zst`

#### Rootfs desktop

```bash
mkrootfs --profile desktop
```

Resultado:

- Gera:
  - `rootfs-desktop-YYYYmmdd-HHMMSS.tar.zst`

### 2.3 Exemplo: rodando no host apontando para `/rootfs`

Se você tem o sistema montado em `/rootfs` no host:

```bash
mkrootfs --profile desktop --root /rootfs --output-dir /root
```

- `--root /rootfs`: onde está o rootfs a empacotar.
- `--output-dir /root`: lugar onde o `.tar.zst` será gravado no host.

---

## 3. Fluxo recomendado com SPM

A ideia é:

1. **Construir e instalar tudo via SPM** dentro de um chroot (ou diretório raiz).
2. Gerar uma imagem **base**.
3. Em seguida, gerar uma imagem **desktop**.

### 3.1 Instalar sistema usando SPM

Dentro do chroot (ou num rootfs “raso” que será o seu sistema), você usa:

```bash
# toolchain, base, systemd, rede, etc.
spm <lista-de-pacotes-base>

# Xorg + Xfce + áudio/vídeo
spm <lista-de-pacotes-desktop>
```

ou mais incremental:

```bash
# Construir com deps mas ainda não instalar:
spm -b --with-deps systemd xfce4 xorg-server pipewire ffmpeg firefox

# Instalar do cache binário:
spm -i systemd xfce4 xorg-server pipewire ffmpeg firefox
```

Quando o seu sistema estiver pronto, já com:

- `/etc` configurado;
- systemd configurado como PID 1;
- serviços de rede, journald, logind, etc.;
- Xorg + Xfce + audio + video funcionando no chroot;

você passa para a etapa de gerar imagens.

### 3.2 Gerar imagem base

No chroot:

```bash
cd /root         # ou outro diretório seguro para saída
mkrootfs --profile base
```

Guarde esse tarball como “rootfs mínimo” para:

- debug,
- container,
- ou base para futuras construções.

### 3.3 Gerar imagem desktop

Ainda no chroot (ou num novo chroot):

```bash
cd /root
mkrootfs --profile desktop
```

Esse será o “rootfs instalável” com desktop completo.

---

## 4. Restaurar um rootfs a partir do tar

Você pode restaurar o rootfs:

1. Em uma partição real (ex.: `/dev/sdXN` montada em `/mnt/target`).
2. Em um diretório qualquer (ex.: `/rootfs`), para chroot.

### 4.1 Preparar destino

Exemplo: você quer restaurar em `/mnt/target`:

```bash
mkdir -p /mnt/target
mount /dev/sdXN /mnt/target       # adapte para seu disco real
```

### 4.2 Descompactar o rootfs base ou desktop

#### Tar `.tar.zst`

```bash
cd /mnt/target
zstd -d -c /caminho/para/rootfs-desktop-YYYYmmdd-HHMMSS.tar.zst | tar -xpf -
```

#### Tar `.tar.xz`

```bash
cd /mnt/target
xz -d -c /caminho/para/rootfs-desktop-YYYYmmdd-HHMMSS.tar.xz | tar -xpf -
```

#### Tar `.tar.gz`

```bash
cd /mnt/target
gzip -d -c /caminho/para/rootfs-desktop-YYYYmmdd-HHMMSS.tar.gz | tar -xpf -
```

Observações importantes:

- Use `tar -xpf -` (com `-p`) para preservar permissões e owners.
- O tar foi criado a partir da raiz (`/` ou `--root`) e descompactar em `/mnt/target` coloca tudo na mesma topologia.

---

## 5. Integração com `manage-chroot.sh`

Você já tem um script `manage-chroot.sh` que:

- monta bind de pseudo-fs (`/dev`, `/proc`, `/sys`, `/run`) dentro do chroot;
- entra e sai do chroot de forma segura;
- permite rodar comandos no chroot sem “morar” lá.

### 5.1 Fluxo típico de uso

1. **Criar diretório do rootfs de construção** no host:

   ```bash
   mkdir -p /rootfs
   ```

2. **Extrair o rootfs base ou vazio de trabalho**:

   ```bash
   cd /rootfs
   # supondo que você esteja iniciando do zero:
   # (caso tenha um rootfs-base prévio, extraia aqui)
   ```

3. **Entrar no chroot para construir o sistema**:

   ```bash
   manage-chroot.sh enter /rootfs
   ```

   Dentro do chroot:

   ```bash
   # configurar rede, resolver, etc. se necessário
   spm <pacotes-base>
   spm <pacotes-desktop>
   ```

4. **Sair do chroot**:

   ```bash
   exit
   # no host, manage-chroot.sh deve desmontar/bind automaticamente (dependendo do modo)
   ```

5. **Gerar as imagens de rootfs (no host ou dentro do chroot)**:

   - Dentro do chroot (mais simples):

     ```bash
     manage-chroot.sh enter /rootfs

     cd /root
     mkrootfs --profile base
     mkrootfs --profile desktop

     exit
     ```

   - Ou no host, apontando `--root /rootfs`:

     ```bash
     cd /
     mkrootfs --profile base --root /rootfs --output-dir /root
     mkrootfs --profile desktop --root /rootfs --output-dir /root
     ```

---

## 6. Fluxo completo: do zero até um sistema pronto

### 6.1 Construção dentro de `/rootfs` (no host)

1. Crie o diretório de rootfs de construção:

   ```bash
   mkdir -p /rootfs
   ```

2. Use `manage-chroot.sh` para entrar e preparar o ambiente:

   ```bash
   manage-chroot.sh enter /rootfs
   ```

3. Dentro do chroot:

   - Configure `/etc/resolv.conf`, locale, time zone, etc.
   - Use `spm` para instalar tudo o que você definiu (toolchain, base, systemd, Xorg, Xfce, etc.).
   - Teste o sistema:

     ```bash
     systemctl list-unit-files | grep enabled
     loginctl
     startx  # ou startxfce4 / lightdm, conforme sua configuração
     ```

4. Quando estiver satisfeito com o sistema:

   ```bash
   cd /root
   mkrootfs --profile base
   mkrootfs --profile desktop
   ```

5. Saia do chroot:

   ```bash
   exit
   ```

### 6.2 Instalar o rootfs em um disco real

Com o tar do rootfs desktop pronto:

1. Particione e formate o disco (ex.: `/dev/sdX` → `/dev/sdX1`):

   ```bash
   mkfs.ext4 /dev/sdX1
   mkdir -p /mnt/target
   mount /dev/sdX1 /mnt/target
   ```

2. Extraia a imagem desktop:

   ```bash
   cd /mnt/target
   zstd -d -c /caminho/para/rootfs-desktop-YYYYmmdd-HHMMSS.tar.zst | tar -xpf -
   ```

3. Monte pseudo-fs e entre em chroot para configurar bootloader, fstab, hostname, etc.:

   ```bash
   manage-chroot.sh enter /mnt/target
   ```

   Dentro do chroot:

   ```bash
   # configurar /etc/fstab, /etc/hostname, /etc/hosts
   # garantir que systemd esteja habilitado, lightdm configurado, etc.
   ```

4. Saia, desmonte e teste boot real.

---

## 7. Dicas de sanidade e debug

- Use sempre `--dry-run` primeiro:

  ```bash
  mkrootfs --profile base --dry-run
  ```

  Você verá:

  - o rootdir;
  - o arquivo de saída (nome + compressão);
  - a lista exata de exclusões.

- Se quiser incluir mais diretórios no perfil base, você pode ajustar o script `mkrootfs` e adicionar mais padrões a `EXCLUDES` dentro do bloco `PROFILE=base`.

- Se algo essencial sumir (por exemplo, um ícone ou tema importante), use o tar do perfil `desktop` para comparar conteúdo.

---

Com isso, o `mkrootfs` se integra ao seu fluxo SPM + manage-chroot:

1. Constrói tudo com SPM.
2. Testa e configura via chroot.
3. Gera rootfs base e desktop.
4. Restaura o rootfs no disco desejado.
5. Faz boot no seu sistema personalizado.
