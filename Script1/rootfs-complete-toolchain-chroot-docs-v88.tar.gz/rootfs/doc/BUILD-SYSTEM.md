# Documentação – Construção do Sistema Linux do Zero

Este documento descreve **toda a construção do sistema**, desde o toolchain
temporário até a preparação do ambiente para chroot.

## 1. Estrutura Geral

- ROOTFS: diretório raiz do novo sistema (ex: /tmp/rootfs)
- tools: toolchain temporário usado durante a construção
- scripts: scripts de build e orquestração
- sources: tarballs dos pacotes

```
/tmp/rootfs
├── tools
├── bin
├── lib
├── usr
├── scripts
└── doc
```

## 2. Toolchain Temporário

O processo começa com:

- Binutils Pass 1
- GCC Pass 1

Eles são instalados em:

```
$ROOTFS/tools
```

Esse toolchain **não depende da libc final**.

## 3. Headers do Kernel

Os Linux API Headers são instalados em:

```
$ROOTFS/usr/include
```

Eles definem a ABI entre kernel e userspace.

## 4. Glibc Pass 1

A glibc é construída usando:

- headers do kernel
- GCC Pass 1

Ela fornece:

- loader dinâmico
- libc básica
- syscalls wrapper

## 5. Ferramentas Temporárias

Programas como:

- bash
- coreutils
- sed
- grep
- tar

são construídos para permitir um ambiente funcional mínimo.

## 6. Toolchain Pass 2

Com libc disponível:

- Binutils Pass 2
- GCC Pass 2

Agora o compilador está **completo** e usa o sysroot real.

## 7. Pronto para chroot

Após isso, o sistema está pronto para:

```bash
chroot $ROOTFS /bin/bash
```

ou usando o script seguro fornecido.
