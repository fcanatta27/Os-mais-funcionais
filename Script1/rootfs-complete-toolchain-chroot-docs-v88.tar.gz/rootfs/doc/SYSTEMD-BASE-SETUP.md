# SYSTEMD – Base Setup, Uso e Administração

Este documento descreve **completo e detalhado** como o systemd foi configurado neste sistema,
como utilizá-lo no dia a dia e quais passos executar no **primeiro boot** de um sistema Linux
construído do zero.

---

## 1. O que é o systemd

O **systemd** é:

- PID 1 (primeiro processo do sistema)
- Gerenciador de serviços
- Gerenciador de sessões
- Gerenciador de logs (journald)
- Gerenciador de rede (networkd)
- Gerenciador de tempo (timesyncd)
- Gerenciador de dispositivos (udevd)
- Gerenciador de usuários/grupos (sysusers)
- Gerenciador de arquivos temporários (tmpfiles)

Neste sistema ele **substitui completamente** sysvinit, busybox-init, openrc, etc.

---

## 2. Layout básico no sistema

Principais caminhos:

- Binário PID 1  
  `/usr/lib/systemd/systemd`

- Link de inicialização  
  `/sbin/init -> /usr/lib/systemd/systemd`

- Units do sistema  
  `/usr/lib/systemd/system/*.service`

- Overrides e habilitações  
  `/etc/systemd/system/`

- Configurações globais  
  `/etc/systemd/*.conf`

- Logs persistentes  
  `/var/log/journal`

---

## 3. Targets (níveis de execução)

Targets substituem os antigos runlevels.

Principais:

- `default.target` → target padrão do boot
- `multi-user.target` → sistema em modo texto com rede
- `graphical.target` → modo gráfico (quando existir GUI)
- `rescue.target` → modo single-user
- `emergency.target` → shell mínimo

Neste sistema:

```
default.target → multi-user.target
```

---

## 4. Serviços essenciais habilitados

Habilitados automaticamente:

- systemd-networkd.service
- systemd-resolved.service
- systemd-timesyncd.service
- getty@tty1.service

---

## 5. Comandos básicos do systemctl

### Ver status do sistema

```bash
systemctl status
```

### Listar serviços ativos

```bash
systemctl list-units --type=service
```

### Listar serviços habilitados no boot

```bash
systemctl list-unit-files --state=enabled
```

### Iniciar / parar serviços

```bash
systemctl start sshd
systemctl stop sshd
systemctl restart sshd
```

### Habilitar / desabilitar no boot

```bash
systemctl enable sshd
systemctl disable sshd
```

### Ver logs de um serviço

```bash
journalctl -u sshd
```

---

## 6. Criando um serviço customizado

Exemplo: `/etc/systemd/system/meu-servico.service`

```ini
[Unit]
Description=Meu serviço de exemplo
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/meu-programa
Restart=on-failure

[Install]
WantedBy=multi-user.target
```

Ativar:

```bash
systemctl daemon-reexec
systemctl daemon-reload
systemctl enable meu-servico
systemctl start meu-servico
```

---

## 7. Logs – journald

### Ver logs do boot atual

```bash
journalctl -b
```

### Ver logs do boot anterior

```bash
journalctl -b -1
```

### Ver logs em tempo real

```bash
journalctl -f
```

### Ver logs de um serviço

```bash
journalctl -u systemd-networkd
```

Logs são persistentes em:

```
/var/log/journal
```

---

## 8. Rede – systemd-networkd

Configuração padrão:

```
/etc/systemd/network/20-wired.network
```

Usa DHCP automático para interfaces:

- en*
- eth*
- wl*

Ver estado:

```bash
networkctl
networkctl status
```

---

## 9. DNS – systemd-resolved

Arquivo:

```
/etc/systemd/resolved.conf
```

Ver estado:

```bash
resolvectl status
```

Testar DNS:

```bash
ping -c 3 google.com
```

---

## 10. Tempo – systemd-timesyncd

Arquivo:

```
/etc/systemd/timesyncd.conf
```

Ver estado:

```bash
timedatectl status
```

Forçar sync:

```bash
timedatectl set-ntp true
```

---

## 11. Locale, teclado e console

Arquivos:

- `/etc/locale.conf`
- `/etc/locale.gen`
- `/etc/vconsole.conf`
- `/etc/localtime`

Gerar locales:

```bash
locale-gen
```

---

## 12. CHECKLIST – PRIMEIRO BOOT DO SISTEMA

Execute **nesta ordem** após o primeiro boot:

### 1. Login como root

No console (tty1).

---

### 2. Gerar locales

```bash
locale-gen
```

Reinicie o shell:

```bash
exec bash
```

---

### 3. Verificar systemd

```bash
systemctl status
```

---

### 4. Verificar rede

```bash
networkctl
ping -c 3 1.1.1.1
ping -c 3 google.com
```

---

### 5. Ajustar hostname (opcional)

```bash
echo "meu-host" > /etc/hostname
hostnamectl set-hostname meu-host
```

---

### 6. Criar usuário normal

```bash
useradd -m -G wheel,audio,video -s /bin/bash usuario
passwd usuario
```

(ajuste grupos conforme necessário)

---

### 7. Configurar sudo (se tiver sudo instalado)

```bash
EDITOR=vim visudo
```

Descomente:

```
%wheel ALL=(ALL) ALL
```

---

### 8. Gerar chaves SSH

```bash
ssh-keygen -A
systemctl enable sshd
systemctl start sshd
```

---

### 9. Testar logs

```bash
journalctl -b
journalctl -u sshd
```

---

### 10. Ajustar timezone (opcional)

```bash
timedatectl set-timezone America/Sao_Paulo
```

---

### 11. Reiniciar para validar boot completo

```bash
reboot
```

---

## 13. Próximos passos

- Configurar GRUB totalmente
- Criar initramfs (se necessário)
- Instalar stack gráfica (opcional)
- Endurecer segurança (firewall, ssh config, etc.)

Este sistema agora está **pronto para uso real**.
