# PRIMEIRO BOOT – CHECKLIST COMPLETO (BASE + XORG + XFCE4)

Este documento descreve **exatamente** o que configurar e testar no primeiro boot
para obter um **desktop XFCE4 completo, funcional e estável**.

---

## 1. LOGIN COMO ROOT (PRIMEIRA VEZ)

Entre como root no console:

```bash
login: root
```

Confirme:
```bash
uname -a
mount
df -h
```

---

## 2. CRIAR USUÁRIO NORMAL

```bash
useradd -m -G wheel,audio,video,input,network,storage -s /bin/bash usuario
passwd usuario
```

(opcional) liberar sudo:
```bash
EDITOR=vi visudo
# descomente:
%wheel ALL=(ALL:ALL) ALL
```

---

## 3. HORA, LOCALIDADE E TECLADO

```bash
timedatectl set-timezone America/Sao_Paulo
timedatectl set-ntp true
localectl set-locale LANG=pt_BR.UTF-8
localectl set-keymap br-abnt2
```

Verificar:
```bash
timedatectl
locale
```

---

## 4. REDE (CABO)

```bash
systemctl enable systemd-networkd
systemctl enable systemd-resolved
systemctl start systemd-networkd
systemctl start systemd-resolved
```

Teste:
```bash
ip addr
ping -c3 8.8.8.8
ping -c3 google.com
```

---

## 5. WI-FI

Editar config:
```bash
cp /etc/wpa_supplicant/wpa_supplicant-wlan0.conf.example    /etc/wpa_supplicant/wpa_supplicant-wlan0.conf
nano /etc/wpa_supplicant/wpa_supplicant-wlan0.conf
```

Ativar:
```bash
systemctl enable wpa_supplicant@wlan0
systemctl start wpa_supplicant@wlan0
```

Teste:
```bash
iw dev
ip addr show wlan0
ping -c3 google.com
```

---

## 6. DBUS E POLKIT

```bash
systemctl enable dbus
systemctl start dbus
```

Teste:
```bash
busctl list
```

---

## 7. TESTAR XORG

```bash
su - usuario
startx
```

Se abrir TWM/xterm → OK.

---

## 8. INSTALAR XFCE4 VIA SPM

```bash
spm -b --with-deps xfce4-session xfce4-panel xfce4-settings xfwm4 thunar xfdesktop
spm -i xfce4-session xfce4-panel xfce4-settings xfwm4 thunar xfdesktop
```

Criar `.xinitrc`:
```bash
echo "exec startxfce4" > ~/.xinitrc
chmod +x ~/.xinitrc
```

Rodar:
```bash
startx
```

---

## 9. TESTES FINAIS

- Painel carrega
- Gerenciador de janelas ativo
- Thunar abre
- Rede funciona
- Teclado correto
- Som (se instalado)

---

## 10. SNAPSHOT (RECOMENDADO)

```bash
tar -cpf /rootfs-backup.tar /
```

---

Sistema XFCE4 funcional 🎉
